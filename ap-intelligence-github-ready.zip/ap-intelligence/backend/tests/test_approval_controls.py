import pytest
from decimal import Decimal
from fastapi.testclient import TestClient
from app.main import app
from app.database.session import SessionLocal
from app.models.financial_entities import Invoice, ApprovalRequest, ExceptionRecord, MatchingResult, AuditLog

client = TestClient(app)

def test_missing_po_approval_strictly_blocked():
    """Requirement: Invoices with MISSING_PO cannot be approved."""
    # Find the approval request for INV-2026-00452 (which has MISSING_PO)
    response = client.get("/api/v1/approvals")
    assert response.status_code == 200
    approvals = response.json()
    
    missing_po_approval = next(
        (a for a in approvals if a.get("invoice_id") == "INV-2026-00452"), None
    )
    assert missing_po_approval is not None, "Approval record for INV-2026-00452 must exist"
    assert missing_po_approval["match_status"] == "MISSING_PO"
    assert missing_po_approval["blocking_exceptions_count"] >= 1

    # Attempt to approve should fail with 400 Bad Request
    approval_id = missing_po_approval["id"]
    action_res = client.post(
        f"/api/v1/approvals/{approval_id}/action",
        json={"action": "APPROVED", "comments": "Attempting illegal override of missing PO", "approved_by": "USR-002"},
    )
    assert action_res.status_code == 400
    detail = action_res.json()["detail"]
    assert "Financial Control Violation" in detail
    assert "MISSING_PO" in detail or "EXCEPTION_HOLD" in detail or "open blocking exceptions" in detail

def test_accept_variance_strictly_forbidden_on_missing_po():
    """Requirement: Do not allow Accept Variance to bypass missing documentation or duplicate controls."""
    db = SessionLocal()
    exc = db.query(ExceptionRecord).filter(
        ExceptionRecord.invoice_id == "INV-2026-00452",
        ExceptionRecord.category == "MISSING_PO"
    ).first()
    db.close()
    assert exc is not None, "Exception record for INV-2026-00452 must exist"

    # Attempting to resolve MISSING_PO using ACCEPT_VARIANCE must be rejected
    resolve_res = client.post(
        f"/api/v1/exceptions/{exc.id}/resolve",
        json={
            "action": "ACCEPT_VARIANCE",
            "resolution_notes": "Trying to accept variance on missing PO",
            "resolved_by": "USR-002"
        }
    )
    assert resolve_res.status_code == 400
    detail = resolve_res.json()["detail"].lower()
    assert "cannot be bypassed" in detail or "missing purchase order" in detail or "prohibited" in detail

def test_delegation_of_authority_ceilings():
    """Requirement: Block approval attempts by unauthorized users or users exceeding approval thresholds."""
    # Find an eligible pending approval with amount > 100,000 INR
    response = client.get("/api/v1/approvals")
    assert response.status_code == 200
    approvals = response.json()

    high_value_pending = next(
        (a for a in approvals if a.get("status") == "PENDING" and a.get("blocking_exceptions_count", 0) == 0 and a["amount_inr"] > 100000),
        None
    )
    assert high_value_pending is not None, "Need a pending approval > 1,00,000 INR for ceiling test"
    approval_id = high_value_pending["id"]
    amount = high_value_pending["amount_inr"]

    # Role FINANCE_EXECUTIVE (threshold 1,00,000) should be blocked with 403
    action_res = client.post(
        f"/api/v1/approvals/{approval_id}/action",
        json={
            "action": "APPROVED",
            "comments": "Approval by junior executive",
            "approved_by": "USR-003",
            "user_role": "FINANCE_EXECUTIVE"
        },
    )
    assert action_res.status_code == 403
    detail = action_res.json()["detail"]
    assert "Authorization Ceiling Exceeded" in detail or "Delegation of Authority" in detail

    # Role AP_MANAGER (threshold 10,00,000) or CFO (unlimited) can approve if <= ceiling
    if amount <= 1000000:
        valid_res = client.post(
            f"/api/v1/approvals/{approval_id}/action",
            json={
                "action": "APPROVED",
                "comments": "Approval by AP Manager",
                "approved_by": "USR-002",
                "user_role": "AP_MANAGER"
            },
        )
        assert valid_res.status_code == 200
        assert valid_res.json()["status"] == "APPROVED"

def test_data_integrity_and_amount_consistency():
    """Requirement: Fix invoice amount inconsistencies across all modules so the invoice, matching result,
    exception and approval screens reflect the identical truth."""
    db = SessionLocal()
    invoice = db.query(Invoice).filter(Invoice.id == "INV-2026-00452").first()
    approval = db.query(ApprovalRequest).filter(ApprovalRequest.invoice_id == "INV-2026-00452").first()
    exception = db.query(ExceptionRecord).filter(ExceptionRecord.invoice_id == "INV-2026-00452").first()
    db.close()

    assert invoice is not None
    assert approval is not None
    assert exception is not None

    # Amounts must be completely unified across all entities
    expected_amount = Decimal("246620.00")
    assert invoice.total_amount_inr == expected_amount
    assert approval.amount_inr == expected_amount
    assert exception.financial_impact_inr == expected_amount

    # API responses must reflect this consistent amount
    approvals_res = client.get("/api/v1/approvals")
    inv_approval = next(a for a in approvals_res.json() if a["invoice_id"] == "INV-2026-00452")
    assert Decimal(str(inv_approval["amount_inr"])) == expected_amount
    assert inv_approval["status"] == "HELD"
    assert inv_approval["match_status"] == "MISSING_PO"
    assert inv_approval["blocking_exceptions_count"] >= 1

def test_resolve_exception_never_auto_approves():
    """Requirement: Resolving an exception transitions to eligible status (PENDING_APPROVAL) and requires subsequent human sign-off."""
    db = SessionLocal()
    # Create a temporary test invoice and exception for non-blocking resolution test
    from datetime import date
    test_inv = Invoice(
        id="INV-TEST-CONTROL-001",
        vendor_id="VEND-001",
        invoice_date=date(2026, 3, 31),
        due_date=date(2026, 4, 30),
        vendor_gstin="27AABCS1429B1Z1",
        recipient_gstin="29AAACG0561F1Z8",
        place_of_supply="27",
        taxable_value_inr=Decimal("15000.00"),
        total_tax_inr=Decimal("0.00"),
        total_amount_inr=Decimal("15000.00"),
        status="EXCEPTION_HOLD",
        match_status="PRICE_MISMATCH",
    )
    test_apr = ApprovalRequest(
        id="APR-TEST-CONTROL-001",
        invoice_id="INV-TEST-CONTROL-001",
        required_role="AP_MANAGER",
        status="HELD",
        amount_inr=Decimal("15000.00")
    )
    test_exc = ExceptionRecord(
        id="EXC-TEST-CONTROL-001",
        invoice_id="INV-TEST-CONTROL-001",
        category="PRICE_MISMATCH",
        severity="MEDIUM",
        expected_value="14550.00",
        actual_value="15000.00",
        difference_value="450.00",
        financial_impact_inr=Decimal("450.00"),
        responsible_department="FINANCE",
        status="OPEN",
    )
    db.merge(test_inv)
    db.merge(test_apr)
    db.merge(test_exc)
    db.commit()
    db.close()

    # Resolve exception via SUPPLIER_CREDIT_NOTE
    res_resolve = client.post(
        f"/api/v1/exceptions/EXC-TEST-CONTROL-001/resolve",
        json={
            "action": "SUPPLIER_CREDIT_NOTE",
            "resolution_notes": "Credit note CN-8891 received and verified",
            "resolved_by": "USR-002"
        }
    )
    assert res_resolve.status_code == 200
    res_data = res_resolve.json()
    assert res_data["status"] == "RESOLVED"

    # Verify invoice transitioned to PENDING_APPROVAL, NOT APPROVED
    db = SessionLocal()
    updated_inv = db.query(Invoice).filter(Invoice.id == "INV-TEST-CONTROL-001").first()
    updated_apr = db.query(ApprovalRequest).filter(ApprovalRequest.id == "APR-TEST-CONTROL-001").first()
    assert updated_inv.status == "PENDING_APPROVAL"
    assert updated_apr.status == "PENDING"
    assert updated_inv.status != "APPROVED"
    assert updated_apr.status != "APPROVED"

    # Now explicit human approval can be granted
    action_res = client.post(
        f"/api/v1/approvals/APR-TEST-CONTROL-001/action",
        json={
            "action": "APPROVED",
            "comments": "Explicit human sign-off post resolution",
            "approved_by": "USR-002",
            "user_role": "AP_MANAGER"
        }
    )
    assert action_res.status_code == 200
    assert action_res.json()["status"] == "APPROVED"

    # Cleanup test records
    db.query(AuditLog).filter(AuditLog.entity_id.in_(["INV-TEST-CONTROL-001", "APR-TEST-CONTROL-001", "EXC-TEST-CONTROL-001"])).delete(synchronize_session=False)
    db.query(ExceptionRecord).filter(ExceptionRecord.id == "EXC-TEST-CONTROL-001").delete()
    db.query(ApprovalRequest).filter(ApprovalRequest.id == "APR-TEST-CONTROL-001").delete()
    db.query(Invoice).filter(Invoice.id == "INV-TEST-CONTROL-001").delete()
    db.commit()
    db.close()

def test_search_approvals_inv_2026_00452():
    """Requirement: Searching INV-2026-00452 returns only the target record and excludes unrelated invoices."""
    res = client.get("/api/v1/approvals?search=INV-2026-00452")
    assert res.status_code == 200
    results = res.json()
    assert len(results) == 1, f"Expected exactly 1 result for INV-2026-00452, got {len(results)}"
    item = results[0]
    assert item["invoice_id"] == "INV-2026-00452"
    assert item["id"] == "APR-2026-0092"
    assert item["match_status"] == "MISSING_PO"
    assert item["status"] == "HELD"
    assert item["amount_inr"] == 246620.0
    assert item["blocking_exceptions_count"] >= 1
    # Verify unrelated invoices are excluded
    assert not any(i["invoice_id"] in ["INV-2026-00470", "INV-2026-00471", "INV-2026-00472"] for i in results)

def test_search_valid_invoice_with_approval_record():
    """Requirement: Searching a valid invoice returns its linked approval record."""
    res = client.get("/api/v1/approvals?search=INV-2026-00467")
    assert res.status_code == 200
    results = res.json()
    assert len(results) >= 1
    assert all("INV-2026-00467" in r["invoice_id"] or "APR" in r["id"] for r in results)

def test_search_invoice_with_no_approval_record():
    """Requirement: Searching an invoice with no approval record returns an empty list (no fallback to mock data)."""
    res = client.get("/api/v1/approvals?search=INV-DOES-NOT-EXIST-99999")
    assert res.status_code == 200
    results = res.json()
    assert len(results) == 0, f"Expected 0 results for non-existent invoice, got {len(results)}"

def test_duplicate_invoice_approval_strictly_blocked():
    """Requirement: Invoices with DUPLICATE_INVOICE match status cannot be approved."""
    db = SessionLocal()
    from datetime import date
    dup_inv = Invoice(
        id="INV-TEST-DUP-001",
        vendor_id="VEND-001",
        invoice_date=date(2026, 3, 31),
        due_date=date(2026, 4, 30),
        vendor_gstin="27AABCS1429B1Z1",
        recipient_gstin="29AAACG0561F1Z8",
        place_of_supply="27",
        taxable_value_inr=Decimal("50000.00"),
        total_tax_inr=Decimal("9000.00"),
        total_amount_inr=Decimal("59000.00"),
        status="EXCEPTION_HOLD",
        match_status="DUPLICATE_INVOICE",
    )
    dup_apr = ApprovalRequest(
        id="APR-TEST-DUP-001",
        invoice_id="INV-TEST-DUP-001",
        required_role="AP_MANAGER",
        status="HELD",
        amount_inr=Decimal("59000.00")
    )
    dup_exc = ExceptionRecord(
        id="EXC-TEST-DUP-001",
        invoice_id="INV-TEST-DUP-001",
        category="DUPLICATE_INVOICE",
        severity="CRITICAL",
        expected_value="Original INV-2026-00100",
        actual_value="Duplicate INV-TEST-DUP-001",
        difference_value="59000.00",
        financial_impact_inr=Decimal("59000.00"),
        responsible_department="FINANCE",
        status="OPEN",
    )
    db.merge(dup_inv)
    db.merge(dup_apr)
    db.merge(dup_exc)
    db.commit()
    db.close()

    # Attempt to approve duplicate invoice must return HTTP 400
    action_res = client.post(
        "/api/v1/approvals/APR-TEST-DUP-001/action",
        json={"action": "APPROVED", "comments": "Attempting illegal duplicate approval", "user_role": "AP_MANAGER"},
    )
    assert action_res.status_code == 400
    detail = action_res.json()["detail"]
    assert "Financial Control Violation" in detail

    # Cleanup test records
    db = SessionLocal()
    db.query(AuditLog).filter(AuditLog.entity_id.in_(["INV-TEST-DUP-001", "APR-TEST-DUP-001", "EXC-TEST-DUP-001"])).delete(synchronize_session=False)
    db.query(ExceptionRecord).filter(ExceptionRecord.id == "EXC-TEST-DUP-001").delete()
    db.query(ApprovalRequest).filter(ApprovalRequest.id == "APR-TEST-DUP-001").delete()
    db.query(Invoice).filter(Invoice.id == "INV-TEST-DUP-001").delete()
    db.commit()
    db.close()

def test_preserve_approval_for_eligible_exact_matches():
    """Requirement: Invoices with EXACT_MATCH and 0 open exceptions can be cleanly approved."""
    res = client.get("/api/v1/approvals")
    assert res.status_code == 200
    approvals = res.json()
    eligible = [
        a for a in approvals
        if a.get("status") == "PENDING"
        and a.get("match_status") in ["EXACT_MATCH", "MATCH_WITHIN_TOLERANCE"]
        and a.get("blocking_exceptions_count", 0) == 0
        and a["amount_inr"] <= 1000000
    ]
    assert len(eligible) > 0, "Expected at least one eligible exact match pending approval"
    target = eligible[0]
    appr_res = client.post(
        f"/api/v1/approvals/{target['id']}/action",
        json={"action": "APPROVED", "comments": "Valid exact match approved by authorized manager", "user_role": "AP_MANAGER"},
    )
    assert appr_res.status_code == 200
    updated = appr_res.json()
    assert updated["status"] == "APPROVED"
