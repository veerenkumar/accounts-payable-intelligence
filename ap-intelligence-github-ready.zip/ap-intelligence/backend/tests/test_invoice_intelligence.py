import os
import io
import pytest
from PIL import Image
from fastapi.testclient import TestClient
from app.main import app
from app.document_processing.parser import DocumentParser
from app.document_processing.validator import InvoiceValidator
from app.database.session import SessionLocal
from app.models.financial_entities import Document, Invoice, InvoiceItem

client = TestClient(app)

@pytest.fixture
def sample_pdf_path():
    # Clean up any previous test invoice
    db = SessionLocal()
    db.query(InvoiceItem).filter(InvoiceItem.invoice_id == "INV-2026-90001").delete()
    db.query(Invoice).filter(Invoice.id == "INV-2026-90001").delete()
    db.commit()
    db.close()

    # Generate fresh synthetic test invoice with matching line items
    p = os.path.join(os.path.dirname(__file__), "test_new_invoice.pdf")
    from reportlab.lib.pagesizes import letter
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib import colors

    styles = getSampleStyleSheet()
    doc = SimpleDocTemplate(p, pagesize=letter)
    story = [
        Paragraph("<b>TAX INVOICE</b>", styles["Title"]),
        Spacer(1, 10),
        Paragraph("<b>Supplier:</b> Precision Tools & Dies Ltd", styles["Normal"]),
        Paragraph("<b>Supplier GSTIN:</b> 27AAACP5544J1Z8", styles["Normal"]),
        Paragraph("<b>Recipient:</b> Apex Bharat Manufacturing Pvt. Ltd.", styles["Normal"]),
        Paragraph("<b>Recipient GSTIN:</b> 27AABCA9876K1Z5", styles["Normal"]),
        Spacer(1, 10),
        Paragraph("<b>Invoice Number:</b> INV-2026-90001", styles["Normal"]),
        Paragraph("<b>PO Reference:</b> PO-2026-00101", styles["Normal"]),
        Paragraph("<b>Invoice Date:</b> 2026-11-01", styles["Normal"]),
        Paragraph("<b>Due Date:</b> 2026-12-01", styles["Normal"]),
        Spacer(1, 15),
    ]
    data = [
        ["Line", "Item Code", "Description", "HSN", "Qty", "Unit Rate (INR)", "Total (INR)"],
        ["1", "STL-BEAM-01", "Heavy Structural Steel Beams IS2062", "7216", "50.00", "4,180.00", "209,000.00"],
    ]
    t = Table(data, colWidths=[30, 90, 180, 50, 45, 85, 80])
    story.append(t)
    story.append(Spacer(1, 15))
    story.append(Paragraph("<b>Taxable Value:</b> INR 209,000.00", styles["Normal"]))
    story.append(Paragraph("<b>CGST (9%):</b> INR 18,810.00", styles["Normal"]))
    story.append(Paragraph("<b>SGST (9%):</b> INR 18,810.00", styles["Normal"]))
    story.append(Paragraph("<b>Total Invoice Amount:</b> INR 246,620.00", styles["Normal"]))
    doc.build(story)

    yield p
    if os.path.exists(p):
        os.remove(p)

@pytest.fixture
def sample_image_bytes():
    # Generate in-memory synthetic PNG invoice
    img = Image.new("RGB", (800, 1000), color=(255, 255, 255))
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return buf.getvalue()

def test_valid_pdf_invoice_upload(sample_pdf_path):
    with open(sample_pdf_path, "rb") as f:
        response = client.post(
            "/api/v1/documents/upload",
            files={"file": ("test_new_invoice.pdf", f, "application/pdf")},
        )
    assert response.status_code == 200
    data = response.json()
    assert "document_id" in data
    assert data["file_name"] == "test_new_invoice.pdf"
    assert data["extraction_confidence"] >= 0.85
    assert data["parsed_invoice"]["invoice_number"] == "INV-2026-90001"
    assert data["parsed_invoice"]["vendor_name"] == "Precision Tools & Dies Ltd"
    assert len(data["parsed_invoice"]["line_items"]) >= 1
    assert data["is_valid"] is True

def test_valid_image_invoice_upload(sample_image_bytes):
    response = client.post(
        "/api/v1/documents/upload",
        files={"file": ("scanned_invoice_sample.png", sample_image_bytes, "image/png")},
    )
    assert response.status_code == 200
    data = response.json()
    assert "document_id" in data
    assert data["file_name"] == "scanned_invoice_sample.png"
    assert data["requires_human_review"] is True  # Raster image requires human review

def test_invalid_file_format():
    fake_content = b"Binary executable content"
    response = client.post(
        "/api/v1/documents/upload",
        files={"file": ("malicious_payload.exe", fake_content, "application/octet-stream")},
    )
    assert response.status_code == 400
    assert "Unsupported file format" in response.json()["detail"]

def test_duplicate_invoice_rejection(sample_pdf_path):
    # Upload once
    with open(sample_pdf_path, "rb") as f:
        r1 = client.post(
            "/api/v1/documents/upload",
            files={"file": ("test_new_invoice.pdf", f, "application/pdf")},
        )
    assert r1.status_code == 200

    # Upload same invoice number again
    with open(sample_pdf_path, "rb") as f:
        res2 = client.post(
            "/api/v1/documents/upload",
            files={"file": ("test_new_invoice_copy.pdf", f, "application/pdf")},
        )
    assert res2.status_code == 200
    data = res2.json()
    assert data["workflow_status"] == "DUPLICATE_ALERT"
    assert data["is_valid"] is False
    assert any("Duplicate" in err for err in data["validation_errors"])

def test_validator_missing_invoice_number():
    bad_data = {
        "invoice_number": "",
        "invoice_date": "2026-11-01",
        "vendor_gstin": "27AAACT2727Q1ZW",
        "taxable_value": 10000.0,
        "total_amount": 11800.0,
    }
    val = InvoiceValidator.validate_invoice(bad_data)
    assert val["is_valid"] is False
    assert any("Missing mandatory field: Invoice Number" in err for err in val["errors"])

def test_validator_incorrect_gstin_format():
    bad_data = {
        "invoice_number": "INV-TEST-GST-01",
        "invoice_date": "2026-11-01",
        "vendor_gstin": "INVALID_GSTIN_123",  # Malformed
        "taxable_value": 10000.0,
        "total_amount": 11800.0,
    }
    val = InvoiceValidator.validate_invoice(bad_data)
    assert val["is_valid"] is False
    assert any("Invalid Supplier GSTIN" in err for err in val["errors"])

def test_validator_total_arithmetic_reconciliation_mismatch():
    mismatched_data = {
        "invoice_number": "INV-TEST-MATH-01",
        "invoice_date": "2026-11-01",
        "vendor_gstin": "27AAACT2727Q1ZW",
        "recipient_gstin": "27AABCA9876K1Z5",
        "taxable_value": 100000.0,
        "cgst_amount": 9000.0,
        "sgst_amount": 9000.0,
        "total_tax": 18000.0,
        "total_amount": 135000.0,  # Mismatch: 100000 + 18000 = 118000 != 135000
    }
    val = InvoiceValidator.validate_invoice(mismatched_data)
    assert val["is_valid"] is False
    assert val["discrepancy_amount_inr"] == 17000.0
    assert any("Invoice total reconciliation failed" in err for err in val["errors"])

def test_validator_low_ocr_confidence_requires_review():
    low_conf_data = {
        "invoice_number": "INV-TEST-LOW-01",
        "invoice_date": "2026-11-01",
        "vendor_gstin": "27AAACT2727Q1ZW",
        "taxable_value": 10000.0,
        "total_amount": 10000.0,
        "overall_confidence": 0.65,  # Below 0.85
    }
    val = InvoiceValidator.validate_invoice(low_conf_data)
    assert val["requires_human_review"] is True
    assert any("Low composite OCR extraction confidence" in w for w in val["warnings"])

def test_database_persistence_and_line_items():
    db = SessionLocal()
    try:
        # Query saved invoice from earlier test
        inv = db.query(Invoice).filter(Invoice.id == "INV-2026-90001").first()
        assert inv is not None
        assert inv.document_id is not None
        assert float(inv.total_amount_inr) == 246620.0

        # Verify Document persistence
        doc = db.query(Document).filter(Document.id == inv.document_id).first()
        assert doc is not None
        assert "test_new_invoice" in doc.file_name

        # Verify Line Items persistence
        items = db.query(InvoiceItem).filter(InvoiceItem.invoice_id == inv.id).all()
        assert len(items) >= 1
        assert items[0].item_code == "STL-BEAM-01"
        assert float(items[0].quantity) == 50.0
        assert float(items[0].unit_price_inr) == 4180.0
    finally:
        db.close()

def test_update_invoice_fields_and_validate():
    # Test PUT /api/v1/invoices/{id}
    update_payload = {
        "po_reference": "PO-2026-00101-AMENDED",
        "taxable_value_inr": 209000.0,
        "cgst_amount_inr": 18810.0,
        "sgst_amount_inr": 18810.0,
        "total_amount_inr": 246620.0,
        "items": [
            {
                "line_number": 1,
                "item_code": "STL-BEAM-01",
                "description": "Heavy Structural Steel Beams IS2062",
                "hsn_sac_code": "7216",
                "quantity": 50.0,
                "unit_price_inr": 4180.0,
                "gst_rate_percent": 18.0,
                "taxable_amount_inr": 209000.0,
                "total_line_amount_inr": 246620.0,
            }
        ],
    }
    response = client.put("/api/v1/invoices/INV-2026-90001", json=update_payload)
    assert response.status_code == 200
    updated = response.json()
    assert updated["po_reference"] == "PO-2026-00101-AMENDED"
    assert updated["status"] == "VERIFIED_VALID"

    # Test POST /api/v1/invoices/{id}/validate
    val_res = client.post("/api/v1/invoices/INV-2026-90001/validate")
    assert val_res.status_code == 200
    data = val_res.json()
    assert data["is_valid"] is True
    assert len(data["errors"]) == 0
