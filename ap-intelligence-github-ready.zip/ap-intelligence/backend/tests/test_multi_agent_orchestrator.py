import os
import pytest
from app.workflows.orchestrator import MultiAgentSupervisor

SAMPLE_DOCS_DIR = "/Users/veerenkumarkonchada/.gemini/antigravity/scratch/ap-intelligence/data/sample_documents"

def test_supervisor_workflow_success_tata_steel():
    pdf_path = os.path.join(SAMPLE_DOCS_DIR, "INV_2026_00452_TataSteel.pdf")
    assert os.path.exists(pdf_path)

    state = MultiAgentSupervisor.execute_invoice_workflow(
        pdf_path=pdf_path,
        po_master_db={"po_id": "PO-2026-00101", "vendor_id": "VEND-001", "status": "APPROVED"},
        grn_master_db={"grn_id": "GRN-2026-00085", "status": "ACCEPTED"},
    )

    assert state["workflow_status"] == "COMPLETED_APPROVED"
    assert state["is_matched"] is True
    assert state["matching_result"]["match_status"] == "EXACT_MATCH"
    assert state["assigned_approval_role"] == "AP_MANAGER"  # ₹2,46,620 falls in Manager bracket
    assert state["requires_human_approval"] is True
    assert state["risk_score"] < 50
    assert len(state["agent_trail"]) >= 6
    assert state["total_tokens_used"] > 0

def test_supervisor_workflow_success_schneider():
    pdf_path = os.path.join(SAMPLE_DOCS_DIR, "INV_2026_00454_Schneider.pdf")
    assert os.path.exists(pdf_path)

    state = MultiAgentSupervisor.execute_invoice_workflow(
        pdf_path=pdf_path,
        po_master_db={"po_id": "PO-2026-00108", "vendor_id": "VEND-007", "status": "APPROVED"},
        grn_master_db={"grn_id": "GRN-2026-00095", "status": "ACCEPTED"},
    )

    assert state["workflow_status"] == "COMPLETED_APPROVED"
    assert state["is_matched"] is True
    assert state["assigned_approval_role"] == "AP_MANAGER"  # ₹5,66,400 falls in Manager bracket
    assert state["requires_human_approval"] is True

def test_supervisor_workflow_duplicate_exception_branch():
    pdf_path = os.path.join(SAMPLE_DOCS_DIR, "INV_2026_00452_TataSteel.pdf")
    assert os.path.exists(pdf_path)

    # Force duplicate flag to test Agent 5 and Agent 6 routing
    state = MultiAgentSupervisor.execute_invoice_workflow(
        pdf_path=pdf_path,
        po_master_db={"po_id": "PO-2026-00101", "vendor_id": "VEND-001", "status": "APPROVED"},
        grn_master_db={"grn_id": "GRN-2026-00085", "status": "ACCEPTED"},
        is_duplicate=True,
    )

    assert state["workflow_status"] == "COMPLETED_EXCEPTION_HOLD"
    assert state["is_matched"] is False
    assert state["risk_score"] >= 75
    assert state["exception_ticket"] is not None
    assert "DUPLICATE" in state["exception_ticket"]["category"]
    assert any(a["agent"] == "Exception Resolution Agent" for a in state["agent_trail"])

