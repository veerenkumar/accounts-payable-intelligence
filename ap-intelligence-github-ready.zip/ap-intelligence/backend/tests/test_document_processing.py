import os
import pytest
from app.document_processing.gst_validator import GSTValidator
from app.document_processing.parser import DocumentParser

SAMPLE_DOCS_DIR = "/Users/veerenkumarkonchada/.gemini/antigravity/scratch/ap-intelligence/data/sample_documents"

def test_gstin_format_valid():
    valid_gstin = "27AAACT2727Q1ZW"
    result = GSTValidator.validate_format(valid_gstin)
    assert result["is_valid"] is True
    assert result["state_code"] == "27"
    assert result["state_name"] == "Maharashtra"
    assert result["pan"] == "AAACT2727Q"

def test_gstin_format_invalid():
    invalid_gstin = "INVALID12345"
    result = GSTValidator.validate_format(invalid_gstin)
    assert result["is_valid"] is False
    assert "error" in result

def test_gst_tax_applicability():
    # Intra-state (Both Maharashtra 27)
    assert GSTValidator.determine_tax_applicability("27", "27") == "INTRA_STATE"
    # Inter-state (Karnataka 29 to Maharashtra 27)
    assert GSTValidator.determine_tax_applicability("29", "27") == "INTER_STATE"

def test_pdf_extraction_tata_steel():
    pdf_path = os.path.join(SAMPLE_DOCS_DIR, "INV_2026_00452_TataSteel.pdf")
    assert os.path.exists(pdf_path), "Sample PDF must exist"

    text = DocumentParser.extract_text_from_pdf(pdf_path)
    assert "INV-2026-00452" in text
    assert "27AAACT2727Q1ZW" in text

    parsed = DocumentParser.parse_invoice(text)
    assert parsed["invoice_number"] == "INV-2026-00452"
    assert parsed["po_reference"] == "PO-2026-00101"
    assert parsed["vendor_gstin"] == "27AAACT2727Q1ZW"
    assert parsed["taxable_value"] == 209000.0
    assert parsed["total_amount"] == 246620.0
    assert parsed["overall_confidence"] >= 0.90

def test_pdf_extraction_schneider():
    pdf_path = os.path.join(SAMPLE_DOCS_DIR, "INV_2026_00454_Schneider.pdf")
    assert os.path.exists(pdf_path), "Sample PDF must exist"

    text = DocumentParser.extract_text_from_pdf(pdf_path)
    parsed = DocumentParser.parse_invoice(text)
    assert parsed["invoice_number"] == "INV-2026-00454"
    assert parsed["po_reference"] == "PO-2026-00108"
    assert parsed["vendor_gstin"] == "29AAACS6328P1Z3"
    assert parsed["igst_amount"] == 86400.0
    assert parsed["total_amount"] == 566400.0

def test_document_inspection_api_returns_ocr_text_and_parsed_fields():
    """Requirement: Verify inspection API returns stored OCR text and structured invoice fields."""
    from fastapi.testclient import TestClient
    from app.main import app

    client = TestClient(app)
    response = client.get("/api/v1/documents")
    assert response.status_code == 200
    docs = response.json()
    assert len(docs) > 0

    tata_doc = next((d for d in docs if "TataSteel" in d.get("file_name", "")), None)
    assert tata_doc is not None, "INV_2026_00452_TataSteel.pdf must exist in documents queue"

    # 1. OCR text must be non-empty and accessible
    assert "ocr_raw_text" in tata_doc
    ocr_text = tata_doc["ocr_raw_text"]
    assert ocr_text is not None and len(ocr_text) > 0
    assert "INV-2026-00452" in ocr_text
    assert "Tata Steel Products Ltd." in ocr_text
    assert "27AAACT2727Q1ZW" in ocr_text

    # 2. Structured parsed invoice fields must be populated
    parsed = tata_doc.get("parsed_invoice")
    assert parsed is not None, "Parsed invoice attributes must be present"
    assert parsed["invoice_number"] == "INV-2026-00452"
    assert parsed["vendor_name"] == "Tata Steel Products Ltd."
    assert parsed["vendor_gstin"] == "27AAACT2727Q1ZW"
    assert parsed["invoice_date"] == "2026-11-01"
    assert parsed["taxable_value"] == 209000.0
    assert parsed["cgst_amount"] == 18810.0
    assert parsed["sgst_amount"] == 18810.0
    assert parsed["igst_amount"] == 0.0
    assert parsed["total_amount"] == 246620.0
    assert parsed["overall_confidence"] >= 0.95

    # 3. Individual document inspection endpoint /documents/{doc_id}
    single_res = client.get(f"/api/v1/documents/{tata_doc['id']}")
    assert single_res.status_code == 200
    single_data = single_res.json()
    assert single_data["ocr_raw_text"] == ocr_text
    assert single_data["parsed_invoice"]["invoice_number"] == "INV-2026-00452"

def test_scanned_image_inspection_and_honest_confidence():
    """Requirement: Scanned image OCR returns honest confidence and does not fabricate fields."""
    parsed = DocumentParser.parse_invoice(text="", is_scanned_image=True)
    assert parsed["overall_confidence"] <= 0.70
    assert parsed["invoice_number"] is None
    assert parsed["vendor_name"] is None
    assert parsed["vendor_gstin"] is None
    assert parsed["total_amount"] == 0.0

def test_missing_ocr_text_fallback_handling():
    """Requirement: Parser gracefully handles missing or empty text stream without fabrication."""
    parsed = DocumentParser.parse_invoice(text="")
    assert parsed["invoice_number"] is None
    assert parsed["vendor_gstin"] is None
    assert parsed["total_amount"] == 0.0


