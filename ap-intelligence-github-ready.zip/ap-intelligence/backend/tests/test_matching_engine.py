from decimal import Decimal
import pytest
from app.matching.engine import (
    DeterministicMatchingEngine,
    MatchingInput,
    LineItemData,
)

def make_sample_items(qty: str, price: str) -> list[LineItemData]:
    q = Decimal(qty)
    p = Decimal(price)
    taxable = q * p
    tax = taxable * Decimal("0.18")
    return [
        LineItemData(
            item_code="STL-BEAM-01",
            description="Structural Steel Beams",
            quantity=q,
            unit_price=p,
            gst_rate=Decimal("18.0"),
            taxable_amount=taxable,
            total_amount=taxable + tax,
        )
    ]

# Scenario 1: Exact 3-Way Match
def test_scenario_exact_match():
    inp = MatchingInput(
        invoice_id="INV-2026-00454",
        vendor_id="VEND-007",
        po_reference="PO-2026-00108",
        invoice_items=make_sample_items("4.0", "120000.0"),
        invoice_total_taxable=Decimal("480000.0"),
        invoice_total_tax=Decimal("86400.0"),
        invoice_total_amount=Decimal("566400.0"),
        po_id="PO-2026-00108",
        po_vendor_id="VEND-007",
        po_items=make_sample_items("4.0", "120000.0"),
        grn_id="GRN-2026-00095",
        grn_items={"STL-BEAM-01": Decimal("4.0")},
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.is_matched is True
    assert res.match_status == "EXACT_MATCH"
    assert res.total_financial_impact_inr == Decimal("0.00")
    assert len(res.discrepancies) == 0

# Scenario 2: Match Within Tolerance (Price +0.48% within 2.0% limit)
def test_scenario_within_tolerance():
    inv_items = make_sample_items("50.0", "4200.0")  # Price 4200 vs PO 4180 (+0.48%)
    po_items = make_sample_items("50.0", "4180.0")
    inp = MatchingInput(
        invoice_id="INV-2026-00452",
        vendor_id="VEND-001",
        po_reference="PO-2026-00101",
        invoice_items=inv_items,
        invoice_total_taxable=Decimal("210000.0"),
        invoice_total_tax=Decimal("37800.0"),
        invoice_total_amount=Decimal("247800.0"),
        po_id="PO-2026-00101",
        po_vendor_id="VEND-001",
        po_items=po_items,
        grn_id="GRN-2026-00085",
        grn_items={"STL-BEAM-01": Decimal("50.0")},
        price_tolerance_pct=Decimal("2.0"),
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.is_matched is True
    assert res.match_status == "MATCH_WITHIN_TOLERANCE"
    assert res.total_financial_impact_inr == Decimal("0.00")

# Scenario 3: Price Mismatch (Price +8.97% exceeds 2.0% limit)
def test_scenario_price_mismatch():
    inv_items = make_sample_items("10.0", "8500.0")
    po_items = make_sample_items("10.0", "7800.0")
    inp = MatchingInput(
        invoice_id="INV-2026-00453",
        vendor_id="VEND-004",
        po_reference="PO-2026-00104",
        invoice_items=inv_items,
        invoice_total_taxable=Decimal("85000.0"),
        invoice_total_tax=Decimal("15300.0"),
        invoice_total_amount=Decimal("100300.0"),
        po_id="PO-2026-00104",
        po_vendor_id="VEND-004",
        po_items=po_items,
        grn_id="GRN-2026-00088",
        grn_items={"STL-BEAM-01": Decimal("10.0")},
        price_tolerance_pct=Decimal("2.0"),
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.is_matched is False
    assert res.match_status == "PRICE_MISMATCH"
    assert res.total_financial_impact_inr == Decimal("7000.00")  # (8500-7800)*10
    assert len(res.discrepancies) == 1

# Scenario 4: Quantity Mismatch (Billed 15 vs GRN Accepted 10)
def test_scenario_quantity_mismatch():
    inv_items = make_sample_items("15.0", "1000.0")
    po_items = make_sample_items("15.0", "1000.0")
    inp = MatchingInput(
        invoice_id="INV-2026-00455",
        vendor_id="VEND-005",
        po_reference="PO-2026-00112",
        invoice_items=inv_items,
        invoice_total_taxable=Decimal("15000.0"),
        invoice_total_tax=Decimal("2700.0"),
        invoice_total_amount=Decimal("17700.0"),
        po_id="PO-2026-00112",
        po_vendor_id="VEND-005",
        po_items=po_items,
        grn_id="GRN-2026-00099",
        grn_items={"STL-BEAM-01": Decimal("10.0")},  # Only 10 accepted
        qty_tolerance_pct=Decimal("0.0"),
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.is_matched is False
    assert res.match_status == "QUANTITY_MISMATCH"
    assert res.total_financial_impact_inr == Decimal("5000.00")  # (15-10)*1000

# Scenario 5: Missing PO Reference
def test_scenario_missing_po():
    inp = MatchingInput(
        invoice_id="INV-2026-00456",
        vendor_id="VEND-006",
        po_reference=None,
        invoice_items=make_sample_items("5.0", "5000.0"),
        invoice_total_taxable=Decimal("25000.0"),
        invoice_total_tax=Decimal("4500.0"),
        invoice_total_amount=Decimal("29500.0"),
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.is_matched is False
    assert res.match_status == "MISSING_PO"
    assert res.total_financial_impact_inr == Decimal("29500.0")

# Scenario 6: Missing GRN
def test_scenario_missing_grn():
    inp = MatchingInput(
        invoice_id="INV-2026-00457",
        vendor_id="VEND-001",
        po_reference="PO-2026-00101",
        invoice_items=make_sample_items("10.0", "4180.0"),
        invoice_total_taxable=Decimal("41800.0"),
        invoice_total_tax=Decimal("7524.0"),
        invoice_total_amount=Decimal("49324.0"),
        po_id="PO-2026-00101",
        po_vendor_id="VEND-001",
        po_items=make_sample_items("10.0", "4180.0"),
        grn_id=None,
        grn_items={},
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.is_matched is False
    assert res.match_status == "MISSING_GRN"

# Scenario 7: Vendor Mismatch
def test_scenario_vendor_mismatch():
    inp = MatchingInput(
        invoice_id="INV-2026-00458",
        vendor_id="VEND-FRAUD-09",
        po_reference="PO-2026-00101",
        invoice_items=make_sample_items("10.0", "4180.0"),
        invoice_total_taxable=Decimal("41800.0"),
        invoice_total_tax=Decimal("7524.0"),
        invoice_total_amount=Decimal("49324.0"),
        po_id="PO-2026-00101",
        po_vendor_id="VEND-001",  # Legitimate vendor
        po_items=make_sample_items("10.0", "4180.0"),
        grn_id="GRN-01",
        grn_items={"STL-BEAM-01": Decimal("10.0")},
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.is_matched is False
    assert res.match_status == "VENDOR_MISMATCH"

# Scenario 8: Duplicate Invoice Detection
def test_scenario_duplicate_invoice():
    inp = MatchingInput(
        invoice_id="INV-2026-00452",
        vendor_id="VEND-001",
        po_reference="PO-2026-00101",
        invoice_items=make_sample_items("50.0", "4180.0"),
        invoice_total_taxable=Decimal("209000.0"),
        invoice_total_tax=Decimal("37620.0"),
        invoice_total_amount=Decimal("246620.0"),
        po_id="PO-2026-00101",
        po_vendor_id="VEND-001",
        po_items=make_sample_items("50.0", "4180.0"),
        grn_id="GRN-2026-00085",
        grn_items={"STL-BEAM-01": Decimal("50.0")},
        is_duplicate_invoice=True,
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.is_matched is False
    assert res.match_status == "DUPLICATE_INVOICE"

