import pytest
from decimal import Decimal
from fastapi.testclient import TestClient
from app.main import app
from app.database.session import SessionLocal
from app.models.financial_entities import (
    Invoice,
    InvoiceItem,
    PurchaseOrder,
    POItem,
    GoodsReceiptNote,
    GRNItem,
    MatchingResult,
    ExceptionRecord,
    ApprovalRequest,
    Vendor,
)
from app.matching.engine import (
    DeterministicMatchingEngine,
    MatchingInput,
    LineItemData,
)
from app.matching.service import MatchingService

client = TestClient(app)

def make_item(code: str, desc: str, qty: str, price: str, gst: str = "18.0") -> LineItemData:
    q = Decimal(qty)
    p = Decimal(price)
    g = Decimal(gst)
    taxable = q * p
    tax = (taxable * (g / Decimal("100"))).quantize(Decimal("0.01"))
    return LineItemData(
        item_code=code,
        description=desc,
        quantity=q,
        unit_price=p,
        gst_rate=g,
        taxable_amount=taxable,
        total_amount=taxable + tax,
    )

# 1. Exact Match
def test_scenario_01_exact_match():
    item = make_item("STL-BEAM-01", "Heavy Structural Steel Beams", "50.0", "4180.0")
    inp = MatchingInput(
        invoice_id="INV-TEST-001",
        vendor_id="VEND-001",
        po_reference="PO-2026-00101",
        invoice_items=[item],
        invoice_total_taxable=item.taxable_amount,
        invoice_total_tax=item.total_amount - item.taxable_amount,
        invoice_total_amount=item.total_amount,
        po_id="PO-2026-00101",
        po_vendor_id="VEND-001",
        po_items=[item],
        grn_id="GRN-2026-00081",
        grn_items={"STL-BEAM-01": Decimal("50.0")},
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.is_matched is True
    assert res.match_status == "EXACT_MATCH"
    assert res.total_financial_impact_inr == Decimal("0.00")
    assert len(res.discrepancies) == 0

# 2. Within-Tolerance Match (Price +1.2% <= 2.0% policy)
def test_scenario_02_within_tolerance():
    inv_item = make_item("VALVE-GATE-04", "Industrial Gate Valve", "10.0", "15180.0") # +1.2% over 15000
    po_item = make_item("VALVE-GATE-04", "Industrial Gate Valve", "10.0", "15000.0")
    inp = MatchingInput(
        invoice_id="INV-TEST-002",
        vendor_id="VEND-002",
        po_reference="PO-2026-00102",
        invoice_items=[inv_item],
        invoice_total_taxable=inv_item.taxable_amount,
        invoice_total_tax=inv_item.total_amount - inv_item.taxable_amount,
        invoice_total_amount=inv_item.total_amount,
        po_id="PO-2026-00102",
        po_vendor_id="VEND-002",
        po_items=[po_item],
        grn_id="GRN-2026-00082",
        grn_items={"VALVE-GATE-04": Decimal("10.0")},
        price_tolerance_pct=Decimal("2.0"),
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.is_matched is True
    assert res.match_status == "MATCH_WITHIN_TOLERANCE"
    assert res.total_price_variance_pct == Decimal("1.20")
    assert res.line_evaluations[0].status == "TOLERANCE_PASSED"

# 3. Price Mismatch (Price +6.0% > 2.0% limit)
def test_scenario_03_price_mismatch():
    inv_item = make_item("ELEC-TRANS-01", "33kV Power Transformer", "2.0", "1590000.0") # +6% over 1500000
    po_item = make_item("ELEC-TRANS-01", "33kV Power Transformer", "2.0", "1500000.0")
    inp = MatchingInput(
        invoice_id="INV-TEST-003",
        vendor_id="VEND-003",
        po_reference="PO-2026-00103",
        invoice_items=[inv_item],
        invoice_total_taxable=inv_item.taxable_amount,
        invoice_total_tax=inv_item.total_amount - inv_item.taxable_amount,
        invoice_total_amount=inv_item.total_amount,
        po_id="PO-2026-00103",
        po_vendor_id="VEND-003",
        po_items=[po_item],
        grn_id="GRN-2026-00083",
        grn_items={"ELEC-TRANS-01": Decimal("2.0")},
        price_tolerance_pct=Decimal("2.0"),
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.is_matched is False
    assert res.match_status == "PRICE_MISMATCH"
    assert res.total_financial_impact_inr == Decimal("180000.00") # (1590000 - 1500000) * 2

# 4. Quantity Mismatch (Billed 25 > Accepted 20)
def test_scenario_04_quantity_mismatch():
    inv_item = make_item("PIPE-SEAM-02", "Seamless Carbon Steel Pipe", "25.0", "3400.0")
    po_item = make_item("PIPE-SEAM-02", "Seamless Carbon Steel Pipe", "25.0", "3400.0")
    inp = MatchingInput(
        invoice_id="INV-TEST-004",
        vendor_id="VEND-004",
        po_reference="PO-2026-00104",
        invoice_items=[inv_item],
        invoice_total_taxable=inv_item.taxable_amount,
        invoice_total_tax=inv_item.total_amount - inv_item.taxable_amount,
        invoice_total_amount=inv_item.total_amount,
        po_id="PO-2026-00104",
        po_vendor_id="VEND-004",
        po_items=[po_item],
        grn_id="GRN-2026-00084",
        grn_items={"PIPE-SEAM-02": Decimal("20.0")}, # Warehouse only accepted 20
        qty_tolerance_pct=Decimal("0.0"),
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.is_matched is False
    assert res.match_status == "QUANTITY_MISMATCH"
    assert res.total_financial_impact_inr == Decimal("17000.00") # (25 - 20) * 3400

# 5. Partial Receipt (PO 100, GRN accepted 40, Invoice bills 40)
def test_scenario_05_partial_receipt():
    inv_item = make_item("FAST-BOLT-08", "High Tensile Flange Bolts", "40.0", "250.0")
    po_item = make_item("FAST-BOLT-08", "High Tensile Flange Bolts", "100.0", "250.0")
    inp = MatchingInput(
        invoice_id="INV-TEST-005",
        vendor_id="VEND-005",
        po_reference="PO-2026-00105",
        invoice_items=[inv_item],
        invoice_total_taxable=inv_item.taxable_amount,
        invoice_total_tax=inv_item.total_amount - inv_item.taxable_amount,
        invoice_total_amount=inv_item.total_amount,
        po_id="PO-2026-00105",
        po_vendor_id="VEND-005",
        po_items=[po_item],
        grn_id="GRN-2026-00085",
        grn_items={"FAST-BOLT-08": Decimal("40.0")},
        classify_partial_receipt=True,
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.is_matched is True
    assert res.match_status == "PARTIAL_RECEIPT"
    assert res.total_financial_impact_inr == Decimal("0.00")

# 6. Multiple GRNs against one PO (GRN 1: 30 units, GRN 2: 20 units -> Total 50 units)
def test_scenario_06_multiple_grns_aggregation():
    # Multi-GRN aggregation combines accepted quantities from multiple delivery receipts
    grn_items_combined = {"PUMP-SUB-03": Decimal("30.0") + Decimal("20.0")} # 50.0 accepted
    inv_item = make_item("PUMP-SUB-03", "Submersible Dewatering Pump", "50.0", "12500.0")
    po_item = make_item("PUMP-SUB-03", "Submersible Dewatering Pump", "50.0", "12500.0")
    inp = MatchingInput(
        invoice_id="INV-TEST-006",
        vendor_id="VEND-006",
        po_reference="PO-2026-00106",
        invoice_items=[inv_item],
        invoice_total_taxable=inv_item.taxable_amount,
        invoice_total_tax=inv_item.total_amount - inv_item.taxable_amount,
        invoice_total_amount=inv_item.total_amount,
        po_id="PO-2026-00106",
        po_vendor_id="VEND-006",
        po_items=[po_item],
        grn_id="GRN-2026-00086-A, GRN-2026-00086-B",
        grn_items=grn_items_combined,
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.is_matched is True
    assert res.match_status == "EXACT_MATCH"
    assert res.line_evaluations[0].grn_accepted_qty == Decimal("50.0")

# 7. Tax Discrepancy (> ₹5.00 statutory tolerance)
def test_scenario_07_tax_discrepancy():
    inv_item = make_item("CHEM-RESIN-01", "Industrial Epoxy Resin", "10.0", "5000.0", gst="18.0")
    po_item = make_item("CHEM-RESIN-01", "Industrial Epoxy Resin", "10.0", "5000.0", gst="18.0")
    # Expected tax = 50000 * 0.18 = 9000. Invoice charges 9500 (diff = 500 > 5.0)
    inp = MatchingInput(
        invoice_id="INV-TEST-007",
        vendor_id="VEND-007",
        po_reference="PO-2026-00107",
        invoice_items=[inv_item],
        invoice_total_taxable=inv_item.taxable_amount,
        invoice_total_tax=Decimal("9500.00"),
        invoice_total_amount=Decimal("59500.00"),
        po_id="PO-2026-00107",
        po_vendor_id="VEND-007",
        po_items=[po_item],
        grn_id="GRN-2026-00087",
        grn_items={"CHEM-RESIN-01": Decimal("10.0")},
        tax_tolerance_inr=Decimal("5.0"),
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.is_matched is False
    assert res.match_status == "TAX_MISMATCH"
    assert res.total_tax_variance_inr == Decimal("500.00")
    assert "Tax discrepancy of ₹500.00" in res.evaluation_notes

# 8. Missing Purchase Order Reference
def test_scenario_08_missing_po():
    inv_item = make_item("SERV-CONS-01", "Engineering Consulting Services", "1.0", "75000.0")
    inp = MatchingInput(
        invoice_id="INV-TEST-008",
        vendor_id="VEND-008",
        po_reference=None,
        invoice_items=[inv_item],
        invoice_total_taxable=inv_item.taxable_amount,
        invoice_total_tax=inv_item.total_amount - inv_item.taxable_amount,
        invoice_total_amount=inv_item.total_amount,
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.is_matched is False
    assert res.match_status == "MISSING_PO"

# 9. Missing Goods Receipt Note
def test_scenario_09_missing_grn():
    inv_item = make_item("ELEC-MOTOR-05", "50HP Induction Motor", "5.0", "42000.0")
    po_item = make_item("ELEC-MOTOR-05", "50HP Induction Motor", "5.0", "42000.0")
    inp = MatchingInput(
        invoice_id="INV-TEST-009",
        vendor_id="VEND-009",
        po_reference="PO-2026-00109",
        invoice_items=[inv_item],
        invoice_total_taxable=inv_item.taxable_amount,
        invoice_total_tax=inv_item.total_amount - inv_item.taxable_amount,
        invoice_total_amount=inv_item.total_amount,
        po_id="PO-2026-00109",
        po_vendor_id="VEND-009",
        po_items=[po_item],
        grn_id=None,
        grn_items={},
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.is_matched is False
    assert res.match_status == "MISSING_GRN"

# 10. Duplicate Invoice Alert
def test_scenario_10_duplicate_invoice():
    inv_item = make_item("PUMP-SEAL-01", "Mechanical Shaft Seal", "4.0", "8500.0")
    po_item = make_item("PUMP-SEAL-01", "Mechanical Shaft Seal", "4.0", "8500.0")
    inp = MatchingInput(
        invoice_id="INV-TEST-010",
        vendor_id="VEND-010",
        po_reference="PO-2026-00110",
        invoice_items=[inv_item],
        invoice_total_taxable=inv_item.taxable_amount,
        invoice_total_tax=inv_item.total_amount - inv_item.taxable_amount,
        invoice_total_amount=inv_item.total_amount,
        po_id="PO-2026-00110",
        po_vendor_id="VEND-010",
        po_items=[po_item],
        grn_id="GRN-2026-00090",
        grn_items={"PUMP-SEAL-01": Decimal("4.0")},
        is_duplicate_invoice=True,
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.is_matched is False
    assert res.match_status == "DUPLICATE_INVOICE"

# 11. Database Integration & API Persistence Test (INV-2026-00467 Exact Match)
def test_database_evaluate_matching_exact_match():
    response = client.post("/api/v1/matching/evaluate/INV-2026-00467")
    assert response.status_code == 200
    data = response.json()
    assert data["invoice_id"] == "INV-2026-00467"
    assert data["match_status"] in ["EXACT_MATCH", "MATCH_WITHIN_TOLERANCE"]
    assert data["is_matched"] is True

    # Verify SQLite DB state
    db = SessionLocal()
    inv = db.query(Invoice).filter(Invoice.id == "INV-2026-00467").first()
    assert inv.status == "PENDING_APPROVAL" # Human approval gate
    assert inv.payment_status == "UNPAID" # Zero automatic payment guarantee

    # Verify ApprovalRequest created
    apr = db.query(ApprovalRequest).filter(ApprovalRequest.invoice_id == "INV-2026-00467").first()
    assert apr is not None
    assert apr.status == "PENDING"
    db.close()

# 12. Database Integration & Exception Routing Test (INV-2026-00453 Price Mismatch)
def test_database_evaluate_matching_price_mismatch_exception():
    response = client.post("/api/v1/matching/evaluate/INV-2026-00453")
    assert response.status_code == 200
    data = response.json()
    assert data["invoice_id"] == "INV-2026-00453"
    assert data["match_status"] == "PRICE_MISMATCH"
    assert data["is_matched"] is False

    # Verify SQLite DB state
    db = SessionLocal()
    inv = db.query(Invoice).filter(Invoice.id == "INV-2026-00453").first()
    assert inv.status == "EXCEPTION_HOLD"

    # Verify ExceptionRecord created in SQLite exceptions table
    exc = db.query(ExceptionRecord).filter(ExceptionRecord.invoice_id == "INV-2026-00453").order_by(ExceptionRecord.created_at.desc()).first()
    assert exc is not None
    assert exc.category == "PRICE_MISMATCH"
    assert exc.status == "OPEN"
    db.close()

# 13. Triangulation Detail Endpoint Verification
def test_get_triangulation_detail_endpoint():
    response = client.get("/api/v1/matching/INV-2026-00451")
    assert response.status_code == 200
    data = response.json()
    assert "invoice" in data
    assert "purchase_order" in data
    assert "goods_receipt_notes" in data
    assert "matching_result" in data
    assert data["invoice"]["id"] == "INV-2026-00451"
