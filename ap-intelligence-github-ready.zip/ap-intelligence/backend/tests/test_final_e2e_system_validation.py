import pytest
from decimal import Decimal
from fastapi.testclient import TestClient
from app.main import app
from app.database.session import SessionLocal
from app.models.financial_entities import Invoice, InvoiceItem, PurchaseOrder, GoodsReceiptNote, MatchingResult, ExceptionRecord, ApprovalRequest, AuditLog, Vendor

client = TestClient(app)

def test_e2e_successful_match_workflow():
    """
    Task 3 & 4: Test complete workflow for a legitimate 3-way match:
    Invoice -> PO -> GRN -> Matching Engine -> Approval Center.
    Verifies INV-2026-00451 (Tata Steel IS2062 Beams).
    """
    db = SessionLocal()
    try:
        inv = db.query(Invoice).filter(Invoice.id == "INV-2026-00451").first()
        assert inv is not None
        assert inv.vendor_id == "VEND-001"
        assert inv.po_reference == "PO-2026-00101"
        assert inv.status == "APPROVED"
        assert inv.match_status == "EXACT_MATCH"

        # Verify PO
        po = db.query(PurchaseOrder).filter(PurchaseOrder.id == inv.po_reference).first()
        assert po is not None
        assert po.vendor_id == inv.vendor_id
        assert po.total_amount_inr == inv.total_amount_inr

        # Verify GRN
        grn = db.query(GoodsReceiptNote).filter(GoodsReceiptNote.po_id == po.id).first()
        assert grn is not None
        assert grn.status == "ACCEPTED"

        # Verify Triangulation Detail API
        res = client.get("/api/v1/matching/INV-2026-00451")
        assert res.status_code == 200
        tri = res.json()
        assert tri["invoice"]["match_status"] == "EXACT_MATCH"
        assert tri["invoice"]["id"] == "INV-2026-00451"
        assert tri["purchase_order"]["id"] == "PO-2026-00101"
        assert len(tri["goods_receipt_notes"]) >= 1

    finally:
        db.close()

def test_e2e_exception_workflow_held_approval():
    """
    Task 3 & 4: Test complete workflow for an exception invoice:
    INV-2026-00452 has MISSING_PO, EXCEPTION_HOLD, and open Exception.
    Ensures human approval is strictly prevented.
    """
    db = SessionLocal()
    try:
        inv = db.query(Invoice).filter(Invoice.id == "INV-2026-00452").first()
        assert inv is not None
        assert inv.status == "EXCEPTION_HOLD"
        assert inv.match_status == "MISSING_PO"
        assert inv.payment_status == "UNPAID"

        # Verify open ExceptionRecord
        exc = db.query(ExceptionRecord).filter(ExceptionRecord.invoice_id == "INV-2026-00452").first()
        assert exc is not None
        assert exc.category == "MISSING_PO"
        assert exc.status == "OPEN"
        assert float(exc.financial_impact_inr) == 246620.0

        # Verify Approval Request is HELD
        appr = db.query(ApprovalRequest).filter(ApprovalRequest.invoice_id == "INV-2026-00452").first()
        assert appr is not None
        assert appr.status == "HELD"

        # Verify Attempt to Approve is rejected with HTTP 400
        payload = {
            "action": "APPROVED",
            "comments": "Attempting illegal bypass of MISSING_PO control"
        }
        res = client.post(f"/api/v1/approvals/{appr.id}/action?user_role=CFO", json=payload)
        assert res.status_code == 400
        assert "EXCEPTION_HOLD" in res.json()["detail"] or "Financial Control Violation" in res.json()["detail"]

    finally:
        db.close()

def test_financial_gst_arithmetic_consistency():
    """
    Task 5: Verify financial arithmetic and GST math across all invoice records.
    1. total_tax = cgst + sgst + igst
    2. total_amount = taxable_value + total_tax
    3. Intra-state vs Inter-state tax rules
    """
    db = SessionLocal()
    try:
        invoices = db.query(Invoice).all()
        assert len(invoices) >= 20

        for inv in invoices:
            cgst = float(inv.cgst_amount_inr or 0)
            sgst = float(inv.sgst_amount_inr or 0)
            igst = float(inv.igst_amount_inr or 0)
            total_tax = float(inv.total_tax_inr or 0)
            taxable = float(inv.taxable_value_inr or 0)
            grand_total = float(inv.total_amount_inr or 0)

            # GST Tax Component Sum
            assert abs((cgst + sgst + igst) - total_tax) < 0.05, f"Tax mismatch on {inv.id}"

            # Grand Total Math
            assert abs((taxable + total_tax) - grand_total) < 0.05, f"Grand total mismatch on {inv.id}"

            # Intra-State vs Inter-State GST Rule Check
            vendor = db.query(Vendor).filter(Vendor.id == inv.vendor_id).first()
            if vendor and vendor.state_code == inv.place_of_supply:
                # Intra-state: CGST + SGST (no IGST)
                assert igst == 0.0, f"Expected 0 IGST for intra-state on {inv.id}"
            elif vendor and vendor.state_code != inv.place_of_supply:
                # Inter-state: IGST only
                assert cgst == 0.0 and sgst == 0.0, f"Expected 0 CGST/SGST for inter-state on {inv.id}"

    finally:
        db.close()

def test_dashboard_kpis_exact_match_with_database():
    """
    Task 5: Verify dashboard KPIs API response matches actual database truth.
    """
    db = SessionLocal()
    try:
        res = client.get("/api/v1/analytics/dashboard")
        assert res.status_code == 200
        kpis = res.json()

        total_invoices_db = db.query(Invoice).count()
        assert kpis["total_invoices_processed"] == total_invoices_db

        open_exceptions_db = db.query(ExceptionRecord).filter(ExceptionRecord.status == "OPEN").count()
        assert kpis["exception_count"] == open_exceptions_db

        pending_approvals_db = db.query(ApprovalRequest).filter(ApprovalRequest.status == "PENDING").count()
        assert kpis["pending_approvals_count"] == pending_approvals_db

    finally:
        db.close()

def test_rbac_authorization_matrix():
    """
    Task 6: Test role-based access control across restricted finance endpoints:
    1. OCR Reconciliation: Junior clerk -> 403 Forbidden
    2. Large Amount Approval: Finance Executive exceeding approval ceiling -> 403 Forbidden
    """
    # 1. OCR Reconciliation Role Gate
    res_unauth = client.post(
        "/api/v1/invoices/INV-2026-00452/reconcile-ocr",
        json={"confirmed_by": "USR-CLERK", "user_role": "JUNIOR_CLERK", "comments": "Illegal"}
    )
    assert res_unauth.status_code == 403

    # 2. DOA Approval Limit Gate
    # Finance Executive ceiling is 100,000 INR. Attempting to approve >100,000 should be rejected
    db = SessionLocal()
    try:
        high_val_appr = db.query(ApprovalRequest).filter(
            ApprovalRequest.amount_inr > Decimal("100000.00"),
            ApprovalRequest.status == "PENDING"
        ).first()

        if high_val_appr:
            res_doa = client.post(
                f"/api/v1/approvals/{high_val_appr.id}/action?user_role=FINANCE_EXECUTIVE",
                json={"action": "APPROVED", "comments": "DOA test"}
            )
            assert res_doa.status_code == 403
            assert "Authorization Ceiling Exceeded" in res_doa.json()["detail"] or "Delegation of Authority" in res_doa.json()["detail"]
    finally:
        db.close()

def test_database_integrity_and_no_unintended_mutations():
    """
    Task 7: Verify data integrity:
    1. INV-2026-00452 is NEVER marked as APPROVED.
    2. Audit logs contain tamper-evident history.
    """
    db = SessionLocal()
    try:
        inv = db.query(Invoice).filter(Invoice.id == "INV-2026-00452").first()
        assert inv.status != "APPROVED", "INV-2026-00452 must NEVER be approved"
        assert inv.payment_status == "UNPAID"

        # Check AuditLog count for this invoice
        audits = db.query(AuditLog).filter(AuditLog.entity_id == "INV-2026-00452").all()
        assert len(audits) >= 1
        for a in audits:
            assert a.action in (
                "MATCH_EVALUATED_MISSING_PO",
                "MATCH_EVALUATED_ITEM_MISMATCH",
                "HUMAN_CONFIRMED_OCR_RECONCILIATION",
                "INVOICE_FIELDS_CORRECTED",
                "INVOICE_INGESTION",
                "RECONCILIATION_COMPLETED",
                "APPROVAL_APPROVED",
                "APPROVAL_HELD",
                "APPROVAL_REJECTED"
            )
    finally:
        db.close()
