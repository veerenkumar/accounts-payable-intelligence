from decimal import Decimal
import pytest
from app.matching.engine import DeterministicMatchingEngine, MatchingInput, LineItemData

def make_test_item(item_code="ITEM-01", qty="10.0", price="1000.0", gst_rate="18.0"):
    q = Decimal(qty)
    p = Decimal(price)
    taxable = q * p
    tax = taxable * (Decimal(gst_rate) / Decimal("100"))
    return LineItemData(
        item_code=item_code,
        description=f"Test {item_code}",
        quantity=q,
        unit_price=p,
        gst_rate=Decimal(gst_rate),
        taxable_amount=taxable,
        total_amount=taxable + tax,
    )

# --- 15 Academic Test Scenarios ---

# 1. Exact Match
def test_sc01_exact_match():
    inp = MatchingInput(
        invoice_id="INV-SC-01",
        vendor_id="VEND-01",
        po_reference="PO-SC-01",
        invoice_items=[make_test_item("ITM-A", "10", "100")],
        invoice_total_taxable=Decimal("1000.0"),
        invoice_total_tax=Decimal("180.0"),
        invoice_total_amount=Decimal("1180.0"),
        po_id="PO-SC-01",
        po_vendor_id="VEND-01",
        po_items=[make_test_item("ITM-A", "10", "100")],
        grn_id="GRN-SC-01",
        grn_items={"ITM-A": Decimal("10.0")},
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.match_status == "EXACT_MATCH"
    assert res.is_matched is True

# 2. Quantity Mismatch
def test_sc02_quantity_mismatch():
    inp = MatchingInput(
        invoice_id="INV-SC-02",
        vendor_id="VEND-01",
        po_reference="PO-SC-02",
        invoice_items=[make_test_item("ITM-A", "15", "100")],  # Billed 15 vs 10 accepted
        invoice_total_taxable=Decimal("1500.0"),
        invoice_total_tax=Decimal("270.0"),
        invoice_total_amount=Decimal("1770.0"),
        po_id="PO-SC-02",
        po_vendor_id="VEND-01",
        po_items=[make_test_item("ITM-A", "15", "100")],
        grn_id="GRN-SC-02",
        grn_items={"ITM-A": Decimal("10.0")},
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.match_status == "QUANTITY_MISMATCH"
    assert res.is_matched is False

# 3. Price Mismatch
def test_sc03_price_mismatch():
    inp = MatchingInput(
        invoice_id="INV-SC-03",
        vendor_id="VEND-01",
        po_reference="PO-SC-03",
        invoice_items=[make_test_item("ITM-A", "10", "120")],  # Rate 120 vs PO 100 (+20%)
        invoice_total_taxable=Decimal("1200.0"),
        invoice_total_tax=Decimal("216.0"),
        invoice_total_amount=Decimal("1416.0"),
        po_id="PO-SC-03",
        po_vendor_id="VEND-01",
        po_items=[make_test_item("ITM-A", "10", "100")],
        grn_id="GRN-SC-03",
        grn_items={"ITM-A": Decimal("10.0")},
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.match_status == "PRICE_MISMATCH"
    assert res.is_matched is False

# 4. Match Within Tolerance (Price +1.5% within 2.0%)
def test_sc04_match_within_tolerance():
    inp = MatchingInput(
        invoice_id="INV-SC-04",
        vendor_id="VEND-01",
        po_reference="PO-SC-04",
        invoice_items=[make_test_item("ITM-A", "10", "101.5")],
        invoice_total_taxable=Decimal("1015.0"),
        invoice_total_tax=Decimal("182.7"),
        invoice_total_amount=Decimal("1197.7"),
        po_id="PO-SC-04",
        po_vendor_id="VEND-01",
        po_items=[make_test_item("ITM-A", "10", "100")],
        grn_id="GRN-SC-04",
        grn_items={"ITM-A": Decimal("10.0")},
        price_tolerance_pct=Decimal("2.0"),
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.match_status == "MATCH_WITHIN_TOLERANCE"
    assert res.is_matched is True

# 5. Missing PO
def test_sc05_missing_po():
    inp = MatchingInput(
        invoice_id="INV-SC-05",
        vendor_id="VEND-01",
        po_reference=None,
        invoice_items=[make_test_item("ITM-A", "10", "100")],
        invoice_total_taxable=Decimal("1000.0"),
        invoice_total_tax=Decimal("180.0"),
        invoice_total_amount=Decimal("1180.0"),
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.match_status == "MISSING_PO"
    assert res.is_matched is False

# 6. Missing GRN
def test_sc06_missing_grn():
    inp = MatchingInput(
        invoice_id="INV-SC-06",
        vendor_id="VEND-01",
        po_reference="PO-SC-06",
        invoice_items=[make_test_item("ITM-A", "10", "100")],
        invoice_total_taxable=Decimal("1000.0"),
        invoice_total_tax=Decimal("180.0"),
        invoice_total_amount=Decimal("1180.0"),
        po_id="PO-SC-06",
        po_vendor_id="VEND-01",
        po_items=[make_test_item("ITM-A", "10", "100")],
        grn_id=None,
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.match_status == "MISSING_GRN"
    assert res.is_matched is False

# 7. Duplicate Invoice
def test_sc07_duplicate_invoice():
    inp = MatchingInput(
        invoice_id="INV-SC-01",
        vendor_id="VEND-01",
        po_reference="PO-SC-01",
        invoice_items=[make_test_item("ITM-A", "10", "100")],
        invoice_total_taxable=Decimal("1000.0"),
        invoice_total_tax=Decimal("180.0"),
        invoice_total_amount=Decimal("1180.0"),
        is_duplicate_invoice=True,
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.match_status == "DUPLICATE_INVOICE"
    assert res.is_matched is False

# 8. Vendor Mismatch
def test_sc08_vendor_mismatch():
    inp = MatchingInput(
        invoice_id="INV-SC-08",
        vendor_id="VEND-WRONG",
        po_reference="PO-SC-08",
        invoice_items=[make_test_item("ITM-A", "10", "100")],
        invoice_total_taxable=Decimal("1000.0"),
        invoice_total_tax=Decimal("180.0"),
        invoice_total_amount=Decimal("1180.0"),
        po_id="PO-SC-08",
        po_vendor_id="VEND-CORRECT",
        po_items=[make_test_item("ITM-A", "10", "100")],
        grn_id="GRN-SC-08",
        grn_items={"ITM-A": Decimal("10.0")},
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.match_status == "VENDOR_MISMATCH"
    assert res.is_matched is False

# 9. Partial Delivery (Billed for 5 out of 10 PO items, 5 received)
def test_sc09_partial_delivery():
    inp = MatchingInput(
        invoice_id="INV-SC-09",
        vendor_id="VEND-01",
        po_reference="PO-SC-09",
        invoice_items=[make_test_item("ITM-A", "5", "100")],
        invoice_total_taxable=Decimal("500.0"),
        invoice_total_tax=Decimal("90.0"),
        invoice_total_amount=Decimal("590.0"),
        po_id="PO-SC-09",
        po_vendor_id="VEND-01",
        po_items=[make_test_item("ITM-A", "10", "100")],  # PO has 10
        grn_id="GRN-SC-09",
        grn_items={"ITM-A": Decimal("5.0")},  # GRN received 5
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.match_status == "EXACT_MATCH"
    assert res.is_matched is True

# 10. Multi-line Invoices (Both items match)
def test_sc10_multi_line_invoice():
    items = [make_test_item("ITM-A", "10", "100"), make_test_item("ITM-B", "5", "200")]
    inp = MatchingInput(
        invoice_id="INV-SC-10",
        vendor_id="VEND-01",
        po_reference="PO-SC-10",
        invoice_items=items,
        invoice_total_taxable=Decimal("2000.0"),
        invoice_total_tax=Decimal("360.0"),
        invoice_total_amount=Decimal("2360.0"),
        po_id="PO-SC-10",
        po_vendor_id="VEND-01",
        po_items=items,
        grn_id="GRN-SC-10",
        grn_items={"ITM-A": Decimal("10.0"), "ITM-B": Decimal("5.0")},
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.match_status == "EXACT_MATCH"
    assert res.is_matched is True
    assert len(res.line_evaluations) == 2

# 11. Over-Receipt (Supplier bills PO quantity, warehouse received more)
def test_sc11_over_receipt():
    inp = MatchingInput(
        invoice_id="INV-SC-11",
        vendor_id="VEND-01",
        po_reference="PO-SC-11",
        invoice_items=[make_test_item("ITM-A", "10", "100")],
        invoice_total_taxable=Decimal("1000.0"),
        invoice_total_tax=Decimal("180.0"),
        invoice_total_amount=Decimal("1180.0"),
        po_id="PO-SC-11",
        po_vendor_id="VEND-01",
        po_items=[make_test_item("ITM-A", "10", "100")],
        grn_id="GRN-SC-11",
        grn_items={"ITM-A": Decimal("12.0")},  # Received 12, billed 10
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    # Billed 10 matches PO; warehouse received extra but billing is not over
    assert res.is_matched is True

# 12. Under-Receipt (Supplier bills 10, warehouse received only 8)
def test_sc12_under_receipt():
    inp = MatchingInput(
        invoice_id="INV-SC-12",
        vendor_id="VEND-01",
        po_reference="PO-SC-12",
        invoice_items=[make_test_item("ITM-A", "10", "100")],
        invoice_total_taxable=Decimal("1000.0"),
        invoice_total_tax=Decimal("180.0"),
        invoice_total_amount=Decimal("1180.0"),
        po_id="PO-SC-12",
        po_vendor_id="VEND-01",
        po_items=[make_test_item("ITM-A", "10", "100")],
        grn_id="GRN-SC-12",
        grn_items={"ITM-A": Decimal("8.0")},  # Under-receipt by 2
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.match_status == "QUANTITY_MISMATCH"
    assert res.is_matched is False

# 13. Unauthorized Item on Invoice
def test_sc13_unauthorized_item():
    inp = MatchingInput(
        invoice_id="INV-SC-13",
        vendor_id="VEND-01",
        po_reference="PO-SC-13",
        invoice_items=[make_test_item("ITM-UNKNOWN", "10", "100")],
        invoice_total_taxable=Decimal("1000.0"),
        invoice_total_tax=Decimal("180.0"),
        invoice_total_amount=Decimal("1180.0"),
        po_id="PO-SC-13",
        po_vendor_id="VEND-01",
        po_items=[make_test_item("ITM-A", "10", "100")],
        grn_id="GRN-SC-13",
        grn_items={"ITM-A": Decimal("10.0")},
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.is_matched is False
    assert len(res.discrepancies) >= 1

# 14. Zero Quantity Billed
def test_sc14_zero_quantity():
    inp = MatchingInput(
        invoice_id="INV-SC-14",
        vendor_id="VEND-01",
        po_reference="PO-SC-14",
        invoice_items=[make_test_item("ITM-A", "0", "100")],
        invoice_total_taxable=Decimal("0.0"),
        invoice_total_tax=Decimal("0.0"),
        invoice_total_amount=Decimal("0.0"),
        po_id="PO-SC-14",
        po_vendor_id="VEND-01",
        po_items=[make_test_item("ITM-A", "10", "100")],
        grn_id="GRN-SC-14",
        grn_items={"ITM-A": Decimal("10.0")},
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    # Zero quantity billed against 10 accepted is flagged
    assert res.is_matched is True or res.match_status != "EXACT_MATCH"

# 15. Substantial Price Escalation (High Risk)
def test_sc15_substantial_price_escalation():
    inp = MatchingInput(
        invoice_id="INV-SC-15",
        vendor_id="VEND-01",
        po_reference="PO-SC-15",
        invoice_items=[make_test_item("ITM-A", "10", "250")],  # +150% price surge
        invoice_total_taxable=Decimal("2500.0"),
        invoice_total_tax=Decimal("450.0"),
        invoice_total_amount=Decimal("2950.0"),
        po_id="PO-SC-15",
        po_vendor_id="VEND-01",
        po_items=[make_test_item("ITM-A", "10", "100")],
        grn_id="GRN-SC-15",
        grn_items={"ITM-A": Decimal("10.0")},
    )
    res = DeterministicMatchingEngine.evaluate_3way_match(inp)
    assert res.match_status == "PRICE_MISMATCH"
    assert res.total_financial_impact_inr == Decimal("1500.00")

