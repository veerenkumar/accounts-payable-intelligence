import pytest
from datetime import date
from decimal import Decimal
from fastapi.testclient import TestClient
from app.main import app
from app.database.session import SessionLocal
from app.models.financial_entities import Invoice, PurchaseOrder, GoodsReceiptNote, MatchingResult, ExceptionRecord, Vendor, Document
from app.matching.service import MatchingService

client = TestClient(app)

def test_detect_cross_vendor_invoice_collision():
    """
    Task 7: Regression test for cross-vendor invoice collisions.
    Ensure that when an uploaded document has an invoice number that matches an
    existing ledger row but belongs to a different vendor (Tata Steel vs L&T),
    the system flags the discrepancy rather than silently accepting it.
    """
    response = client.get("/api/v1/invoices/INV-2026-00452")
    assert response.status_code == 200
    data = response.json()

    # Confirmed Ledger attributes
    assert data["vendor_id"] == "VEND-002"
    assert data["vendor_name"] == "Larsen & Toubro Heavy Engg"
    assert data["vendor_gstin"] == "27AAACL0140P1ZH"

    # Conflicting OCR Document attributes
    assert data["ocr_data"]["vendor_name"] == "Tata Steel Products Ltd."
    assert data["ocr_data"]["vendor_gstin"] == "27AAACT2727Q1ZW"
    assert data["ocr_data"]["po_reference"] == "PO-2026-00101"

    # Active Discrepancies
    disc_map = {d["field"]: d for d in data["ocr_discrepancies"]}
    assert disc_map["vendor_name"]["has_conflict"] is True
    assert disc_map["vendor_gstin"]["has_conflict"] is True
    assert disc_map["po_reference"]["has_conflict"] is True

def test_reject_po_association_when_vendor_mismatch():
    """
    Task 7: Test that assigning a PO belonging to Vendor A (Tata Steel)
    to an invoice belonging to Vendor B (L&T) is caught by deterministic matching.
    """
    db = SessionLocal()
    test_inv_id = "INV-TEST-COLLISION-001"
    try:
        # Create an invoice belonging to L&T (VEND-002), but pointing to Tata Steel's PO (PO-2026-00101)
        test_inv = Invoice(
            id=test_inv_id,
            vendor_id="VEND-002",
            vendor_gstin="27AAACL0140P1ZH",
            recipient_gstin="27AABCA9876K1Z5",
            place_of_supply="27",
            invoice_date=date(2026, 11, 1),
            due_date=date(2026, 12, 1),
            po_reference="PO-2026-00101", # Belongs to VEND-001!
            taxable_value_inr=Decimal("209000.00"),
            total_tax_inr=Decimal("37620.00"),
            total_amount_inr=Decimal("246620.00"),
            status="INGESTED"
        )
        db.add(test_inv)
        db.commit()

        # Execute matching
        result = MatchingService.evaluate_invoice_matching(test_inv_id, db)
        
        # Must detect that PO-2026-00101 does NOT match VEND-002
        assert result["is_matched"] is False
        assert result["match_status"] in ("VENDOR_MISMATCH", "ITEM_MISMATCH", "REQUIRES_HUMAN_REVIEW")

    finally:
        db.rollback()
        db.query(MatchingResult).filter(MatchingResult.invoice_id == test_inv_id).delete()
        db.query(ExceptionRecord).filter(ExceptionRecord.invoice_id == test_inv_id).delete()
        db.query(Invoice).filter(Invoice.id == test_inv_id).delete()
        db.commit()
        db.close()

def test_po_already_fulfilled_by_earlier_invoice():
    """
    Task 7: Verify that PO-2026-00101 was already fulfilled by INV-2026-00451.
    Any second invoice claiming 50 units against PO-2026-00101 (authorized for 20 units)
    cannot achieve EXACT_MATCH.
    """
    db = SessionLocal()
    try:
        # 1. Verify original legitimate invoice INV-2026-00451 exists and is matched
        inv_legit = db.query(Invoice).filter(Invoice.id == "INV-2026-00451").first()
        assert inv_legit is not None
        assert inv_legit.vendor_id == "VEND-001"
        assert inv_legit.po_reference == "PO-2026-00101"
        assert float(inv_legit.total_amount_inr) == 98648.0
        assert inv_legit.match_status == "EXACT_MATCH"

        # 2. Verify PO total vs conflicting PDF total
        po = db.query(PurchaseOrder).filter(PurchaseOrder.id == "PO-2026-00101").first()
        assert po is not None
        assert po.vendor_id == "VEND-001"
        assert float(po.total_amount_inr) == 98648.0
        assert po.status == "FULFILLED"

        # Conflicting invoice bills 246,620 (50 units @ 4,180 + tax) vs 98,648 (20 units @ 4,180 + tax)
        variance = Decimal("246620.00") - po.total_amount_inr
        assert variance == Decimal("147972.00")
        assert variance > Decimal("0.00")

    finally:
        db.close()

def test_nonexistent_po_evaluated_as_missing_po():
    """
    Task 7: Verify that matching an invoice with a non-existent PO reference
    (such as PO-2026-00101-AMENDED) strictly yields MISSING_PO and NO GRN.
    """
    db = SessionLocal()
    try:
        result = MatchingService.evaluate_invoice_matching("INV-2026-00452", db)
        assert result["match_status"] == "MISSING_PO"
        assert result["po_id"] is None
        assert result["grn_id"] is None
        assert result["is_matched"] is False
    finally:
        db.close()
