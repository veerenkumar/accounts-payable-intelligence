import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_roi_model_endpoint():
    response = client.get("/api/v1/analytics/roi-model")
    assert response.status_code == 200
    data = response.json()
    assert data["initial_investment_inr"] == 1200000.0
    assert len(data["scenarios"]) == 3
    base_case = [s for s in data["scenarios"] if "Base-Case" in s["scenario_name"]][0]
    assert base_case["roi_percent"] > 200.0
    assert base_case["payback_period_months"] < 6.0

def test_copilot_outstanding_query():
    response = client.post(
        "/api/v1/copilot/query",
        json={"query": "What is our total outstanding payables?"},
    )
    assert response.status_code == 200
    data = response.json()
    assert "₹" in data["response"]
    assert "get_outstanding_liabilities" in data["tools_executed"]
    assert len(data["supporting_records"]) > 0

def test_copilot_vendor_query():
    response = client.post(
        "/api/v1/copilot/query",
        json={"query": "Give me the status on Tata Steel invoices"},
    )
    assert response.status_code == 200
    data = response.json()
    assert "Tata Steel Products Ltd." in data["response"]
    assert "VEND-001" in data["supporting_records"]
    assert "get_vendor_exposure" in data["tools_executed"]

def test_resolve_exception_debit_note():
    # Retrieve all exceptions (any status)
    exc_list = client.get("/api/v1/exceptions").json()
    assert len(exc_list) >= 1
    exc_id = exc_list[0]["id"]

    res = client.post(
        f"/api/v1/exceptions/{exc_id}/resolve",
        json={
            "action": "ISSUE_DEBIT_NOTE",
            "resolution_notes": "Vendor acknowledged price billing escalation. Issued debit note for ₹7,000 variance.",
            "adjust_liability_inr": 7000.0,
        },
    )
    assert res.status_code == 200
    data = res.json()
    assert data["status"] == "RESOLVED"
    assert data["action_taken"] == "ISSUE_DEBIT_NOTE"
    assert data["debit_note_reference"] is not None
