import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health_check():
    response = client.get("/api/v1/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["version"] == "1.0.0"
    assert data["database"] == "connected"

def test_dashboard_kpis():
    response = client.get("/api/v1/analytics/dashboard")
    assert response.status_code == 200
    data = response.json()
    assert data["total_invoices_processed"] >= 3
    assert data["total_invoice_value_inr"] > 0
    assert "matching_rate_percent" in data

def test_list_vendors():
    response = client.get("/api/v1/vendors")
    assert response.status_code == 200
    vendors = response.json()
    assert len(vendors) >= 3
    assert any(v["id"] == "VEND-001" for v in vendors)

def test_list_invoices():
    response = client.get("/api/v1/invoices")
    assert response.status_code == 200
    invoices = response.json()
    assert len(invoices) >= 3
    assert any(i["id"] == "INV-2026-00454" for i in invoices)

def test_get_single_invoice():
    response = client.get("/api/v1/invoices/INV-2026-00454")
    assert response.status_code == 200
    inv = response.json()
    assert inv["vendor_id"] == "VEND-007"
    assert inv["match_status"] == "EXACT_MATCH"

def test_list_exceptions():
    response = client.get("/api/v1/exceptions")
    assert response.status_code == 200
    exceptions = response.json()
    assert len(exceptions) >= 1
    assert exceptions[0]["category"] == "PRICE_DIFF"

def test_approval_action():
    response = client.get("/api/v1/approvals")
    assert response.status_code == 200
    approvals = response.json()
    assert len(approvals) >= 1

    # First test: Blocked approval with open exceptions or non-pending status is rejected
    held = [a for a in approvals if a.get("blocking_exceptions_count", 0) > 0 or a.get("status") == "HELD"]
    if held:
        held_id = held[0]["id"]
        blocked_res = client.post(
            f"/api/v1/approvals/{held_id}/action",
            json={"action": "APPROVED", "comments": "Should be blocked due to open exceptions"},
        )
        assert blocked_res.status_code == 400
        assert "Financial Control Violation" in blocked_res.json()["detail"]

    # Second test: Eligible approval without open exceptions succeeds
    eligible = [a for a in approvals if a.get("blocking_exceptions_count", 0) == 0 and a["status"] == "PENDING"]
    assert len(eligible) > 0, "Expected at least one eligible pending approval"
    approval_id = eligible[0]["id"]

    action_response = client.post(
        f"/api/v1/approvals/{approval_id}/action",
        json={"action": "APPROVED", "comments": "Automated verification test approval"},
    )
    assert action_response.status_code == 200
    updated = action_response.json()
    assert updated["status"] == "APPROVED"

def test_upload_and_list_documents():
    import os
    sample_pdf_path = os.path.join(os.path.dirname(__file__), "..", "..", "data", "sample_documents", "INV_2026_00452_TataSteel.pdf")
    if os.path.exists(sample_pdf_path):
        with open(sample_pdf_path, "rb") as f:
            response = client.post(
                "/api/v1/documents/upload",
                files={"file": ("INV_2026_00452_TataSteel.pdf", f, "application/pdf")},
            )
        assert response.status_code == 200
        data = response.json()
        assert "document_id" in data
        assert data["file_name"] == "INV_2026_00452_TataSteel.pdf"
        assert data["extraction_confidence"] > 0.8

    # Test listing documents
    list_res = client.get("/api/v1/documents")
    assert list_res.status_code == 200
    docs = list_res.json()
    assert len(docs) >= 1

