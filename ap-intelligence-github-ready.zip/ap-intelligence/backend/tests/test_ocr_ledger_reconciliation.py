import pytest
from datetime import date
from decimal import Decimal
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session
from app.main import app
from app.database.session import SessionLocal
from app.models.financial_entities import Invoice, InvoiceItem, PurchaseOrder, Vendor, Document, AuditLog
from app.matching.service import MatchingService

client = TestClient(app)

def test_ocr_to_ledger_discrepancy_detection_inv_00452():
    """
    Task 1, 2, 5: Verify that the ledger API detects and exposes discrepancies
    between the ERP ledger row and the physical document artifact for INV-2026-00452.
    """
    response = client.get("/api/v1/invoices/INV-2026-00452")
    assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
    data = response.json()

    assert data["id"] == "INV-2026-00452"
    assert data["vendor_id"] == "VEND-002"
    assert data["vendor_name"] == "Larsen & Toubro Heavy Engg"
    assert data["vendor_gstin"] == "27AAACL0140P1ZH"
    assert data["po_reference"] == "PO-2026-00101-AMENDED"
    assert data["total_amount_inr"] == 246620.0

    # Verify OCR data extraction
    assert data["ocr_data"] is not None
    assert data["ocr_data"]["invoice_number"] == "INV-2026-00452"
    assert data["ocr_data"]["vendor_name"] == "Tata Steel Products Ltd."
    assert data["ocr_data"]["vendor_gstin"] == "27AAACT2727Q1ZW"
    assert data["ocr_data"]["po_reference"] == "PO-2026-00101"
    assert data["ocr_data"]["total_amount"] == 246620.0

    # Verify field-by-field discrepancies
    discrepancies = {d["field"]: d for d in data["ocr_discrepancies"]}
    assert len(discrepancies) >= 4

    # 1. Vendor Name conflict
    assert discrepancies["vendor_name"]["has_conflict"] is True
    assert discrepancies["vendor_name"]["ledger_value"] == "Larsen & Toubro Heavy Engg"
    assert discrepancies["vendor_name"]["ocr_value"] == "Tata Steel Products Ltd."

    # 2. Vendor GSTIN conflict
    assert discrepancies["vendor_gstin"]["has_conflict"] is True
    assert discrepancies["vendor_gstin"]["ledger_value"] == "27AAACL0140P1ZH"
    assert discrepancies["vendor_gstin"]["ocr_value"] == "27AAACT2727Q1ZW"

    # 3. PO Reference conflict
    assert discrepancies["po_reference"]["has_conflict"] is True
    assert discrepancies["po_reference"]["ledger_value"] == "PO-2026-00101-AMENDED"
    assert discrepancies["po_reference"]["ocr_value"] == "PO-2026-00101"

    # 4. Total Amount agreement (both are 246,620)
    assert discrepancies["total_amount_inr"]["has_conflict"] is False
    assert float(discrepancies["total_amount_inr"]["ledger_value"]) == 246620.0
    assert float(discrepancies["total_amount_inr"]["ocr_value"]) == 246620.0

def test_unapproved_ocr_does_not_mutate_ledger():
    """
    Task 5 & 6: Ensure raw OCR extraction does not silently alter the financial ledger.
    The database state must remain unchanged unless explicitly reconciled.
    """
    db = SessionLocal()
    try:
        inv = db.query(Invoice).filter(Invoice.id == "INV-2026-00452").first()
        assert inv is not None
        assert inv.vendor_id == "VEND-002"
        assert inv.vendor_gstin == "27AAACL0140P1ZH"
        assert inv.po_reference == "PO-2026-00101-AMENDED"
    finally:
        db.close()

def test_matching_engine_uses_confirmed_ledger_not_unapproved_ocr():
    """
    Task 6: Ensure the matching engine strictly uses confirmed ledger data,
    NOT raw OCR suggestions. Because ledger has 'PO-2026-00101-AMENDED' (which does
    not exist in PO table), matching must evaluate to MISSING_PO.
    """
    db = SessionLocal()
    try:
        result = MatchingService.evaluate_invoice_matching("INV-2026-00452", db)
        assert result["match_status"] == "MISSING_PO"
    finally:
        db.close()

def test_reconciliation_requires_authorized_role():
    """
    Task 5: Reconciling OCR discrepancies requires authorized role (AP_MANAGER, CFO, AUDITOR).
    Unauthorized roles must be rejected with 403 Forbidden.
    """
    payload = {
        "confirmed_by": "USR-UNAUTH-01",
        "user_role": "JUNIOR_CLERK",
        "accept_ocr_vendor": True,
        "accept_ocr_po": True,
        "comments": "Unauthorized attempt to reconcile"
    }
    response = client.post("/api/v1/invoices/INV-2026-00452/reconcile-ocr", json=payload)
    assert response.status_code == 403, f"Expected 403 Forbidden, got {response.status_code}"
    assert "Unauthorized" in response.json()["detail"]

def test_reconciliation_rejects_missing_document():
    """
    Reconciliation cannot proceed if no matching document exists for the invoice.
    """
    payload = {
        "confirmed_by": "USR-002",
        "user_role": "AP_MANAGER",
        "accept_ocr_vendor": True,
        "accept_ocr_po": True,
        "comments": "Reconciliation without document"
    }
    response = client.post("/api/v1/invoices/INV-NON-EXISTENT/reconcile-ocr", json=payload)
    assert response.status_code == 404

def test_reconciliation_workflow_execution_and_audit():
    """
    Task 5 & 7: Test the complete human-authorized reconciliation workflow:
    1. Create a test invoice linked to a test document artifact with conflicts.
    2. Reconcile with authorization.
    3. Verify ledger columns are updated safely.
    4. Verify AuditLog entry is recorded with full before/after state.
    5. Cleanup test data.
    """
    db = SessionLocal()
    test_inv_id = "INV-TEST-RECON-999"
    test_doc_id = "DOC-TEST-RECON-999"
    try:
        # Create test document
        doc = Document(
            id=test_doc_id,
            file_name="INV_TEST_RECON_999_TataSteel.pdf",
            file_path="/tmp/test_recon.pdf",
            mime_type="application/pdf",
            document_type="INVOICE",
            file_size_bytes=12345,
            ocr_raw_text="""
INVOICE
Invoice No: INV-TEST-RECON-999
Date: 12/03/2026
Supplier: Tata Steel Products Ltd.
GSTIN: 27AAACT2727Q1ZW
PO Reference: PO-2026-00101
Taxable Amount: 209000.00
Total Amount: 246620.00
"""
        )
        db.add(doc)

        # Create test invoice with conflicting ledger data
        inv = Invoice(
            id=test_inv_id,
            vendor_id="VEND-002",
            vendor_gstin="27AAACL0140P1ZH",
            recipient_gstin="27AABCT3456K1Z2",
            place_of_supply="27",
            invoice_date=date(2026, 3, 12),
            due_date=date(2026, 4, 11),
            po_reference="PO-2026-00101-AMENDED",
            taxable_value_inr=Decimal("209000.00"),
            total_tax_inr=Decimal("37620.00"),
            total_amount_inr=Decimal("246620.00"),
            status="RECONCILIATION_REQUIRED",
            document_id=test_doc_id
        )
        db.add(inv)
        db.commit()

        # Step 2: Call reconciliation endpoint with authorized role
        payload = {
            "confirmed_by": "USR-FIN-009",
            "user_role": "AP_MANAGER",
            "accept_ocr_vendor": True,
            "accept_ocr_po": True,
            "accept_ocr_dates": True,
            "comments": "Authorized CFO sign-off: Reconciling ledger with Tata Steel document artifact."
        }
        res = client.post(f"/api/v1/invoices/{test_inv_id}/reconcile-ocr", json=payload)
        assert res.status_code == 200, f"Expected 200, got {res.status_code}: {res.text}"
        data = res.json()
        assert data["status"] == "RECONCILED"
        assert data["invoice_id"] == test_inv_id
        assert data["vendor_id"] == "VEND-001"
        assert data["vendor_gstin"] == "27AAACT2727Q1ZW"
        assert data["po_reference"] == "PO-2026-00101"
        assert "vendor_id" in data["updated_fields"]
        assert "po_reference" in data["updated_fields"]

        # Step 3: Verify database state
        db.expire_all()
        reconciled_inv = db.query(Invoice).filter(Invoice.id == test_inv_id).first()
        assert reconciled_inv.vendor_id == "VEND-001"
        assert reconciled_inv.vendor_gstin == "27AAACT2727Q1ZW"
        assert reconciled_inv.po_reference == "PO-2026-00101"

        # Step 4: Verify AuditLog entry
        audit = db.query(AuditLog).filter(
            AuditLog.entity_id == test_inv_id,
            AuditLog.action == "HUMAN_CONFIRMED_OCR_RECONCILIATION"
        ).first()
        assert audit is not None
        assert audit.actor_id == "USR-FIN-009"
        assert audit.old_state["vendor_id"] == "VEND-002"
        assert audit.new_state["vendor_id"] == "VEND-001"
        assert audit.new_state["po_reference"] == "PO-2026-00101"

    finally:
        # Cleanup test data to prevent database pollution
        db.rollback()
        db.query(AuditLog).filter(AuditLog.entity_id == test_inv_id).delete()
        db.query(Invoice).filter(Invoice.id == test_inv_id).delete()
        db.query(Document).filter(Document.id == test_doc_id).delete()
        db.commit()
        db.close()
