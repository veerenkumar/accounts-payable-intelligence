import uuid
from datetime import datetime, date
from sqlalchemy import (
    Column,
    String,
    Integer,
    Numeric,
    Boolean,
    Date,
    DateTime,
    Text,
    ForeignKey,
    JSON,
)
from sqlalchemy.orm import relationship
from app.database.session import Base

def generate_uuid():
    return str(uuid.uuid4())

class Role(Base):
    __tablename__ = "roles"

    id = Column(String(32), primary_key=True)  # ADMIN, FINANCE_CONTROLLER, AP_MANAGER, FINANCE_EXECUTIVE
    name = Column(String(64), nullable=False)
    description = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    users = relationship("User", back_populates="role")

class User(Base):
    __tablename__ = "users"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    role_id = Column(String(32), ForeignKey("roles.id"), nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    full_name = Column(String(255), nullable=False)
    department = Column(String(100), default="Finance & Accounts")
    approval_limit_inr = Column(Numeric(15, 2), default=0.00)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    role = relationship("Role", back_populates="users")
    assigned_exceptions = relationship("ExceptionRecord", back_populates="assigned_user")
    approval_requests = relationship("ApprovalRequest", back_populates="assigned_user")

class Vendor(Base):
    __tablename__ = "vendors"

    id = Column(String(32), primary_key=True)  # VEND-001
    name = Column(String(255), nullable=False)
    gstin = Column(String(15), nullable=False)
    pan = Column(String(10), nullable=False)
    address = Column(Text, nullable=False)
    state_code = Column(String(2), nullable=False)
    contact_email = Column(String(255), nullable=False)
    contact_phone = Column(String(32), nullable=False)
    payment_terms_days = Column(Integer, default=30)
    bank_account_last4 = Column(String(4), nullable=False)
    bank_ifsc = Column(String(11), nullable=False)
    risk_category = Column(String(16), default="LOW")  # LOW, MEDIUM, HIGH
    total_spend_ytd_inr = Column(Numeric(15, 2), default=0.00)
    created_at = Column(DateTime, default=datetime.utcnow)

    purchase_orders = relationship("PurchaseOrder", back_populates="vendor")
    invoices = relationship("Invoice", back_populates="vendor")

class PurchaseOrder(Base):
    __tablename__ = "purchase_orders"

    id = Column(String(32), primary_key=True)  # PO-2026-00101
    vendor_id = Column(String(32), ForeignKey("vendors.id"), nullable=False)
    po_date = Column(Date, nullable=False)
    delivery_due_date = Column(Date, nullable=False)
    currency = Column(String(3), default="INR")
    subtotal_inr = Column(Numeric(15, 2), nullable=False)
    tax_amount_inr = Column(Numeric(15, 2), nullable=False)
    total_amount_inr = Column(Numeric(15, 2), nullable=False)
    status = Column(String(32), default="OPEN")  # OPEN, PARTIALLY_FULFILLED, FULFILLED, CLOSED
    payment_terms = Column(String(64), default="Net 30")
    created_at = Column(DateTime, default=datetime.utcnow)

    vendor = relationship("Vendor", back_populates="purchase_orders")
    items = relationship("POItem", back_populates="purchase_order", cascade="all, delete-orphan")
    grns = relationship("GoodsReceiptNote", back_populates="purchase_order")

class POItem(Base):
    __tablename__ = "po_items"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    po_id = Column(String(32), ForeignKey("purchase_orders.id"), nullable=False)
    line_number = Column(Integer, nullable=False)
    item_code = Column(String(64), nullable=False)
    description = Column(Text, nullable=False)
    hsn_sac_code = Column(String(16), nullable=False)
    quantity = Column(Numeric(12, 3), nullable=False)
    unit_price_inr = Column(Numeric(15, 2), nullable=False)
    gst_rate_percent = Column(Numeric(5, 2), nullable=False)
    taxable_amount_inr = Column(Numeric(15, 2), nullable=False)
    total_line_amount_inr = Column(Numeric(15, 2), nullable=False)

    purchase_order = relationship("PurchaseOrder", back_populates="items")

class GoodsReceiptNote(Base):
    __tablename__ = "goods_receipt_notes"

    id = Column(String(32), primary_key=True)  # GRN-2026-00085
    po_id = Column(String(32), ForeignKey("purchase_orders.id"), nullable=False)
    vendor_id = Column(String(32), ForeignKey("vendors.id"), nullable=False)
    receipt_date = Column(Date, nullable=False)
    delivery_challan_no = Column(String(64), nullable=True)
    received_by_user = Column(String(100), nullable=False)
    warehouse_location = Column(String(100), default="Central Warehouse")
    status = Column(String(32), default="ACCEPTED")  # ACCEPTED, PARTIALLY_ACCEPTED, REJECTED
    created_at = Column(DateTime, default=datetime.utcnow)

    purchase_order = relationship("PurchaseOrder", back_populates="grns")
    items = relationship("GRNItem", back_populates="grn", cascade="all, delete-orphan")

class GRNItem(Base):
    __tablename__ = "grn_items"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    grn_id = Column(String(32), ForeignKey("goods_receipt_notes.id"), nullable=False)
    item_code = Column(String(64), nullable=False)
    quantity_received = Column(Numeric(12, 3), nullable=False)
    quantity_accepted = Column(Numeric(12, 3), nullable=False)
    quantity_rejected = Column(Numeric(12, 3), default=0.000)
    rejection_reason = Column(Text, nullable=True)

    grn = relationship("GoodsReceiptNote", back_populates="items")

class Document(Base):
    __tablename__ = "documents"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    file_name = Column(String(255), nullable=False)
    file_path = Column(String(512), nullable=False)
    file_size_bytes = Column(Integer, nullable=False)
    mime_type = Column(String(64), nullable=False)
    document_type = Column(String(32), nullable=False)  # INVOICE, PO, GRN, SUPPORTING
    ocr_raw_text = Column(Text, nullable=True)
    ocr_confidence_score = Column(Numeric(5, 4), nullable=True)
    uploaded_at = Column(DateTime, default=datetime.utcnow)

class Invoice(Base):
    __tablename__ = "invoices"

    id = Column(String(64), primary_key=True)  # INV-2026-00452
    vendor_id = Column(String(32), ForeignKey("vendors.id"), nullable=False)
    po_reference = Column(String(32), ForeignKey("purchase_orders.id"), nullable=True)
    document_id = Column(String(36), ForeignKey("documents.id"), nullable=True)
    invoice_date = Column(Date, nullable=False)
    due_date = Column(Date, nullable=False)
    vendor_gstin = Column(String(15), nullable=False)
    recipient_gstin = Column(String(15), nullable=False)
    place_of_supply = Column(String(2), nullable=False)
    is_reverse_charge = Column(Boolean, default=False)
    taxable_value_inr = Column(Numeric(15, 2), nullable=False)
    cgst_amount_inr = Column(Numeric(15, 2), default=0.00)
    sgst_amount_inr = Column(Numeric(15, 2), default=0.00)
    igst_amount_inr = Column(Numeric(15, 2), default=0.00)
    total_tax_inr = Column(Numeric(15, 2), nullable=False)
    total_amount_inr = Column(Numeric(15, 2), nullable=False)
    currency = Column(String(3), default="INR")
    status = Column(String(32), default="INGESTED")
    match_status = Column(String(32), default="REQUIRES_HUMAN_REVIEW")
    extraction_confidence = Column(Numeric(5, 4), default=0.9500)
    payment_status = Column(String(32), default="UNPAID")
    created_at = Column(DateTime, default=datetime.utcnow)

    vendor = relationship("Vendor", back_populates="invoices")
    items = relationship("InvoiceItem", back_populates="invoice", cascade="all, delete-orphan")
    matching_result = relationship("MatchingResult", back_populates="invoice", uselist=False)
    exceptions = relationship("ExceptionRecord", back_populates="invoice")
    approval_requests = relationship("ApprovalRequest", back_populates="invoice")
    risk_alerts = relationship("RiskAlert", back_populates="invoice")

class InvoiceItem(Base):
    __tablename__ = "invoice_items"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    invoice_id = Column(String(64), ForeignKey("invoices.id"), nullable=False)
    line_number = Column(Integer, nullable=False)
    item_code = Column(String(64), nullable=False)
    description = Column(Text, nullable=False)
    hsn_sac_code = Column(String(16), nullable=False)
    quantity = Column(Numeric(12, 3), nullable=False)
    unit_price_inr = Column(Numeric(15, 2), nullable=False)
    gst_rate_percent = Column(Numeric(5, 2), nullable=False)
    taxable_amount_inr = Column(Numeric(15, 2), nullable=False)
    total_line_amount_inr = Column(Numeric(15, 2), nullable=False)

    invoice = relationship("Invoice", back_populates="items")

class MatchingResult(Base):
    __tablename__ = "matching_results"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    invoice_id = Column(String(64), ForeignKey("invoices.id"), unique=True, nullable=False)
    po_id = Column(String(32), ForeignKey("purchase_orders.id"), nullable=True)
    grn_id = Column(String(32), ForeignKey("goods_receipt_notes.id"), nullable=True)
    match_status = Column(String(32), nullable=False)
    price_variance_percent = Column(Numeric(6, 2), default=0.00)
    quantity_variance_percent = Column(Numeric(6, 2), default=0.00)
    tax_variance_inr = Column(Numeric(15, 2), default=0.00)
    total_financial_impact_inr = Column(Numeric(15, 2), default=0.00)
    is_matched = Column(Boolean, nullable=False)
    evaluation_notes = Column(Text, nullable=True)
    line_evaluations = Column(JSON, nullable=True)
    discrepancies = Column(JSON, nullable=True)
    evaluated_at = Column(DateTime, default=datetime.utcnow)

    invoice = relationship("Invoice", back_populates="matching_result")

class ExceptionRecord(Base):
    __tablename__ = "exceptions"

    id = Column(String(32), primary_key=True)  # EXC-2026-00018
    invoice_id = Column(String(64), ForeignKey("invoices.id"), nullable=False)
    category = Column(String(32), nullable=False)
    severity = Column(String(16), nullable=False)  # LOW, MEDIUM, HIGH, CRITICAL
    expected_value = Column(Text, nullable=False)
    actual_value = Column(Text, nullable=False)
    difference_value = Column(Text, nullable=False)
    financial_impact_inr = Column(Numeric(15, 2), nullable=False)
    responsible_department = Column(String(64), nullable=False)
    status = Column(String(32), default="OPEN")  # OPEN, INVESTIGATING, RESOLVED
    assigned_to_user_id = Column(String(36), ForeignKey("users.id"), nullable=True)
    resolution_notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    resolved_at = Column(DateTime, nullable=True)

    invoice = relationship("Invoice", back_populates="exceptions")
    assigned_user = relationship("User", back_populates="assigned_exceptions")

class RiskAlert(Base):
    __tablename__ = "risk_alerts"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    invoice_id = Column(String(64), ForeignKey("invoices.id"), nullable=False)
    vendor_id = Column(String(32), ForeignKey("vendors.id"), nullable=False)
    risk_score = Column(Integer, nullable=False)
    risk_category = Column(String(32), nullable=False)  # LOW, MODERATE, ELEVATED, HIGH
    rule_triggered = Column(String(128), nullable=False)
    explanation = Column(Text, nullable=False)
    suggested_action = Column(Text, nullable=False)
    is_acknowledged = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    invoice = relationship("Invoice", back_populates="risk_alerts")

class ApprovalRequest(Base):
    __tablename__ = "approval_requests"

    id = Column(String(32), primary_key=True)  # APR-2026-00092
    invoice_id = Column(String(64), ForeignKey("invoices.id"), nullable=False)
    required_role = Column(String(32), ForeignKey("roles.id"), nullable=False)
    amount_inr = Column(Numeric(15, 2), nullable=False)
    status = Column(String(32), default="PENDING")  # PENDING, APPROVED, REJECTED, HELD
    assigned_user_id = Column(String(36), ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    invoice = relationship("Invoice", back_populates="approval_requests")
    assigned_user = relationship("User", back_populates="approval_requests")
    history = relationship("ApprovalHistory", back_populates="approval_request", cascade="all, delete-orphan")

class ApprovalHistory(Base):
    __tablename__ = "approval_history"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    approval_request_id = Column(String(32), ForeignKey("approval_requests.id"), nullable=False)
    decided_by_user_id = Column(String(36), ForeignKey("users.id"), nullable=False)
    action = Column(String(32), nullable=False)  # APPROVED, REJECTED, HELD
    comments = Column(Text, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)

    approval_request = relationship("ApprovalRequest", back_populates="history")

class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    entity_type = Column(String(64), nullable=False)
    entity_id = Column(String(64), nullable=False)
    action = Column(String(64), nullable=False)
    actor_type = Column(String(16), nullable=False)  # USER, AGENT, SYSTEM
    actor_id = Column(String(64), nullable=False)
    old_state = Column(JSON, nullable=True)
    new_state = Column(JSON, nullable=True)
    ip_address = Column(String(45), nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow)

