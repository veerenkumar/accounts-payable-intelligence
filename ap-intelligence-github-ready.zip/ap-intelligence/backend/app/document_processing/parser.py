import os
import re
from datetime import datetime, date
from decimal import Decimal
from typing import Dict, Any, List, Optional
from pypdf import PdfReader
from PIL import Image

class DocumentParser:
    """
    Intelligent extraction parser for supplier invoices.
    Supports PDF documents and image files (PNG, JPG, JPEG).
    Extracts header fields, vendor details, GSTIN, PO reference, line items, and financial totals.
    Calculates field-level extraction confidence scores.
    """

    @staticmethod
    def extract_text_from_pdf(pdf_path: str) -> str:
        if not os.path.exists(pdf_path):
            raise FileNotFoundError(f"PDF file not found at path: {pdf_path}")

        reader = PdfReader(pdf_path)
        full_text = []
        for page in reader.pages:
            text = page.extract_text()
            if text:
                full_text.append(text)
        return "\n".join(full_text)

    @staticmethod
    def inspect_image(image_path: str) -> Dict[str, Any]:
        """Inspects image attributes and validates image integrity."""
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Image file not found at path: {image_path}")

        with Image.open(image_path) as img:
            return {
                "format": img.format,
                "size": img.size,  # (width, height)
                "mode": img.mode,
                "is_valid": True,
            }

    @classmethod
    def parse_invoice(cls, text: str, is_scanned_image: bool = False) -> Dict[str, Any]:
        """
        Parses raw text extracted from invoice into structured financial attributes.
        """
        extracted: Dict[str, Any] = {
            "invoice_number": None,
            "invoice_date": None,
            "due_date": None,
            "po_reference": None,
            "vendor_name": None,
            "vendor_gstin": None,
            "recipient_gstin": None,
            "place_of_supply": None,
            "currency": "INR",
            "taxable_value": 0.0,
            "cgst_amount": 0.0,
            "sgst_amount": 0.0,
            "igst_amount": 0.0,
            "total_tax": 0.0,
            "total_amount": 0.0,
            "line_items": [],
            "field_confidences": {},
            "overall_confidence": 0.95,
        }

        if is_scanned_image and not text.strip():
            extracted["overall_confidence"] = 0.65
            extracted["field_confidences"]["ocr_quality"] = 0.60
            return extracted

        # 1. Vendor Name
        vendor_match = re.search(
            r"(?:Supplier|Vendor|Seller|From)[\s:]*([A-Za-z0-9\s.,&'-]+?)(?=\n|GSTIN|Recipient|Bill To|$)",
            text,
            re.IGNORECASE,
        )
        if vendor_match:
            cand = vendor_match.group(1).strip()
            if len(cand) >= 3 and not re.match(r"^(GSTIN|TAX|INVOICE|PO)", cand, re.IGNORECASE):
                extracted["vendor_name"] = cand
                extracted["field_confidences"]["vendor_name"] = 0.96
        if not extracted["vendor_name"]:
            extracted["field_confidences"]["vendor_name"] = 0.50

        # 2. Invoice Number Regex
        inv_match = re.search(r"(?:Invoice\s*(?:No|Number|#)[\s:]*)([A-Z0-9\-_/]+)", text, re.IGNORECASE)
        if inv_match:
            extracted["invoice_number"] = inv_match.group(1).strip()
            extracted["field_confidences"]["invoice_number"] = 0.99
        else:
            extracted["field_confidences"]["invoice_number"] = 0.50

        # 3. PO Reference Regex (matches "PO Reference: PO-2026-00101" or "PO No: PO-1234")
        po_match = re.search(r"(?:P\.?O\.?\s*(?:Reference|Ref|No|Number)[\s:]*)([A-Z0-9\-]+)", text, re.IGNORECASE)
        if po_match:
            extracted["po_reference"] = po_match.group(1).strip()
            extracted["field_confidences"]["po_reference"] = 0.98

        # 4. Currency
        curr_match = re.search(r"\b(INR|USD|EUR|GBP|₹|Rs\.?)\b", text, re.IGNORECASE)
        if curr_match:
            c_val = curr_match.group(1).upper()
            extracted["currency"] = "INR" if c_val in ("INR", "₹", "RS", "RS.") else c_val
        extracted["field_confidences"]["currency"] = 0.99

        # 5. Invoice & Due Dates
        date_matches = re.findall(r"(\d{4}-\d{2}-\d{2}|\d{2}/\d{2}/\d{4}|\d{2}-\d{2}-\d{4})", text)
        if date_matches:
            extracted["invoice_date"] = date_matches[0]
            extracted["due_date"] = date_matches[1] if len(date_matches) > 1 else date_matches[0]
            extracted["field_confidences"]["dates"] = 0.95
        else:
            extracted["field_confidences"]["dates"] = 0.40

        # 6. GSTIN Matches (Supplier and Recipient)
        gstin_matches = re.findall(r"\b[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}\b", text)
        if len(gstin_matches) >= 2:
            extracted["vendor_gstin"] = gstin_matches[0]
            extracted["recipient_gstin"] = gstin_matches[1]
            extracted["field_confidences"]["gstin"] = 0.99
        elif len(gstin_matches) == 1:
            extracted["vendor_gstin"] = gstin_matches[0]
            extracted["field_confidences"]["gstin"] = 0.90
        else:
            extracted["field_confidences"]["gstin"] = 0.40

        # Place of supply derived from vendor GSTIN
        if extracted["vendor_gstin"]:
            extracted["place_of_supply"] = extracted["vendor_gstin"][:2]

        # 7. Financial Amounts (Taxable, Tax, Total)
        taxable_match = re.search(r"Taxable\s*(?:Value|Amount)[\s:]*(?:INR|Rs\.?|₹)?\s*([\d,]+\.?\d*)", text, re.IGNORECASE)
        if taxable_match:
            extracted["taxable_value"] = float(taxable_match.group(1).replace(",", ""))
            extracted["field_confidences"]["taxable_value"] = 0.98

        cgst_match = re.search(r"CGST(?:\s*\(\d+%\))?[\s:]*(?:INR|Rs\.?|₹)?\s*([\d,]+\.?\d*)", text, re.IGNORECASE)
        if cgst_match:
            extracted["cgst_amount"] = float(cgst_match.group(1).replace(",", ""))

        sgst_match = re.search(r"SGST(?:\s*\(\d+%\))?[\s:]*(?:INR|Rs\.?|₹)?\s*([\d,]+\.?\d*)", text, re.IGNORECASE)
        if sgst_match:
            extracted["sgst_amount"] = float(sgst_match.group(1).replace(",", ""))

        igst_match = re.search(r"IGST(?:\s*\(\d+%\))?[\s:]*(?:INR|Rs\.?|₹)?\s*([\d,]+\.?\d*)", text, re.IGNORECASE)
        if igst_match:
            extracted["igst_amount"] = float(igst_match.group(1).replace(",", ""))

        total_match = re.search(r"Total\s*(?:Invoice\s*)?(?:Amount|Value)[\s:]*(?:INR|Rs\.?|₹)?\s*([\d,]+\.?\d*)", text, re.IGNORECASE)
        if total_match:
            extracted["total_amount"] = float(total_match.group(1).replace(",", ""))
            extracted["field_confidences"]["total_amount"] = 0.99

        extracted["total_tax"] = round(extracted["cgst_amount"] + extracted["sgst_amount"] + extracted["igst_amount"], 2)

        # 8. Line Items Table Extraction
        extracted["line_items"] = cls._extract_line_items(text, extracted)
        extracted["field_confidences"]["line_items"] = 0.95 if extracted["line_items"] else 0.50

        # Calculate composite overall confidence
        conf_values = list(extracted["field_confidences"].values())
        if conf_values:
            extracted["overall_confidence"] = round(sum(conf_values) / len(conf_values), 4)

        return extracted

    @classmethod
    def _extract_line_items(cls, text: str, header_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        lines = [line.strip() for line in text.split("\n") if line.strip()]
        line_items = []

        # Case A: ReportLab / Column-separated table pattern
        # Look for table header markers: "Line", "Item Code", "Description", "HSN", "Qty", "Unit Rate", "Total"
        for i, line in enumerate(lines):
            if line.lower() == "line" and i + 7 < len(lines):
                # Check if headers follow:
                headers_found = (
                    "item code" in lines[i+1].lower() and
                    "description" in lines[i+2].lower() and
                    "hsn" in lines[i+3].lower() and
                    "qty" in lines[i+4].lower()
                )
                if headers_found:
                    # Next elements are row cells
                    # Look ahead for lines after "Total (INR)"
                    start_row = i + 7
                    # Each row has 7 lines: line_no, code, desc, hsn, qty, unit_price, total
                    row_idx = start_row
                    line_num = 1
                    while row_idx + 6 < len(lines) and lines[row_idx].isdigit() and int(lines[row_idx]) == line_num:
                        l_num = int(lines[row_idx])
                        code = lines[row_idx + 1]
                        desc = lines[row_idx + 2]
                        hsn = lines[row_idx + 3]
                        try:
                            qty = float(lines[row_idx + 4].replace(",", ""))
                            price = float(lines[row_idx + 5].replace(",", ""))
                            total = float(lines[row_idx + 6].replace(",", ""))
                        except ValueError:
                            break

                        gst_rate = 18.0
                        if header_data["taxable_value"] > 0:
                            calc_rate = round((header_data["total_tax"] / header_data["taxable_value"]) * 100, 1)
                            if calc_rate in (5.0, 12.0, 18.0, 28.0):
                                gst_rate = calc_rate

                        line_items.append({
                            "line_number": l_num,
                            "item_code": code,
                            "description": desc,
                            "hsn_sac_code": hsn,
                            "quantity": qty,
                            "unit_price": price,
                            "gst_rate": gst_rate,
                            "taxable_amount": round(qty * price, 2),
                            "total_amount": total,
                        })
                        row_idx += 7
                        line_num += 1
                    break

        # Case B: Standard Single-Line Table Row Pattern (e.g. "1  STL-BEAM-01  Heavy Beams  7216  50.00  4,180.00  209,000.00")
        if not line_items:
            row_pattern = re.compile(
                r"^(\d+)\s+([A-Z0-9\-]+)\s+(.+?)\s+(\d{4,8})\s+([\d,.]+)\s+([\d,.]+)\s+([\d,.]+)$"
            )
            for line in lines:
                m = row_pattern.match(line)
                if m:
                    l_num = int(m.group(1))
                    code = m.group(2)
                    desc = m.group(3).strip()
                    hsn = m.group(4)
                    qty = float(m.group(5).replace(",", ""))
                    price = float(m.group(6).replace(",", ""))
                    total = float(m.group(7).replace(",", ""))
                    line_items.append({
                        "line_number": l_num,
                        "item_code": code,
                        "description": desc,
                        "hsn_sac_code": hsn,
                        "quantity": qty,
                        "unit_price": price,
                        "gst_rate": 18.0,
                        "taxable_amount": round(qty * price, 2),
                        "total_amount": total,
                    })

        # Case C: Fallback Single Synthesized Item if totals exist but no table lines parsed
        if not line_items and header_data.get("taxable_value", 0) > 0:
            taxable = header_data["taxable_value"]
            total = header_data.get("total_amount", taxable)
            line_items.append({
                "line_number": 1,
                "item_code": "ITEM-GENERAL",
                "description": f"Invoice item billed under {header_data.get('invoice_number', 'Invoice')}",
                "hsn_sac_code": "9988",
                "quantity": 1.0,
                "unit_price": taxable,
                "gst_rate": 18.0,
                "taxable_amount": taxable,
                "total_amount": total,
            })

        return line_items
