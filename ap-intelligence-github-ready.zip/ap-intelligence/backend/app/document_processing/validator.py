import re
from datetime import datetime, date
from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, Any, List, Optional
from app.document_processing.gst_validator import GSTValidator

class InvoiceValidator:
    """
    Deterministic Financial Validator for Accounts Payable Invoices.
    Performs 100% exact mathematical and statutory checks using decimal.Decimal.
    Zero floating point drift; Zero LLM hallucinations.
    """

    @staticmethod
    def _to_decimal(val: Any) -> Decimal:
        if val is None:
            return Decimal("0.00")
        try:
            # Clean string format
            s = str(val).replace(",", "").strip()
            return Decimal(s).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        except Exception:
            return Decimal("0.00")

    @classmethod
    def validate_invoice(
        cls,
        invoice_data: Dict[str, Any],
        existing_invoices: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        errors: List[str] = []
        warnings: List[str] = []
        field_validations: Dict[str, bool] = {}
        discrepancy_amount = Decimal("0.00")

        # 1. Invoice Number Validation
        inv_num = invoice_data.get("invoice_number")
        if not inv_num or str(inv_num).strip() in ("", "None", "N/A"):
            errors.append("Missing mandatory field: Invoice Number")
            field_validations["invoice_number"] = False
        else:
            clean_num = str(inv_num).strip()
            if not re.match(r"^[A-Za-z0-9\-_/]+$", clean_num) or len(clean_num) < 3:
                errors.append(f"Invalid invoice number format: '{clean_num}'. Must be alphanumeric with - or / (min 3 chars).")
                field_validations["invoice_number"] = False
            else:
                field_validations["invoice_number"] = True

            # Duplicate Invoice check
            if existing_invoices and clean_num in existing_invoices:
                errors.append(f"Duplicate invoice detected: Invoice '{clean_num}' already exists in ledger.")
                field_validations["is_duplicate"] = False
            else:
                field_validations["is_duplicate"] = True

        # 2. Date Format and Chronology Validation
        inv_date = None
        raw_inv_date = invoice_data.get("invoice_date")
        if not raw_inv_date:
            errors.append("Missing mandatory field: Invoice Date")
            field_validations["invoice_date"] = False
        else:
            try:
                if isinstance(raw_inv_date, date):
                    inv_date = raw_inv_date
                else:
                    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
                        try:
                            inv_date = datetime.strptime(str(raw_inv_date).strip(), fmt).date()
                            break
                        except ValueError:
                            pass
                if not inv_date:
                    errors.append(f"Invalid invoice date format: '{raw_inv_date}'. Expected YYYY-MM-DD or DD/MM/YYYY.")
                    field_validations["invoice_date"] = False
                else:
                    field_validations["invoice_date"] = True
            except Exception as e:
                errors.append(f"Date parsing error: {str(e)}")
                field_validations["invoice_date"] = False

        due_date = None
        raw_due_date = invoice_data.get("due_date")
        if raw_due_date:
            try:
                if isinstance(raw_due_date, date):
                    due_date = raw_due_date
                else:
                    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
                        try:
                            due_date = datetime.strptime(str(raw_due_date).strip(), fmt).date()
                            break
                        except ValueError:
                            pass
                if due_date and inv_date and due_date < inv_date:
                    warnings.append(f"Due date ({due_date}) precedes invoice date ({inv_date}).")
                    field_validations["due_date"] = False
                else:
                    field_validations["due_date"] = True
            except Exception:
                field_validations["due_date"] = True

        # 3. Supplier & GSTIN Validation
        vendor_name = invoice_data.get("vendor_name")
        if not vendor_name or str(vendor_name).strip() in ("", "None", "N/A"):
            warnings.append("Supplier name missing or unparsed from invoice document.")
            field_validations["vendor_name"] = False
        else:
            field_validations["vendor_name"] = True

        vendor_gstin = invoice_data.get("vendor_gstin")
        recipient_gstin = invoice_data.get("recipient_gstin")

        if not vendor_gstin:
            errors.append("Missing mandatory field: Supplier GSTIN")
            field_validations["vendor_gstin"] = False
        else:
            gst_res = GSTValidator.validate_format(str(vendor_gstin).strip())
            if not gst_res["is_valid"]:
                errors.append(f"Invalid Supplier GSTIN format: {gst_res.get('error')}")
                field_validations["vendor_gstin"] = False
            else:
                field_validations["vendor_gstin"] = True

        # 4. Deterministic Financial Invariance Checks (Decimal Arithmetic)
        taxable_val = cls._to_decimal(invoice_data.get("taxable_value"))
        cgst = cls._to_decimal(invoice_data.get("cgst_amount"))
        sgst = cls._to_decimal(invoice_data.get("sgst_amount"))
        igst = cls._to_decimal(invoice_data.get("igst_amount"))
        declared_total_tax = cls._to_decimal(invoice_data.get("total_tax"))
        total_amount = cls._to_decimal(invoice_data.get("total_amount"))

        if total_amount <= Decimal("0.00"):
            errors.append("Invalid total invoice amount: Must be greater than ₹0.00")
            field_validations["total_amount_positive"] = False
        else:
            field_validations["total_amount_positive"] = True

        # Tax calculation validation
        calculated_tax = cgst + sgst + igst
        if declared_total_tax > Decimal("0.00") and abs(calculated_tax - declared_total_tax) > Decimal("0.05"):
            errors.append(
                f"Tax breakdown mismatch: CGST ({cgst}) + SGST ({sgst}) + IGST ({igst}) = {calculated_tax}, but declared total tax is {declared_total_tax}."
            )
            field_validations["tax_breakdown"] = False
        else:
            field_validations["tax_breakdown"] = True

        # Statutory Intra vs Inter-State GST consistency
        if vendor_gstin and recipient_gstin:
            v_state = str(vendor_gstin)[:2]
            r_state = str(recipient_gstin)[:2]
            applicability = GSTValidator.determine_tax_applicability(v_state, r_state)
            if applicability == "INTRA_STATE":
                if igst > Decimal("0.00"):
                    warnings.append(f"Statutory Warning: Intra-state transaction (State {v_state}) should not have IGST ({igst}). Expected CGST + SGST.")
                if abs(cgst - sgst) > Decimal("0.05") and (cgst > 0 or sgst > 0):
                    warnings.append(f"Statutory Warning: Intra-state transaction requires equal CGST and SGST (CGST: {cgst}, SGST: {sgst}).")
            else:
                if (cgst > Decimal("0.00") or sgst > Decimal("0.00")) and igst == Decimal("0.00"):
                    warnings.append(f"Statutory Warning: Inter-state transaction (State {v_state} -> {r_state}) should attract IGST instead of CGST/SGST.")

        # Reconcile Grand Total: Taxable Value + Total Tax == Total Amount
        expected_total = taxable_val + (calculated_tax if calculated_tax > 0 else declared_total_tax)
        diff = abs(expected_total - total_amount)
        if diff > Decimal("0.10"):
            errors.append(
                f"Invoice total reconciliation failed: Taxable Value (₹{taxable_val}) + Tax (₹{calculated_tax}) = ₹{expected_total}, but Total is ₹{total_amount}. Variance: ₹{diff}."
            )
            discrepancy_amount = diff
            field_validations["total_reconciliation"] = False
        else:
            field_validations["total_reconciliation"] = True

        # 5. Line Item Validation (if line items present)
        line_items = invoice_data.get("line_items") or []
        if line_items:
            line_taxable_sum = Decimal("0.00")
            for idx, item in enumerate(line_items, 1):
                qty = cls._to_decimal(item.get("quantity"))
                price = cls._to_decimal(item.get("unit_price"))
                line_taxable = cls._to_decimal(item.get("taxable_amount"))

                expected_line_taxable = (qty * price).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                if abs(expected_line_taxable - line_taxable) > Decimal("0.05"):
                    errors.append(
                        f"Line {idx} arithmetic discrepancy: Qty ({qty}) * Unit Price (₹{price}) = ₹{expected_line_taxable}, declared taxable is ₹{line_taxable}."
                    )
                line_taxable_sum += line_taxable

            if taxable_val > 0 and abs(line_taxable_sum - taxable_val) > Decimal("0.10"):
                errors.append(
                    f"Line items sum (₹{line_taxable_sum}) does not match Header Taxable Value (₹{taxable_val}). Difference: ₹{abs(line_taxable_sum - taxable_val)}."
                )
                field_validations["line_items_reconciliation"] = False
            else:
                field_validations["line_items_reconciliation"] = True

        # 6. Extraction Confidence Checks
        overall_conf = float(invoice_data.get("overall_confidence", 0.95))
        if overall_conf < 0.85:
            warnings.append(f"Low composite OCR extraction confidence ({(overall_conf * 100):.1f}%). Human verification required.")
            field_validations["confidence_sufficient"] = False
        else:
            field_validations["confidence_sufficient"] = True

        is_valid = len(errors) == 0
        requires_human_review = not is_valid or len(warnings) > 0 or overall_conf < 0.90

        return {
            "is_valid": is_valid,
            "requires_human_review": requires_human_review,
            "errors": errors,
            "warnings": warnings,
            "discrepancy_amount_inr": float(discrepancy_amount),
            "field_validations": field_validations,
            "validated_totals": {
                "taxable_value": float(taxable_val),
                "total_tax": float(calculated_tax if calculated_tax > 0 else declared_total_tax),
                "total_amount": float(total_amount),
            },
        }

