import re
from typing import Dict, Any, Optional

GSTIN_REGEX = re.compile(r"^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$")
PAN_REGEX = re.compile(r"^[A-Z]{5}[0-9]{4}[A-Z]{1}$")

# Indian State Codes Mapping (GST 2-digit state prefixes)
STATE_CODE_MAP = {
    "01": "Jammu & Kashmir",
    "02": "Himachal Pradesh",
    "03": "Punjab",
    "04": "Chandigarh",
    "05": "Uttarakhand",
    "06": "Haryana",
    "07": "Delhi",
    "08": "Rajasthan",
    "09": "Uttar Pradesh",
    "10": "Bihar",
    "19": "West Bengal",
    "24": "Gujarat",
    "27": "Maharashtra",
    "29": "Karnataka",
    "32": "Kerala",
    "33": "Tamil Nadu",
    "36": "Telangana",
    "37": "Andhra Pradesh",
}

class GSTValidator:
    @staticmethod
    def validate_format(gstin: str) -> Dict[str, Any]:
        """Validates the standard 15-character alphanumeric format of an Indian GSTIN."""
        clean_gstin = gstin.strip().upper() if gstin else ""
        if not clean_gstin:
            return {"is_valid": False, "error": "GSTIN cannot be empty"}

        if len(clean_gstin) != 15:
            return {
                "is_valid": False,
                "error": f"GSTIN length must be exactly 15 characters, got {len(clean_gstin)}",
            }

        if not GSTIN_REGEX.match(clean_gstin):
            return {
                "is_valid": False,
                "error": "GSTIN does not conform to standard format (2-digit state + 10-char PAN + entity + Z + check digit)",
            }

        state_code = clean_gstin[:2]
        pan = clean_gstin[2:12]
        state_name = STATE_CODE_MAP.get(state_code, "Unknown State / Union Territory")

        return {
            "is_valid": True,
            "gstin": clean_gstin,
            "state_code": state_code,
            "state_name": state_name,
            "pan": pan,
            "entity_number": clean_gstin[12],
            "default_z": clean_gstin[13],
            "check_digit": clean_gstin[14],
        }

    @staticmethod
    def determine_tax_applicability(supplier_state_code: str, recipient_state_code: str) -> str:
        """
        Determines whether the supply is Intra-State (CGST + SGST) or Inter-State (IGST).
        """
        if supplier_state_code == recipient_state_code:
            return "INTRA_STATE"  # CGST + SGST apply equally
        else:
            return "INTER_STATE"  # IGST applies

