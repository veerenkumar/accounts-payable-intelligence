from decimal import Decimal
from typing import Dict, Any, List, Optional
from datetime import datetime
from sqlalchemy.orm import Session

from app.models.financial_entities import (
    Invoice,
    InvoiceItem,
    PurchaseOrder,
    POItem,
    GoodsReceiptNote,
    GRNItem,
    MatchingResult,
    ExceptionRecord,
    ApprovalRequest,
    AuditLog,
    Vendor,
)
from app.matching.engine import (
    DeterministicMatchingEngine,
    MatchingInput,
    LineItemData,
    ThreeWayMatchVerdict,
)

class MatchingService:
    """
    Orchestrates deterministic three-way matching against SQLite ledger entities.
    Enforces tolerance policies, multi-GRN aggregation, exception routing, and human approval gates.
    """

    @classmethod
    def evaluate_invoice_matching(
        cls,
        invoice_id: str,
        db: Session,
        price_tolerance_pct: Decimal = Decimal("2.0"),
        qty_tolerance_pct: Decimal = Decimal("0.0"),
        tax_tolerance_inr: Decimal = Decimal("5.0"),
        classify_partial_receipt: bool = True,
    ) -> Dict[str, Any]:
        invoice = db.query(Invoice).filter(Invoice.id == invoice_id).first()
        if not invoice:
            raise ValueError(f"Invoice '{invoice_id}' not found in database.")

        vendor = db.query(Vendor).filter(Vendor.id == invoice.vendor_id).first()
        vendor_name = vendor.name if vendor else invoice.vendor_id

        # 1. Duplicate Invoice Check in SQLite Ledger
        existing_duplicate = (
            db.query(Invoice)
            .filter(
                Invoice.id != invoice.id,
                Invoice.vendor_id == invoice.vendor_id,
                Invoice.id == invoice.id,
            )
            .first()
        )
        is_duplicate = bool(existing_duplicate) or (invoice.payment_status == "PAID" and invoice.status == "PAID")

        # 2. Purchase Order Lookup & Supplier Verification
        po = None
        po_items_data: List[LineItemData] = []
        if invoice.po_reference:
            po = db.query(PurchaseOrder).filter(PurchaseOrder.id == invoice.po_reference).first()
            if po:
                for p_item in po.items:
                    po_items_data.append(
                        LineItemData(
                            item_code=p_item.item_code,
                            description=p_item.description,
                            quantity=Decimal(str(p_item.quantity)),
                            unit_price=Decimal(str(p_item.unit_price_inr)),
                            gst_rate=Decimal(str(p_item.gst_rate_percent)),
                            taxable_amount=Decimal(str(p_item.taxable_amount_inr)),
                            total_amount=Decimal(str(p_item.total_line_amount_inr)),
                        )
                    )

        # 3. Goods Receipt Notes Lookup (Supporting Multi-GRN Aggregation & Partial Deliveries)
        grns: List[GoodsReceiptNote] = []
        grn_items_map: Dict[str, Decimal] = {}
        grn_received_map: Dict[str, Decimal] = {}
        grn_id_str: Optional[str] = None

        if po:
            grns = db.query(GoodsReceiptNote).filter(GoodsReceiptNote.po_id == po.id).all()
            if grns:
                grn_id_str = ", ".join(g.id for g in grns)
                for g in grns:
                    for g_item in g.items:
                        code = g_item.item_code
                        acc = Decimal(str(g_item.quantity_accepted))
                        rec = Decimal(str(g_item.quantity_received))
                        grn_items_map[code] = grn_items_map.get(code, Decimal("0.000")) + acc
                        grn_received_map[code] = grn_received_map.get(code, Decimal("0.000")) + rec

        # 4. Invoice Line Items Transformation
        inv_items_data: List[LineItemData] = []
        for i_item in invoice.items:
            inv_items_data.append(
                LineItemData(
                    item_code=i_item.item_code,
                    description=i_item.description,
                    quantity=Decimal(str(i_item.quantity)),
                    unit_price=Decimal(str(i_item.unit_price_inr)),
                    gst_rate=Decimal(str(i_item.gst_rate_percent)),
                    taxable_amount=Decimal(str(i_item.taxable_amount_inr)),
                    total_amount=Decimal(str(i_item.total_line_amount_inr)),
                )
            )

        # Fallback if invoice has header amounts but no items persisted yet
        if not inv_items_data and po_items_data:
            inv_items_data = [
                LineItemData(
                    item_code=po_items_data[0].item_code,
                    description=po_items_data[0].description,
                    quantity=po_items_data[0].quantity,
                    unit_price=Decimal(str(invoice.taxable_value_inr)) / po_items_data[0].quantity if po_items_data[0].quantity > 0 else Decimal("0"),
                    gst_rate=po_items_data[0].gst_rate,
                    taxable_amount=Decimal(str(invoice.taxable_value_inr)),
                    total_amount=Decimal(str(invoice.total_amount_inr)),
                )
            ]

        # 5. Build Matching Input Payload
        matching_input = MatchingInput(
            invoice_id=invoice.id,
            vendor_id=invoice.vendor_id,
            po_reference=invoice.po_reference,
            invoice_items=inv_items_data,
            invoice_total_taxable=Decimal(str(invoice.taxable_value_inr)),
            invoice_total_tax=Decimal(str(invoice.total_tax_inr)),
            invoice_total_amount=Decimal(str(invoice.total_amount_inr)),
            po_id=po.id if po else None,
            po_vendor_id=po.vendor_id if po else None,
            po_status=po.status if po else None,
            po_items=po_items_data,
            grn_id=grn_id_str,
            grn_items=grn_items_map,
            price_tolerance_pct=price_tolerance_pct,
            qty_tolerance_pct=qty_tolerance_pct,
            tax_tolerance_inr=tax_tolerance_inr,
            is_duplicate_invoice=is_duplicate,
            classify_partial_receipt=classify_partial_receipt,
        )

        # 6. Execute Deterministic Python Mathematical Matching
        verdict: ThreeWayMatchVerdict = DeterministicMatchingEngine.evaluate_3way_match(matching_input)

        # 7. Persist MatchingResult in SQLite
        matching_record = db.query(MatchingResult).filter(MatchingResult.invoice_id == invoice.id).first()
        if not matching_record:
            matching_record = MatchingResult(invoice_id=invoice.id)
            db.add(matching_record)

        matching_record.po_id = verdict.po_id
        matching_record.grn_id = verdict.grn_id
        matching_record.match_status = verdict.match_status
        matching_record.price_variance_percent = verdict.total_price_variance_pct
        matching_record.quantity_variance_percent = verdict.total_quantity_variance_pct
        matching_record.tax_variance_inr = verdict.total_tax_variance_inr
        matching_record.total_financial_impact_inr = verdict.total_financial_impact_inr
        matching_record.is_matched = verdict.is_matched
        matching_record.evaluation_notes = verdict.evaluation_notes
        matching_record.line_evaluations = [li.model_dump(mode="json") for li in verdict.line_evaluations]
        matching_record.discrepancies = verdict.discrepancies
        matching_record.evaluated_at = datetime.utcnow()

        # 8. Update Invoice Status & Workflow Routing
        invoice.match_status = verdict.match_status

        # Check for unresolved open exceptions in SQLite
        open_exceptions = (
            db.query(ExceptionRecord)
            .filter(ExceptionRecord.invoice_id == invoice.id, ExceptionRecord.status == "OPEN")
            .all()
        )

        if verdict.is_matched and not open_exceptions:
            # Human Approval Gate: Set PENDING_APPROVAL. NEVER automatically disburse or pay!
            invoice.status = "PENDING_APPROVAL"

            # Determine required approval role based on statutory authority matrix
            total_amt = Decimal(str(invoice.total_amount_inr))
            if total_amt <= Decimal("100000.00"):
                required_role = "FINANCE_EXECUTIVE"
            elif total_amt <= Decimal("1000000.00"):
                required_role = "AP_MANAGER"
            else:
                required_role = "FINANCE_CONTROLLER"

            existing_reqs = db.query(ApprovalRequest).filter(ApprovalRequest.invoice_id == invoice.id).all()
            if not existing_reqs:
                approval_req = ApprovalRequest(
                    id=f"APR-{invoice.id.replace('INV-', '')}",
                    invoice_id=invoice.id,
                    required_role=required_role,
                    amount_inr=invoice.total_amount_inr,
                    status="PENDING",
                )
                db.add(approval_req)
            else:
                for req in existing_reqs:
                    req.amount_inr = invoice.total_amount_inr
                    req.required_role = required_role
                    req.status = "PENDING"

        else:
            # Discrepancy Routing: Set EXCEPTION_HOLD and route to Exception Workbench
            invoice.status = "EXCEPTION_HOLD"

            # Financial Control Guard: Any existing approval requests MUST be held.
            # An invoice on EXCEPTION_HOLD must never be PENDING or APPROVED.
            existing_reqs = db.query(ApprovalRequest).filter(ApprovalRequest.invoice_id == invoice.id).all()
            for req in existing_reqs:
                req.status = "HELD"
                req.amount_inr = invoice.total_amount_inr

            # Determine responsible department and severity
            if verdict.match_status in ("DUPLICATE_INVOICE", "VENDOR_MISMATCH"):
                severity = "CRITICAL"
                resp_dept = "Finance & Compliance"
            elif verdict.match_status == "PRICE_MISMATCH":
                severity = "HIGH" if verdict.total_financial_impact_inr > Decimal("50000") else "MEDIUM"
                resp_dept = "Procurement"
            elif verdict.match_status == "QUANTITY_MISMATCH":
                severity = "HIGH" if verdict.total_financial_impact_inr > Decimal("50000") else "MEDIUM"
                resp_dept = "Warehouse & Logistics"
            elif verdict.match_status == "TAX_MISMATCH":
                severity = "MEDIUM"
                resp_dept = "Tax & Statutory Compliance"
            else:
                severity = "HIGH"
                resp_dept = "Accounts Payable"

            exc_id = f"EXC-{invoice.id.replace('INV-', '')}"
            existing_exc = db.query(ExceptionRecord).filter(ExceptionRecord.id == exc_id).first()
            if not existing_exc:
                new_exc = ExceptionRecord(
                    id=exc_id,
                    invoice_id=invoice.id,
                    category=verdict.match_status,
                    severity=severity,
                    expected_value=f"PO {po.id} rate/qty" if po else "Approved PO baseline",
                    actual_value=f"Billed: INR {float(invoice.total_amount_inr):,.2f}",
                    difference_value=verdict.discrepancies[0] if verdict.discrepancies else f"Discrepancy: INR {float(verdict.total_financial_impact_inr):,.2f}",
                    financial_impact_inr=verdict.total_financial_impact_inr,
                    responsible_department=resp_dept,
                    status="OPEN",
                    resolution_notes=f"Investigate {verdict.match_status}. Issue debit note or request PO amendment.",
                )
                db.add(new_exc)
            else:
                existing_exc.category = verdict.match_status
                existing_exc.severity = severity
                existing_exc.financial_impact_inr = verdict.total_financial_impact_inr
                existing_exc.difference_value = verdict.discrepancies[0] if verdict.discrepancies else existing_exc.difference_value
                if existing_exc.status != "RESOLVED":
                    existing_exc.status = "OPEN"

        # 9. Audit Trail
        audit = AuditLog(
            entity_type="THREE_WAY_MATCH",
            entity_id=invoice.id,
            action=f"MATCH_EVALUATED_{verdict.match_status}",
            actor_type="SYSTEM",
            actor_id="deterministic-matching-engine",
            new_state={
                "match_status": verdict.match_status,
                "is_matched": verdict.is_matched,
                "price_variance_pct": float(verdict.total_price_variance_pct),
                "quantity_variance_pct": float(verdict.total_quantity_variance_pct),
                "tax_variance_inr": float(verdict.total_tax_variance_inr),
                "total_financial_impact_inr": float(verdict.total_financial_impact_inr),
                "discrepancies_count": len(verdict.discrepancies),
            },
        )
        db.add(audit)
        db.commit()
        db.refresh(matching_record)

        # 10. Return Structured Presentation Object
        return {
            "invoice_id": invoice.id,
            "vendor_id": invoice.vendor_id,
            "vendor_name": vendor_name,
            "po_id": verdict.po_id,
            "grn_id": verdict.grn_id,
            "match_status": verdict.match_status,
            "is_matched": verdict.is_matched,
            "price_variance_percent": float(verdict.total_price_variance_pct),
            "quantity_variance_percent": float(verdict.total_quantity_variance_pct),
            "tax_variance_inr": float(verdict.total_tax_variance_inr),
            "total_financial_impact_inr": float(verdict.total_financial_impact_inr),
            "evaluation_notes": verdict.evaluation_notes,
            "discrepancies": verdict.discrepancies,
            "line_evaluations": [
                {
                    "item_code": li.item_code,
                    "description": li.description,
                    "invoice_qty": float(li.invoice_qty),
                    "grn_accepted_qty": float(li.grn_accepted_qty),
                    "invoice_unit_price": float(li.invoice_unit_price),
                    "po_unit_price": float(li.po_unit_price),
                    "price_variance_pct": float(li.price_variance_pct),
                    "quantity_variance_pct": float(li.quantity_variance_pct),
                    "financial_impact_inr": float(li.financial_impact_inr),
                    "status": li.status,
                    "reason": li.reason,
                }
                for li in verdict.line_evaluations
            ],
            "tolerances_applied": {
                "price_tolerance_pct": float(price_tolerance_pct),
                "tax_tolerance_inr": float(tax_tolerance_inr),
                "qty_tolerance_pct": float(qty_tolerance_pct),
            },
            "evaluated_at": matching_record.evaluated_at.isoformat() if matching_record.evaluated_at else datetime.utcnow().isoformat(),
        }

