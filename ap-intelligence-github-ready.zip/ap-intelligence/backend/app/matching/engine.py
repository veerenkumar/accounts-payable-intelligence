from decimal import Decimal, ROUND_HALF_UP
from typing import List, Dict, Any, Optional
from pydantic import BaseModel

class LineItemData(BaseModel):
    item_code: str
    description: str
    quantity: Decimal
    unit_price: Decimal
    gst_rate: Decimal
    taxable_amount: Decimal
    total_amount: Decimal

class MatchingInput(BaseModel):
    invoice_id: str
    vendor_id: str
    po_reference: Optional[str]
    invoice_items: List[LineItemData]
    invoice_total_taxable: Decimal
    invoice_total_tax: Decimal
    invoice_total_amount: Decimal
    
    # Associated PO Data
    po_id: Optional[str] = None
    po_vendor_id: Optional[str] = None
    po_status: Optional[str] = None
    po_items: List[LineItemData] = []
    
    # Associated GRN Data
    grn_id: Optional[str] = None
    grn_items: Dict[str, Decimal] = {}  # item_code -> accepted_qty
    
    # Tolerances
    price_tolerance_pct: Decimal = Decimal("2.0")
    qty_tolerance_pct: Decimal = Decimal("0.0")
    tax_tolerance_inr: Decimal = Decimal("5.0")
    
    # Duplicate check flag
    is_duplicate_invoice: bool = False
    
    # Partial delivery handling
    classify_partial_receipt: bool = False

class LineMatchingResult(BaseModel):
    item_code: str
    description: str
    invoice_qty: Decimal
    grn_accepted_qty: Decimal
    invoice_unit_price: Decimal
    po_unit_price: Decimal
    price_variance_pct: Decimal
    quantity_variance_pct: Decimal
    financial_impact_inr: Decimal
    status: str  # EXACT, TOLERANCE_PASSED, PRICE_MISMATCH, QTY_MISMATCH, ITEM_NOT_FOUND
    reason: Optional[str] = None

class ThreeWayMatchVerdict(BaseModel):
    invoice_id: str
    po_id: Optional[str]
    grn_id: Optional[str]
    match_status: str  # EXACT_MATCH, MATCH_WITHIN_TOLERANCE, PRICE_MISMATCH, QUANTITY_MISMATCH, etc.
    is_matched: bool
    total_price_variance_pct: Decimal
    total_quantity_variance_pct: Decimal
    total_tax_variance_inr: Decimal
    total_financial_impact_inr: Decimal
    line_evaluations: List[LineMatchingResult]
    discrepancies: List[str]
    evaluation_notes: str

class DeterministicMatchingEngine:
    """
    Mathematical financial reconciliation engine.
    Uses strict decimal arithmetic to guarantee zero floating point rounding errors.
    """

    @classmethod
    def evaluate_3way_match(cls, payload: MatchingInput) -> ThreeWayMatchVerdict:
        discrepancies: List[str] = []
        line_evaluations: List[LineMatchingResult] = []
        total_financial_impact = Decimal("0.00")

        # Check 1: Duplicate Invoice Check
        if payload.is_duplicate_invoice:
            return ThreeWayMatchVerdict(
                invoice_id=payload.invoice_id,
                po_id=payload.po_id,
                grn_id=payload.grn_id,
                match_status="DUPLICATE_INVOICE",
                is_matched=False,
                total_price_variance_pct=Decimal("0.00"),
                total_quantity_variance_pct=Decimal("0.00"),
                total_tax_variance_inr=Decimal("0.00"),
                total_financial_impact_inr=payload.invoice_total_amount,
                line_evaluations=[],
                discrepancies=["Invoice number or reference identical to previously settled payment voucher."],
                evaluation_notes="Critical Risk Alert: Duplicate invoice detected. Payment on hold.",
            )

        # Check 2: Missing Purchase Order
        if not payload.po_id or not payload.po_reference:
            return ThreeWayMatchVerdict(
                invoice_id=payload.invoice_id,
                po_id=None,
                grn_id=payload.grn_id,
                match_status="MISSING_PO",
                is_matched=False,
                total_price_variance_pct=Decimal("0.00"),
                total_quantity_variance_pct=Decimal("0.00"),
                total_tax_variance_inr=Decimal("0.00"),
                total_financial_impact_inr=payload.invoice_total_amount,
                line_evaluations=[],
                discrepancies=["No valid Purchase Order reference found on supplier invoice."],
                evaluation_notes="Reconciliation Failed: Missing authorized Purchase Order commitment.",
            )

        # Check 3: Vendor Mismatch
        if payload.po_vendor_id and payload.po_vendor_id != payload.vendor_id:
            return ThreeWayMatchVerdict(
                invoice_id=payload.invoice_id,
                po_id=payload.po_id,
                grn_id=payload.grn_id,
                match_status="VENDOR_MISMATCH",
                is_matched=False,
                total_price_variance_pct=Decimal("0.00"),
                total_quantity_variance_pct=Decimal("0.00"),
                total_tax_variance_inr=Decimal("0.00"),
                total_financial_impact_inr=payload.invoice_total_amount,
                line_evaluations=[],
                discrepancies=[f"Invoice vendor {payload.vendor_id} does not match PO vendor {payload.po_vendor_id}."],
                evaluation_notes="Reconciliation Failed: Entity mismatch between supplier invoice and purchase order.",
            )

        # Check 4: Missing Goods Receipt Note
        if not payload.grn_id or not payload.grn_items:
            return ThreeWayMatchVerdict(
                invoice_id=payload.invoice_id,
                po_id=payload.po_id,
                grn_id=None,
                match_status="MISSING_GRN",
                is_matched=False,
                total_price_variance_pct=Decimal("0.00"),
                total_quantity_variance_pct=Decimal("0.00"),
                total_tax_variance_inr=Decimal("0.00"),
                total_financial_impact_inr=payload.invoice_total_amount,
                line_evaluations=[],
                discrepancies=["No warehouse Goods Receipt Note (GRN) found for purchase order."],
                evaluation_notes="Reconciliation Failed: Materials/services have not been recorded as physically received.",
            )

        # Check 5: Line-by-Line Triangulation
        po_items_map = {p.item_code: p for p in payload.po_items}
        has_price_mismatch = False
        has_qty_mismatch = False
        has_item_mismatch = False
        has_tolerance_pass = False
        is_partial_delivery = False
        max_price_var = Decimal("0.00")
        max_qty_var = Decimal("0.00")

        for inv_item in payload.invoice_items:
            po_item = po_items_map.get(inv_item.item_code)
            if not po_item:
                has_item_mismatch = True
                discrepancies.append(f"Item code {inv_item.item_code} was not authorized on PO {payload.po_id}.")
                line_evaluations.append(
                    LineMatchingResult(
                        item_code=inv_item.item_code,
                        description=inv_item.description,
                        invoice_qty=inv_item.quantity,
                        grn_accepted_qty=Decimal("0.00"),
                        invoice_unit_price=inv_item.unit_price,
                        po_unit_price=Decimal("0.00"),
                        price_variance_pct=Decimal("100.00"),
                        quantity_variance_pct=Decimal("100.00"),
                        financial_impact_inr=inv_item.total_amount,
                        status="ITEM_NOT_FOUND",
                        reason="Item not present in PO line specification.",
                    )
                )
                total_financial_impact += inv_item.total_amount
                continue

            # Check quantity against GRN accepted quantity
            grn_accepted = payload.grn_items.get(inv_item.item_code, Decimal("0.00"))
            
            # An invoice is only penalized if billed quantity EXCEEDS what was accepted at warehouse
            # (If warehouse accepted more than billed, the organization is not overbilled)
            qty_diff = inv_item.quantity - grn_accepted
            qty_var_pct = Decimal("0.00")
            if grn_accepted > 0:
                qty_var_pct = ((qty_diff / grn_accepted) * Decimal("100")).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            elif inv_item.quantity > 0:
                qty_var_pct = Decimal("100.00")

            if abs(qty_var_pct) > max_qty_var:
                max_qty_var = abs(qty_var_pct)

            # Check if this represents an authorized partial delivery against a larger PO
            if grn_accepted < po_item.quantity and inv_item.quantity <= grn_accepted:
                is_partial_delivery = True

            # Check price against PO unit price
            price_diff = inv_item.unit_price - po_item.unit_price
            price_var_pct = Decimal("0.00")
            if po_item.unit_price > 0:
                price_var_pct = ((price_diff / po_item.unit_price) * Decimal("100")).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

            if abs(price_var_pct) > max_price_var:
                max_price_var = abs(price_var_pct)

            # Evaluate variances against configured tolerance thresholds
            line_status = "EXACT"
            reason = None
            line_impact = Decimal("0.00")

            # Only trigger quantity discrepancy if supplier billed MORE than warehouse accepted
            if qty_diff > 0:
                if qty_var_pct > payload.qty_tolerance_pct:
                    line_status = "QTY_MISMATCH"
                    has_qty_mismatch = True
                    line_impact += abs(qty_diff * inv_item.unit_price)
                    reason = f"Billed quantity ({inv_item.quantity}) exceeds warehouse accepted quantity ({grn_accepted})."
                    discrepancies.append(reason)

            if price_diff != 0:
                if abs(price_var_pct) > payload.price_tolerance_pct:
                    line_status = "PRICE_MISMATCH"
                    has_price_mismatch = True
                    line_impact += abs(price_diff * inv_item.quantity)
                    reason = f"Invoiced unit rate (₹{inv_item.unit_price}) exceeds PO rate (₹{po_item.unit_price}) by {price_var_pct}% (Max: {payload.price_tolerance_pct}%)."
                    discrepancies.append(reason)
                else:
                    if line_status == "EXACT":
                        line_status = "TOLERANCE_PASSED"
                        has_tolerance_pass = True

            total_financial_impact += line_impact

            line_evaluations.append(
                LineMatchingResult(
                    item_code=inv_item.item_code,
                    description=inv_item.description,
                    invoice_qty=inv_item.quantity,
                    grn_accepted_qty=grn_accepted,
                    invoice_unit_price=inv_item.unit_price,
                    po_unit_price=po_item.unit_price,
                    price_variance_pct=price_var_pct,
                    quantity_variance_pct=qty_var_pct,
                    financial_impact_inr=line_impact.quantize(Decimal("0.01")),
                    status=line_status,
                    reason=reason,
                )
            )

        # Tax Reconciliation Check against PO statutory GST rates and tolerance
        expected_tax = sum(
            (inv_item.taxable_amount * (po_items_map[inv_item.item_code].gst_rate / Decimal("100"))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            for inv_item in payload.invoice_items
            if inv_item.item_code in po_items_map
        )
        tax_diff = abs(payload.invoice_total_tax - expected_tax)
        has_tax_mismatch = False
        if tax_diff > payload.tax_tolerance_inr:
            has_tax_mismatch = True
            discrepancies.append(
                f"Invoiced tax amount (₹{payload.invoice_total_tax:,.2f}) differs from statutory expected tax (₹{expected_tax:,.2f}) by ₹{tax_diff:,.2f} (exceeds allowable rounding threshold of ₹{payload.tax_tolerance_inr:,.2f})."
            )
            total_financial_impact += tax_diff

        # Final Overall Match Classification
        if has_item_mismatch:
            match_status = "ITEM_MISMATCH"
            is_matched = False
            notes = "Reconciliation halted: Line item on invoice does not exist on authorized purchase order."
        elif has_qty_mismatch:
            match_status = "QUANTITY_MISMATCH"
            is_matched = False
            notes = "Reconciliation halted: Line quantity discrepancies detected against warehouse delivery receipts."
        elif has_price_mismatch:
            match_status = "PRICE_MISMATCH"
            is_matched = False
            notes = "Reconciliation halted: Supplier invoiced price exceeds policy tolerance limits."
        elif has_tax_mismatch:
            match_status = "TAX_MISMATCH"
            is_matched = False
            notes = f"Reconciliation halted: Tax discrepancy of ₹{tax_diff:,.2f} exceeds allowable tolerance of ₹{payload.tax_tolerance_inr:,.2f}."
        elif is_partial_delivery and payload.classify_partial_receipt:
            match_status = "PARTIAL_RECEIPT"
            is_matched = True
            notes = "Reconciliation approved: Invoiced quantities match partial goods receipts against open purchase order."
        elif has_tolerance_pass:
            match_status = "MATCH_WITHIN_TOLERANCE"
            is_matched = True
            notes = "Reconciliation approved: Financial variances are within permitted master tolerance thresholds."
        else:
            match_status = "EXACT_MATCH"
            is_matched = True
            notes = "Reconciliation approved: Exact line-item matching across PO, GRN, and Invoice."

        return ThreeWayMatchVerdict(
            invoice_id=payload.invoice_id,
            po_id=payload.po_id,
            grn_id=payload.grn_id,
            match_status=match_status,
            is_matched=is_matched,
            total_price_variance_pct=max_price_var,
            total_quantity_variance_pct=max_qty_var,
            total_tax_variance_inr=tax_diff.quantize(Decimal("0.01")),
            total_financial_impact_inr=total_financial_impact.quantize(Decimal("0.01")),
            line_evaluations=line_evaluations,
            discrepancies=discrepancies,
            evaluation_notes=notes,
        )

