from typing import List, Optional
from pydantic_settings import BaseSettings
from pydantic import Field

class Settings(BaseSettings):
    APP_NAME: str = "AP INTELLIGENCE"
    APP_ENV: str = "development"
    APP_VERSION: str = "1.0.0"
    API_V1_PREFIX: str = "/api/v1"
    
    # Database
    DATABASE_URL: str = "sqlite:///./ap_intelligence.db"
    USE_SQLITE_FALLBACK: bool = True
    
    # Security & JWT
    JWT_SECRET_KEY: str = "ap-intelligence-super-secure-dev-secret-key-2026"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 480
    
    # Financial Matching Tolerances
    MATCH_PRICE_TOLERANCE_PERCENT: float = 2.0
    MATCH_QTY_TOLERANCE_PERCENT: float = 0.0
    MATCH_TAX_TOLERANCE_INR: float = 5.0
    
    # Approval Monetary Limits (INR)
    APPROVAL_LIMIT_FINANCE_EXECUTIVE_INR: float = 100000.0
    APPROVAL_LIMIT_AP_MANAGER_INR: float = 1000000.0
    
    # Corporate GST Entity (Fictional Recipient for Demo)
    CORPORATE_ENTITY_NAME: str = "Apex Bharat Manufacturing Pvt. Ltd."
    CORPORATE_GSTIN: str = "27AABCA9876K1Z5"
    CORPORATE_STATE_CODE: str = "27"
    
    # LLM Settings
    LLM_PROVIDER: str = "gemini"
    GEMINI_API_KEY: Optional[str] = None
    OPENAI_API_KEY: Optional[str] = None
    ENABLE_DETERMINISTIC_AGENT_FALLBACK: bool = True

    class Config:
        env_file = ".env"
        extra = "ignore"

settings = Settings()

