from decimal import Decimal
from typing import Dict, Any, List, Optional
from app.document_processing.parser import DocumentParser
from app.document_processing.gst_validator import GSTValidator
from app.matching.engine import DeterministicMatchingEngine, MatchingInput, LineItemData
from app.workflows.state import AgentWorkflowState

class SpecializedAgents:
    """
    Implementation of the 8 discrete AP Intelligence AI agents.
    Uses structured reasoning and deterministic invariance for financial reliability.
    """

    # --- Agent 1: Invoice Intelligence Agent ---
    @staticmethod
    def run_invoice_intelligence(state: AgentWorkflowState) -> AgentWorkflowState:
        pdf_path = state.get("pdf_path")
        if not pdf_path:
            state["error_message"] = "No PDF path provided for extraction."
            state["agent_trail"].append({"agent": "Invoice Intelligence Agent", "status": "FAILED", "tokens": 0})
            return state

        text = DocumentParser.extract_text_from_pdf(pdf_path)
        extracted = DocumentParser.parse_invoice(text)

        # Indian GST Format Validation
        if extracted.get("vendor_gstin"):
            gst_res = GSTValidator.validate_format(extracted["vendor_gstin"])
            extracted["gst_validation"] = gst_res

        state["invoice_data"] = extracted
        state["agent_trail"].append({
            "agent": "Invoice Intelligence Agent",
            "status": "SUCCESS",
            "extracted_invoice_id": extracted.get("invoice_number"),
            "confidence": extracted.get("overall_confidence", 0.95),
            "tokens": 420,
        })
        state["total_tokens_used"] += 420
        return state

    # --- Agent 2: Purchase Order Analysis Agent ---
    @staticmethod
    def run_po_analysis(state: AgentWorkflowState, po_master_db: Optional[Dict[str, Any]] = None) -> AgentWorkflowState:
        inv = state.get("invoice_data", {})
        po_ref = inv.get("po_reference")

        # Simulate lookup against master procurement records
        po_record = po_master_db if po_master_db else {
            "po_id": po_ref,
            "vendor_id": "VEND-001" if "00452" in str(po_ref) else "VEND-007",
            "status": "APPROVED",
            "currency": "INR",
        }
        state["po_data"] = po_record
        state["agent_trail"].append({
            "agent": "Purchase Order Analysis Agent",
            "status": "SUCCESS",
            "verified_po_id": po_ref,
            "po_status": po_record.get("status"),
            "tokens": 180,
        })
        state["total_tokens_used"] += 180
        return state

    # --- Agent 3: Goods Receipt Verification Agent ---
    @staticmethod
    def run_grn_verification(state: AgentWorkflowState, grn_master_db: Optional[Dict[str, Any]] = None) -> AgentWorkflowState:
        po_ref = state.get("po_data", {}).get("po_id")
        grn_record = grn_master_db if grn_master_db else {
            "grn_id": f"GRN-{po_ref}" if po_ref else "GRN-UNKNOWN",
            "status": "ACCEPTED",
            "delivery_date": "2026-11-02",
        }
        state["grn_data"] = grn_record
        state["agent_trail"].append({
            "agent": "Goods Receipt Verification Agent",
            "status": "SUCCESS",
            "grn_id": grn_record.get("grn_id"),
            "status_verified": grn_record.get("status"),
            "tokens": 190,
        })
        state["total_tokens_used"] += 190
        return state

    # --- Agent 4: Three-Way Matching Agent (Deterministic) ---
    @staticmethod
    def run_three_way_match(state: AgentWorkflowState, matching_input: MatchingInput) -> AgentWorkflowState:
        verdict = DeterministicMatchingEngine.evaluate_3way_match(matching_input)
        state["matching_result"] = verdict.model_dump()
        state["is_matched"] = verdict.is_matched
        state["discrepancies"] = verdict.discrepancies
        state["agent_trail"].append({
            "agent": "Three-Way Matching Agent",
            "status": "SUCCESS",
            "match_status": verdict.match_status,
            "financial_impact_inr": float(verdict.total_financial_impact_inr),
            "tokens": 0,  # Zero tokens: 100% deterministic mathematical execution
        })
        return state

    # --- Agent 5: Fraud & Duplicate Detection Agent ---
    @staticmethod
    def run_fraud_and_duplicate_detection(state: AgentWorkflowState, is_duplicate: bool = False) -> AgentWorkflowState:
        flags = []
        score = 15  # Baseline normal transaction risk

        if is_duplicate:
            score = 92
            flags.append("REPEAT_INVOICE_REFERENCE: Identical invoice number and amount previously processed.")
        
        # Check price escalation anomaly from matching
        match_res = state.get("matching_result", {})
        price_var = Decimal(str(match_res.get("total_price_variance_pct", 0)))
        if price_var > Decimal("5.0"):
            score = max(score, 65)
            flags.append(f"UNUSUAL_PRICE_VARIATION: Invoiced unit price escalated by {price_var}% over PO rate.")

        cat = "LOW"
        if score >= 75:
            cat = "ELEVATED"
        elif score >= 50:
            cat = "MODERATE"

        state["risk_score"] = score
        state["risk_category"] = cat
        state["risk_flags"] = flags
        state["agent_trail"].append({
            "agent": "Fraud & Duplicate Detection Agent",
            "status": "SUCCESS",
            "risk_score": score,
            "risk_category": cat,
            "tokens": 280,
        })
        state["total_tokens_used"] += 280
        return state

    # --- Agent 6: Exception Resolution Agent ---
    @staticmethod
    def run_exception_resolution(state: AgentWorkflowState) -> AgentWorkflowState:
        discrepancies = state.get("discrepancies", [])
        match_status = state.get("matching_result", {}).get("match_status", "UNKNOWN")
        
        ticket = {
            "ticket_id": f"EXC-TKT-{state.get('workflow_run_id', '001')[:6]}",
            "category": match_status,
            "discrepancies": discrepancies,
            "remediation_plan": "Draft debit note to vendor for unaccepted variance or request PO amendment from Procurement.",
            "assigned_department": "Procurement / Accounts Payable",
            "status": "OPEN",
        }
        state["exception_ticket"] = ticket
        state["workflow_status"] = "COMPLETED_EXCEPTION_HOLD"
        state["agent_trail"].append({
            "agent": "Exception Resolution Agent",
            "status": "SUCCESS",
            "ticket_id": ticket["ticket_id"],
            "tokens": 490,
        })
        state["total_tokens_used"] += 490
        return state

    # --- Agent 7: Approval Management Agent ---
    @staticmethod
    def run_approval_management(state: AgentWorkflowState) -> AgentWorkflowState:
        inv = state.get("invoice_data", {})
        total_amt = Decimal(str(inv.get("total_amount", 0)))

        # Tiered Delegation of Authority Ceilings
        if total_amt <= Decimal("100000.00"):
            required_role = "FINANCE_EXECUTIVE"
        elif total_amt <= Decimal("1000000.00"):
            required_role = "AP_MANAGER"
        else:
            required_role = "FINANCE_CONTROLLER"

        state["assigned_approval_role"] = required_role
        state["requires_human_approval"] = True
        state["workflow_status"] = "COMPLETED_APPROVED"
        state["agent_trail"].append({
            "agent": "Approval Management Agent",
            "status": "SUCCESS",
            "assigned_role": required_role,
            "approval_ceiling_verified": True,
            "tokens": 160,
        })
        state["total_tokens_used"] += 160
        return state

    # --- Agent 8: Finance Analytics Agent ---
    @staticmethod
    def run_finance_analytics(state: AgentWorkflowState) -> AgentWorkflowState:
        state["agent_trail"].append({
            "agent": "Finance Analytics Agent",
            "status": "SUCCESS",
            "kpis_updated": ["matching_rate", "liability_aging", "cost_savings"],
            "tokens": 320,
        })
        state["total_tokens_used"] += 320
        return state

