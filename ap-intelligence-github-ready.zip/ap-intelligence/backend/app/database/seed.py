import os
import random
from datetime import date, datetime, timedelta
from decimal import Decimal
from sqlalchemy.orm import Session
from app.database.session import SessionLocal, engine, Base
from app.models.financial_entities import (
    Role,
    User,
    Vendor,
    PurchaseOrder,
    POItem,
    GoodsReceiptNote,
    GRNItem,
    Invoice,
    InvoiceItem,
    MatchingResult,
    ExceptionRecord,
    RiskAlert,
    ApprovalRequest,
    ApprovalHistory,
    AuditLog,
)

def init_db():
    Base.metadata.create_all(bind=engine)

def seed_database():
    db: Session = SessionLocal()
    try:
        # Check if already seeded with at least 15 vendors
        if db.query(Vendor).count() >= 15:
            print("Database already contains >= 15 vendors. Skipping full reseed.")
            return

        print("Clearing previous seed data for fresh expanded generation...")
        # Drop all and recreate clean schema
        Base.metadata.drop_all(bind=engine)
        Base.metadata.create_all(bind=engine)

        print("1. Seeding Master Roles and Users...")
        roles = [
            Role(id="ADMIN", name="Administrator", description="System administrator with full configuration rights"),
            Role(id="FINANCE_CONTROLLER", name="Finance Controller", description="Final financial authority for payables >= 10 Lakhs"),
            Role(id="AP_MANAGER", name="Accounts Payable Manager", description="Authorizes payables between 1 Lakh and 10 Lakhs"),
            Role(id="FINANCE_EXECUTIVE", name="Finance Executive", description="Ingestion and reviews for payables <= 1 Lakh"),
        ]
        db.add_all(roles)
        db.commit()

        users = [
            User(
                id="u-controller",
                role_id="FINANCE_CONTROLLER",
                email="controller@apex.com",
                full_name="Veeren Kumar Konchada",
                department="Corporate Finance & Accounts",
                approval_limit_inr=Decimal("5000000.00"),
                is_active=True,
            ),
            User(
                id="u-manager",
                role_id="AP_MANAGER",
                email="ap.manager@apex.com",
                full_name="Rohan Sharma",
                department="Accounts Payable Operations",
                approval_limit_inr=Decimal("1000000.00"),
                is_active=True,
            ),
            User(
                id="u-exec",
                role_id="FINANCE_EXECUTIVE",
                email="ap.exec@apex.com",
                full_name="Pooja Verma",
                department="Accounts Payable Operations",
                approval_limit_inr=Decimal("100000.00"),
                is_active=True,
            ),
        ]
        db.add_all(users)
        db.commit()

        print("2. Seeding 15 Realistic Master Vendors...")
        vendors_data = [
            ("VEND-001", "Tata Steel Products Ltd.", "27AAACT2727Q1ZW", "AAACT2727Q", "Plot 42, MIDC, Taloja, Navi Mumbai", "27", "sales@tatasteel.demo", "+91-22-67890123", 30, "4921", "SBIN0001234", "LOW", Decimal("14250000.00")),
            ("VEND-002", "Larsen & Toubro Heavy Engg", "27AAACL0140P1ZH", "AAACL0140P", "L&T House, Ballard Estate, Mumbai", "27", "accounts@lt.demo", "+91-22-66965656", 45, "1123", "HDFC0000060", "LOW", Decimal("28500000.00")),
            ("VEND-003", "Hindalco Industries Ltd.", "27AAACH0327P1Z5", "AAACH0327P", "Century Bhavan, Worli, Mumbai", "27", "sales@hindalco.demo", "+91-22-66626666", 30, "8894", "ICIC0000004", "LOW", Decimal("11200000.00")),
            ("VEND-004", "Bharat Petro Lubricants", "27AAACB1234F1Z1", "AAACB1234F", "Chemical Complex, Trombay, Mumbai", "27", "orders@bharatpetro.demo", "+91-22-25567890", 15, "8812", "HDFC0000240", "MEDIUM", Decimal("5400000.00")),
            ("VEND-005", "JSW Steel Coated Products", "27AAACJ4321K1Z2", "AAACJ4321K", "JSW Centre, BKC, Bandra East, Mumbai", "27", "ap@jsw.demo", "+91-22-42861000", 30, "3312", "PUNB0001234", "LOW", Decimal("16800000.00")),
            ("VEND-006", "Godrej Material Handling", "27AAACG0567L1Z9", "AAACG0567L", "Pirojshanagar, Vikhroli, Mumbai", "27", "billing@godrej.demo", "+91-22-67965656", 30, "9921", "CITI0000002", "LOW", Decimal("7200000.00")),
            ("VEND-007", "Schneider Electric India", "29AAACS6328P1Z3", "AAACS6328P", "Whitefield Tech Park, Bangalore", "29", "invoices@schneider.demo", "+91-80-41234567", 45, "1094", "ICIC0000002", "LOW", Decimal("9800000.00")),
            ("VEND-008", "Siemens India Energy Ltd.", "27AAACS1234Q1Z6", "AAACS1234Q", "Kalwa Works, Thane Belapur Road", "27", "contact@siemens.demo", "+91-22-39663000", 60, "4412", "SBIN0000300", "LOW", Decimal("18500000.00")),
            ("VEND-009", "Bosch Rexroth Hydraulics", "29AAACB4321M1Z8", "AAACB4321M", "Hosur Road, Adugodi, Bangalore", "29", "hydraulics@bosch.demo", "+91-80-67521111", 30, "7712", "HDFC0000019", "LOW", Decimal("8900000.00")),
            ("VEND-010", "Thermax Boilers & Heating", "27AAACT0987N1Z4", "AAACT0987N", "Thermax House, Pune", "27", "inquiry@thermax.demo", "+91-20-66051200", 30, "2214", "AXIS0000010", "LOW", Decimal("6400000.00")),
            ("VEND-011", "Kirloskar Brothers Pumps", "27AAACK1122R1Z7", "AAACK1122R", "Udyog Bhavan, Tilak Road, Pune", "27", "pumps@kirloskar.demo", "+91-20-24440770", 30, "5541", "BARB0POONA", "LOW", Decimal("4800000.00")),
            ("VEND-012", "Fastrack Logistics Solutions", "27AAACF9021H1ZQ", "AAACF9021H", "Cargo Terminal, JNPT Port, Nhava Sheva", "27", "freight@fastrack.demo", "+91-22-27241234", 15, "9021", "YESB0000001", "MEDIUM", Decimal("3200000.00")),
            ("VEND-013", "Sunrise Industrial Supplies", "27AAACS8899D1ZT", "AAACS8899D", "GIDC Phase 2, Vapi", "27", "supplies@sunrise.demo", "+91-260-2431234", 15, "6671", "KKBK0000012", "HIGH", Decimal("1950000.00")),
            ("VEND-014", "Apex Packaging Containers", "27AAACA7766K1Z3", "AAACA7766K", "MIDC Chakan, Pune", "27", "boxes@apexpkg.demo", "+91-2135-671234", 30, "3388", "IDIB000M001", "LOW", Decimal("2800000.00")),
            ("VEND-015", "Precision Tools & Dies Ltd", "27AAACP5544J1Z8", "AAACP5544J", "Bhosari Industrial Area, Pune", "27", "tooling@precision.demo", "+91-20-27123456", 30, "1190", "UBIN0530018", "LOW", Decimal("4100000.00")),
        ]

        vendors_list = []
        for v in vendors_data:
            vendor = Vendor(
                id=v[0], name=v[1], gstin=v[2], pan=v[3], address=v[4],
                state_code=v[5], contact_email=v[6], contact_phone=v[7],
                payment_terms_days=v[8], bank_account_last4=v[9], bank_ifsc=v[10],
                risk_category=v[11], total_spend_ytd_inr=v[12]
            )
            vendors_list.append(vendor)
            db.add(vendor)
        db.commit()

        print("3. Seeding 30 Purchase Orders, 30 GRNs, and 30 Invoices...")
        base_date = date(2026, 10, 1)

        # Standard catalog items
        catalog = [
            ("STL-BEAM-01", "Heavy Structural Steel Beams IS2062", "7216", Decimal("4180.00")),
            ("LUB-HYD-68", "Hydraulic Fluid ISO VG 68 210L Drum", "2710", Decimal("7800.00")),
            ("SWG-MCCB-400A", "Molded Case Circuit Breaker 400A 3P", "8536", Decimal("120000.00")),
            ("PMP-IND-50HP", "Centrifugal Water Pump 50HP High Flow", "8413", Decimal("185000.00")),
            ("VALV-BALL-3IN", "Stainless Steel Ball Valve Class 150 3 Inch", "8481", Decimal("8500.00")),
            ("FRT-FULL-TRUCK", "Full Truckload Freight Mumbai to Pune", "9965", Decimal("20000.00")),
            ("PKG-CORR-BOX", "Heavy Duty Corrugated Carton Pallet Lot", "4819", Decimal("45000.00")),
            ("TOOL-CARBIDE", "Solid Carbide End Mill Cutting Set 10pc", "8207", Decimal("18000.00")),
        ]

        for i in range(1, 31):
            if i == 4:
                vendor = next(v for v in vendors_list if v.id == "VEND-007")
            else:
                vendor = vendors_list[(i - 1) % len(vendors_list)]
            item_info = catalog[(i - 1) % len(catalog)]
            
            po_id = f"PO-2026-{100 + i:05d}"
            grn_id = f"GRN-2026-{80 + i:05d}"
            inv_id = f"INV-2026-{450 + i:05d}"

            po_date = base_date + timedelta(days=(i * 2))
            due_date = po_date + timedelta(days=vendor.payment_terms_days)
            delivery_date = po_date + timedelta(days=5)

            qty = Decimal(str(random.choice([5, 10, 20, 50, 100])))
            unit_price = item_info[3]
            taxable = (qty * unit_price).quantize(Decimal("0.01"))
            
            # Inter-state vs Intra-state tax logic
            is_interstate = (vendor.state_code != "27")
            if is_interstate:
                cgst = Decimal("0.00")
                sgst = Decimal("0.00")
                igst = (taxable * Decimal("0.18")).quantize(Decimal("0.01"))
            else:
                cgst = (taxable * Decimal("0.09")).quantize(Decimal("0.01"))
                sgst = (taxable * Decimal("0.09")).quantize(Decimal("0.01"))
                igst = Decimal("0.00")
            total_tax = cgst + sgst + igst
            total_amount = taxable + total_tax

            # 1. Purchase Order
            po = PurchaseOrder(
                id=po_id,
                vendor_id=vendor.id,
                po_date=po_date,
                delivery_due_date=delivery_date + timedelta(days=7),
                currency="INR",
                subtotal_inr=taxable,
                tax_amount_inr=total_tax,
                total_amount_inr=total_amount,
                status="FULFILLED" if i <= 20 else "PARTIALLY_FULFILLED",
                payment_terms=f"Net {vendor.payment_terms_days}",
            )
            db.add(po)
            db.commit()

            po_item = POItem(
                po_id=po_id,
                line_number=1,
                item_code=item_info[0],
                description=item_info[1],
                hsn_sac_code=item_info[2],
                quantity=qty,
                unit_price_inr=unit_price,
                gst_rate_percent=Decimal("18.00"),
                taxable_amount_inr=taxable,
                total_line_amount_inr=total_amount,
            )
            db.add(po_item)

            # 2. Goods Receipt Note (GRN)
            # Scenario logic: introduce quantity variance on select indexes
            received_qty = qty
            accepted_qty = qty
            rejected_qty = Decimal("0.00")
            grn_status = "ACCEPTED"

            if i in (5, 12, 19):  # Quantity under-receipt scenarios
                accepted_qty = qty - Decimal("2.0")
                rejected_qty = Decimal("2.0")
                grn_status = "PARTIALLY_ACCEPTED"

            grn = GoodsReceiptNote(
                id=grn_id,
                po_id=po_id,
                vendor_id=vendor.id,
                receipt_date=delivery_date,
                delivery_challan_no=f"DC-{vendor.id[-3:]}-{8800 + i}",
                received_by_user="warehouse.mgr@apex.com",
                warehouse_location="Pune Central Hub" if i % 2 == 0 else "Mumbai Central Hub",
                status=grn_status,
            )
            db.add(grn)
            db.commit()

            grn_item = GRNItem(
                grn_id=grn_id,
                item_code=item_info[0],
                quantity_received=received_qty,
                quantity_accepted=accepted_qty,
                quantity_rejected=rejected_qty,
                rejection_reason="Damaged in transit" if rejected_qty > 0 else None,
            )
            db.add(grn_item)

            # 3. Invoice & Matching Verdict
            inv_qty = qty
            inv_unit_price = unit_price
            match_status = "EXACT_MATCH"
            inv_status = "APPROVED"
            payment_status = "UNPAID"

            # Inject varied MBA scenarios across 30 invoices
            if i in (3, 11, 23):  # Price Mismatch (+8.9% price escalation)
                inv_unit_price = (unit_price * Decimal("1.089")).quantize(Decimal("0.01"))
                match_status = "PRICE_MISMATCH"
                inv_status = "EXCEPTION_HOLD"
                payment_status = "ON_HOLD"
            elif i in (5, 12, 19):  # Quantity Mismatch (Billed > Accepted)
                match_status = "QUANTITY_MISMATCH"
                inv_status = "EXCEPTION_HOLD"
                payment_status = "ON_HOLD"
            elif i in (2, 8, 16):  # Match within Tolerance (+1.2% price variance within 2%)
                inv_unit_price = (unit_price * Decimal("1.012")).quantize(Decimal("0.01"))
                match_status = "MATCH_WITHIN_TOLERANCE"
                inv_status = "PENDING_APPROVAL"
                payment_status = "UNPAID"
            elif i == 7:  # Duplicate invoice scenario
                match_status = "DUPLICATE_INVOICE"
                inv_status = "EXCEPTION_HOLD"
                payment_status = "ON_HOLD"
            elif i <= 15:
                match_status = "EXACT_MATCH"
                inv_status = "APPROVED"
                payment_status = "PAID" if i <= 8 else "PENDING_DISBURSEMENT"
            else:
                match_status = "EXACT_MATCH"
                inv_status = "PENDING_APPROVAL"
                payment_status = "UNPAID"

            inv_taxable = (inv_qty * inv_unit_price).quantize(Decimal("0.01"))
            if is_interstate:
                inv_cgst = Decimal("0.00")
                inv_sgst = Decimal("0.00")
                inv_igst = (inv_taxable * Decimal("0.18")).quantize(Decimal("0.01"))
            else:
                inv_cgst = (inv_taxable * Decimal("0.09")).quantize(Decimal("0.01"))
                inv_sgst = (inv_taxable * Decimal("0.09")).quantize(Decimal("0.01"))
                inv_igst = Decimal("0.00")
            inv_total_tax = inv_cgst + inv_sgst + inv_igst
            inv_total_amount = inv_taxable + inv_total_tax

            invoice = Invoice(
                id=inv_id,
                vendor_id=vendor.id,
                po_reference=po_id,
                invoice_date=delivery_date + timedelta(days=1),
                due_date=due_date,
                vendor_gstin=vendor.gstin,
                recipient_gstin="27AABCA9876K1Z5",
                place_of_supply="27",
                taxable_value_inr=inv_taxable,
                cgst_amount_inr=inv_cgst,
                sgst_amount_inr=inv_sgst,
                igst_amount_inr=inv_igst,
                total_tax_inr=inv_total_tax,
                total_amount_inr=inv_total_amount,
                status=inv_status,
                match_status=match_status,
                extraction_confidence=Decimal(str(round(random.uniform(0.94, 0.99), 4))),
                payment_status=payment_status,
            )
            db.add(invoice)
            db.commit()

            inv_item_record = InvoiceItem(
                invoice_id=inv_id,
                line_number=1,
                item_code=item_info[0],
                description=item_info[1],
                hsn_sac_code=item_info[2],
                quantity=inv_qty,
                unit_price_inr=inv_unit_price,
                gst_rate_percent=Decimal("18.00"),
                taxable_amount_inr=inv_taxable,
                total_line_amount_inr=inv_total_amount,
            )
            db.add(inv_item_record)

            # 4. Matching Result Record
            is_matched_bool = match_status in ("EXACT_MATCH", "MATCH_WITHIN_TOLERANCE")
            price_var_pct = Decimal("0.00")
            if unit_price > 0:
                price_var_pct = (((inv_unit_price - unit_price) / unit_price) * Decimal("100")).quantize(Decimal("0.01"))
            
            qty_var_pct = Decimal("0.00")
            if accepted_qty > 0:
                qty_var_pct = (((inv_qty - accepted_qty) / accepted_qty) * Decimal("100")).quantize(Decimal("0.01"))

            financial_impact = Decimal("0.00")
            if not is_matched_bool:
                financial_impact = abs(inv_total_amount - total_amount)

            match_result = MatchingResult(
                invoice_id=inv_id,
                po_id=po_id,
                grn_id=grn_id,
                match_status=match_status,
                price_variance_percent=price_var_pct,
                quantity_variance_percent=qty_var_pct,
                tax_variance_inr=abs(inv_total_tax - total_tax),
                total_financial_impact_inr=financial_impact,
                is_matched=is_matched_bool,
                evaluation_notes=f"Reconciliation evaluated for {inv_id}. Verdict: {match_status}.",
            )
            db.add(match_result)

            # 5. Exceptions & Approval Requests
            if not is_matched_bool:
                exc_category = "PRICE_DIFF" if "PRICE" in match_status else ("QUANTITY_DIFF" if "QUANTITY" in match_status else "DUPLICATE_INVOICE")
                exc_record = ExceptionRecord(
                    id=f"EXC-2026-{10 + i:04d}",
                    invoice_id=inv_id,
                    category=exc_category,
                    severity="HIGH" if financial_impact > Decimal("50000.00") else "MEDIUM",
                    expected_value=f"PO Rate ₹{unit_price} / Qty {accepted_qty}",
                    actual_value=f"Invoiced Rate ₹{inv_unit_price} / Qty {inv_qty}",
                    difference_value=f"Impact: ₹{financial_impact}",
                    financial_impact_inr=financial_impact,
                    responsible_department="Procurement / Purchase",
                    status="OPEN",
                    assigned_to_user_id="u-manager",
                    resolution_notes="Pending vendor review or debit note issuance.",
                )
                db.add(exc_record)

            if inv_status == "PENDING_APPROVAL":
                req_role = "FINANCE_EXECUTIVE" if inv_total_amount <= Decimal("100000.00") else ("AP_MANAGER" if inv_total_amount <= Decimal("1000000.00") else "FINANCE_CONTROLLER")
                approval_req = ApprovalRequest(
                    id=f"APR-2026-{90 + i:04d}",
                    invoice_id=inv_id,
                    required_role=req_role,
                    amount_inr=inv_total_amount,
                    status="PENDING",
                    assigned_user_id="u-manager" if req_role == "AP_MANAGER" else "u-controller",
                )
                db.add(approval_req)

            # Risk Alert for anomalies
            if match_status == "DUPLICATE_INVOICE" or price_var_pct > Decimal("5.0"):
                risk = RiskAlert(
                    invoice_id=inv_id,
                    vendor_id=vendor.id,
                    risk_score=92 if match_status == "DUPLICATE_INVOICE" else 65,
                    risk_category="ELEVATED" if match_status == "DUPLICATE_INVOICE" else "MODERATE",
                    rule_triggered="POSSIBLE_DUPLICATE_INVOICE" if match_status == "DUPLICATE_INVOICE" else "UNUSUAL_PRICE_VARIATION",
                    explanation=f"Transaction flagged for {match_status} against PO {po_id}.",
                    suggested_action="Perform manual supervisor verification before approval release.",
                    is_acknowledged=False,
                )
                db.add(risk)

            # Audit Log entry
            audit = AuditLog(
                entity_type="INVOICE_INGESTION",
                entity_id=inv_id,
                action="RECONCILIATION_COMPLETED",
                actor_type="AGENT",
                actor_id="SUPERVISOR_ORCHESTRATOR",
                old_state={"status": "INGESTED"},
                new_state={"status": inv_status, "match_status": match_status},
                ip_address="127.0.0.1",
            )
            db.add(audit)

        db.commit()
        print(f"✅ Successfully seeded {len(vendors_list)} Vendors, 30 Purchase Orders, 30 GRNs, and 30 Invoices into database!")
    finally:
        db.close()

if __name__ == "__main__":
    init_db()
    seed_database()
