from typing import TypedDict, List, Dict, Optional, Any

class AgentWorkflowState(TypedDict):
    # Workflow Metadata
    workflow_run_id: str
    document_id: Optional[str]
    pdf_path: Optional[str]

    # Ingestion & Master Data
    invoice_data: Optional[Dict[str, Any]]
    po_data: Optional[Dict[str, Any]]
    grn_data: Optional[Dict[str, Any]]

    # 3-Way Reconciliation
    matching_result: Optional[Dict[str, Any]]
    is_matched: bool
    discrepancies: List[str]

    # Risk & Anomaly Assessment
    risk_score: int
    risk_category: str
    risk_flags: List[str]

    # Exception Remediation
    exception_ticket: Optional[Dict[str, Any]]

    # Approval Hierarchy & Routing
    assigned_approval_role: Optional[str]
    requires_human_approval: bool
    workflow_status: str  # COMPLETED_APPROVED, COMPLETED_EXCEPTION_HOLD, FAILED

    # Execution Audit Trail
    current_agent: str
    agent_trail: List[Dict[str, Any]]
    total_tokens_used: int
    error_message: Optional[str]

