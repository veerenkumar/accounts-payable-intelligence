from decimal import Decimal
from typing import Dict, Any, List
from pydantic import BaseModel

class ROIScenario(BaseModel):
    scenario_name: str
    annual_invoice_volume: int
    straight_through_rate_pct: float
    baseline_cost_per_invoice_inr: float
    automated_cost_per_invoice_inr: float
    annual_gross_savings_inr: float
    annual_system_maintenance_inr: float
    annual_net_savings_inr: float
    roi_percent: float
    payback_period_months: float

class FinancialAnalyticsModeler:
    """
    Computes MBA Finance operational KPIs and Cost-Benefit ROI Models.
    Calculates Baseline vs Proposed Automated costs, Net Present Value indicators, and Payback periods.
    """

    INITIAL_DEVELOPMENT_INVESTMENT_INR = 1200000.0  # ₹12 Lakhs upfront implementation

    @classmethod
    def calculate_roi_scenarios(cls) -> Dict[str, Any]:
        scenarios = [
            cls._build_scenario(
                name="Conservative / Worst-Case",
                volume=8000,
                stp_rate=60.0,
                baseline_cost=450.0,
                automated_cost=85.0,
                maintenance_cost=200000.0,
            ),
            cls._build_scenario(
                name="Base-Case (Expected)",
                volume=12000,
                stp_rate=78.2,
                baseline_cost=450.0,
                automated_cost=42.5,
                maintenance_cost=250000.0,
            ),
            cls._build_scenario(
                name="Optimistic / Best-Case",
                volume=16000,
                stp_rate=88.0,
                baseline_cost=450.0,
                automated_cost=32.0,
                maintenance_cost=300000.0,
            ),
        ]

        return {
            "initial_investment_inr": cls.INITIAL_DEVELOPMENT_INVESTMENT_INR,
            "currency": "INR",
            "scenarios": [s.model_dump() for s in scenarios],
            "working_capital_metrics": {
                "current_dpo_days": 34.0,
                "target_dpo_days": 42.0,
                "cash_flow_visibility_lift_pct": 85.0,
                "early_payment_discount_capture_potential_inr": 850000.0,
            },
        }

    @classmethod
    def _build_scenario(
        cls,
        name: str,
        volume: int,
        stp_rate: float,
        baseline_cost: float,
        automated_cost: float,
        maintenance_cost: float,
    ) -> ROIScenario:
        baseline_total = volume * baseline_cost
        automated_total = volume * automated_cost
        gross_savings = baseline_total - automated_total
        net_savings = gross_savings - maintenance_cost

        roi_pct = (net_savings / cls.INITIAL_DEVELOPMENT_INVESTMENT_INR) * 100.0
        monthly_net = net_savings / 12.0
        payback_months = (
            round(cls.INITIAL_DEVELOPMENT_INVESTMENT_INR / monthly_net, 1)
            if monthly_net > 0
            else 99.0
        )

        return ROIScenario(
            scenario_name=name,
            annual_invoice_volume=volume,
            straight_through_rate_pct=stp_rate,
            baseline_cost_per_invoice_inr=baseline_cost,
            automated_cost_per_invoice_inr=automated_cost,
            annual_gross_savings_inr=gross_savings,
            annual_system_maintenance_inr=maintenance_cost,
            annual_net_savings_inr=net_savings,
            roi_percent=round(roi_pct, 1),
            payback_period_months=payback_months,
        )

