from typing import List, Optional, Any, Dict
from datetime import date, datetime
from pydantic import BaseModel, Field

# --- Base Health & Auth ---
class HealthResponse(BaseModel):
    status: str
    version: str
    environment: str
    database: str
    active_llm_provider: str
    timestamp: datetime

class TokenResponse(BaseModel):
    access_token: str
    token_type: str
    user_id: str
    email: str
    role: str
    approval_limit_inr: float

class LoginRequest(BaseModel):
    email: str
    password: str

# --- Vendors ---
class VendorBase(BaseModel):
    id: str
    name: str
    gstin: str
    pan: str
    address: str
    state_code: str
    contact_email: str
    contact_phone: str
    payment_terms_days: int = 30
    bank_account_last4: str
    bank_ifsc: str
    risk_category: str = "LOW"
    total_spend_ytd_inr: float = 0.0

class VendorResponse(VendorBase):
    class Config:
        from_attributes = True

# --- Purchase Orders ---
class POItemResponse(BaseModel):
    line_number: int
    item_code: str
    description: str
    hsn_sac_code: str
    quantity: float
    unit_price_inr: float
    gst_rate_percent: float
    taxable_amount_inr: float
    total_line_amount_inr: float

    class Config:
        from_attributes = True

class POResponse(BaseModel):
    id: str
    vendor_id: str
    po_date: date
    delivery_due_date: date
    currency: str
    subtotal_inr: float
    tax_amount_inr: float
    total_amount_inr: float
    status: str
    payment_terms: str
    items: List[POItemResponse] = []

    class Config:
        from_attributes = True

# --- GRNs ---
class GRNItemResponse(BaseModel):
    item_code: str
    quantity_received: float
    quantity_accepted: float
    quantity_rejected: float = 0.0
    rejection_reason: Optional[str] = None

    class Config:
        from_attributes = True

class GRNResponse(BaseModel):
    id: str
    po_id: str
    vendor_id: str
    receipt_date: date
    delivery_challan_no: Optional[str] = None
    received_by_user: str
    status: str
    items: List[GRNItemResponse] = []

    class Config:
        from_attributes = True

# --- Invoices ---
class InvoiceItemResponse(BaseModel):
    line_number: int
    item_code: str
    description: str
    hsn_sac_code: str
    quantity: float
    unit_price_inr: float
    gst_rate_percent: float
    taxable_amount_inr: float
    total_line_amount_inr: float

    class Config:
        from_attributes = True

class OCRDiscrepancyItem(BaseModel):
    field: str
    label: str
    ledger_value: Any
    ocr_value: Any
    has_conflict: bool
    description: str

class InvoiceResponse(BaseModel):
    id: str
    vendor_id: str
    vendor_name: Optional[str] = None
    po_reference: Optional[str] = None
    document_id: Optional[str] = None
    invoice_date: date
    due_date: date
    vendor_gstin: str
    recipient_gstin: str
    place_of_supply: str
    taxable_value_inr: float
    cgst_amount_inr: float
    sgst_amount_inr: float
    igst_amount_inr: float
    total_tax_inr: float
    total_amount_inr: float
    currency: str
    status: str
    match_status: str
    extraction_confidence: float
    payment_status: str
    items: List[InvoiceItemResponse] = []
    ocr_data: Optional[Dict[str, Any]] = None
    ocr_discrepancies: Optional[List[OCRDiscrepancyItem]] = None

    class Config:
        from_attributes = True

class InvoiceReconcileOCRRequest(BaseModel):
    confirmed_by: str = "USR-002"
    user_role: str = "AP_MANAGER"
    accept_ocr_vendor: bool = False
    accept_ocr_po: bool = False
    accept_ocr_dates: bool = False
    comments: Optional[str] = "Human verified OCR reconciliation"

class InvoiceReconcileOCRResponse(BaseModel):
    invoice_id: str
    status: str
    updated_fields: List[str]
    vendor_id: str
    vendor_name: str
    vendor_gstin: str
    po_reference: Optional[str] = None
    audit_log_id: str
    message: str

# --- 3-Way Matching Result ---
class LineMatchEvaluation(BaseModel):
    item_code: str
    description: Optional[str] = None
    invoice_qty: float
    grn_accepted_qty: float
    invoice_unit_price: float
    po_unit_price: float
    price_variance_pct: float
    quantity_variance_pct: float
    financial_impact_inr: float = 0.0
    status: str
    reason: Optional[str] = None

class MatchingResponse(BaseModel):
    invoice_id: str
    vendor_id: Optional[str] = None
    vendor_name: Optional[str] = None
    po_id: Optional[str] = None
    grn_id: Optional[str] = None
    match_status: str
    price_variance_percent: float
    quantity_variance_percent: float
    tax_variance_inr: float
    total_financial_impact_inr: float
    is_matched: bool
    evaluation_notes: Optional[str] = None
    discrepancies: List[str] = []
    line_evaluations: List[LineMatchEvaluation] = []
    tolerances_applied: Optional[Dict[str, float]] = None
    evaluated_at: Optional[str] = None

class MatchingEvaluateRequest(BaseModel):
    price_tolerance_pct: Optional[float] = 2.0
    qty_tolerance_pct: Optional[float] = 0.0
    tax_tolerance_inr: Optional[float] = 5.0
    classify_partial_receipt: Optional[bool] = True

class TriangulationDetailResponse(BaseModel):
    invoice: InvoiceResponse
    vendor: Optional[VendorResponse] = None
    purchase_order: Optional[POResponse] = None
    goods_receipt_notes: List[GRNResponse] = []
    matching_result: Optional[MatchingResponse] = None

# --- Exceptions ---
class ExceptionResponse(BaseModel):
    id: str
    invoice_id: str
    vendor_name: Optional[str] = None
    category: str
    severity: str
    expected_value: str
    actual_value: str
    difference_value: str
    financial_impact_inr: float
    responsible_department: str
    status: str
    created_at: datetime
    resolution_notes: Optional[str] = None

    class Config:
        from_attributes = True

# --- Approvals ---
class ApprovalResponse(BaseModel):
    id: str
    invoice_id: str
    vendor_name: Optional[str] = None
    required_role: str
    amount_inr: float
    status: str
    match_status: Optional[str] = None
    invoice_status: Optional[str] = None
    blocking_exceptions_count: Optional[int] = 0
    created_at: datetime

    class Config:
        from_attributes = True

class ApprovalActionRequest(BaseModel):
    action: str  # APPROVED, REJECTED, HELD
    comments: str
    user_role: Optional[str] = None
    approved_by: Optional[str] = None

# --- KPI Dashboard ---
class KPIDashboardResponse(BaseModel):
    total_invoices_processed: int
    total_invoice_value_inr: float
    total_outstanding_payables_inr: float
    matched_invoices_count: int
    matching_rate_percent: float
    pending_approvals_count: int
    exception_count: int
    duplicate_alerts_count: int
    overdue_payables_inr: float
    avg_processing_time_hours: float
    estimated_annual_savings_inr: float
    straight_through_processing_percent: float

# Append to schemas
from pydantic import BaseModel
from typing import List, Optional, Dict, Any

class CopilotQueryRequest(BaseModel):
    query: str
    conversation_id: Optional[str] = None

class CopilotQueryResponse(BaseModel):
    query: str
    response: str
    tools_executed: List[str]
    supporting_records: List[str]
    data_currency: str

class ExceptionResolveRequest(BaseModel):
    action: str  # ACCEPT_VARIANCE, ISSUE_DEBIT_NOTE, PO_AMENDMENT, REJECT
    resolution_notes: str
    adjust_liability_inr: Optional[float] = 0.0

class ExceptionResolveResponse(BaseModel):
    exception_id: str
    invoice_id: str
    status: str
    action_taken: str
    resolution_notes: str
    debit_note_reference: Optional[str] = None

class DocumentResponse(BaseModel):
    id: str
    file_name: str
    file_size_bytes: int
    mime_type: str
    document_type: str
    ocr_confidence_score: Optional[float] = None
    ocr_raw_text: Optional[str] = None
    parsed_invoice: Optional[Dict[str, Any]] = None
    uploaded_at: datetime

    class Config:
        from_attributes = True

class DocumentUploadResponse(BaseModel):
    document_id: str
    file_name: str
    parsed_invoice: Optional[Dict[str, Any]] = None
    extraction_confidence: float
    ocr_preview: str
    invoice_id: Optional[str] = None
    workflow_status: str
    is_valid: bool = True
    validation_errors: List[str] = []
    validation_warnings: List[str] = []
    requires_human_review: bool = False

class InvoiceItemInput(BaseModel):
    line_number: int
    item_code: str
    description: str
    hsn_sac_code: str
    quantity: float
    unit_price_inr: float
    gst_rate_percent: float = 18.0
    taxable_amount_inr: float
    total_line_amount_inr: float

class InvoiceUpdateRequest(BaseModel):
    vendor_name: Optional[str] = None
    vendor_gstin: Optional[str] = None
    po_reference: Optional[str] = None
    invoice_date: Optional[date] = None
    due_date: Optional[date] = None
    taxable_value_inr: Optional[float] = None
    cgst_amount_inr: Optional[float] = None
    sgst_amount_inr: Optional[float] = None
    igst_amount_inr: Optional[float] = None
    total_amount_inr: Optional[float] = None
    items: Optional[List[InvoiceItemInput]] = None

class InvoiceValidationResponse(BaseModel):
    invoice_id: str
    is_valid: bool
    requires_human_review: bool
    errors: List[str]
    warnings: List[str]
    discrepancy_amount_inr: float
    field_validations: Dict[str, bool]
    validated_totals: Dict[str, float]
