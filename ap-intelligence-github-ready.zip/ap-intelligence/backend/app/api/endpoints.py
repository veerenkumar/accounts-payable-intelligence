import os
import shutil
import uuid
from datetime import datetime, date
from decimal import Decimal
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, File
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.database.session import get_db
from app.models.financial_entities import (
    Role,
    User,
    Vendor,
    PurchaseOrder,
    GoodsReceiptNote,
    Invoice,
    InvoiceItem,
    MatchingResult,
    ExceptionRecord,
    RiskAlert,
    ApprovalRequest,
    AuditLog,
    Document,
)
from app.schemas.financial_schemas import (
    HealthResponse,
    VendorResponse,
    POResponse,
    GRNResponse,
    InvoiceResponse,
    OCRDiscrepancyItem,
    InvoiceReconcileOCRRequest,
    InvoiceReconcileOCRResponse,
    ExceptionResponse,
    ApprovalResponse,
    KPIDashboardResponse,
    ApprovalActionRequest,
    DocumentResponse,
    DocumentUploadResponse,
    InvoiceItemInput,
    InvoiceUpdateRequest,
    InvoiceValidationResponse,
    MatchingResponse,
    MatchingEvaluateRequest,
    TriangulationDetailResponse,
)
from app.matching.service import MatchingService
from app.document_processing.validator import InvoiceValidator
from app.core.config import settings

api_router = APIRouter()

# --- Health Check ---
@api_router.get("/health", response_model=HealthResponse)
def health_check():
    return HealthResponse(
        status="healthy",
        version=settings.APP_VERSION,
        environment=settings.APP_ENV,
        database="connected",
        active_llm_provider=settings.LLM_PROVIDER,
        timestamp=datetime.utcnow(),
    )

# --- Executive KPI Dashboard ---
@api_router.get("/analytics/dashboard", response_model=KPIDashboardResponse)
def get_dashboard_kpis(db: Session = Depends(get_db)):
    invoices = db.query(Invoice).all()
    total_count = len(invoices)
    total_val = sum(float(inv.total_amount_inr) for inv in invoices)
    
    # Outstanding = Unpaid or Pending Disbursement
    outstanding_val = sum(
        float(inv.total_amount_inr)
        for inv in invoices
        if inv.payment_status in ("UNPAID", "ON_HOLD", "PENDING_DISBURSEMENT")
    )

    matched_count = db.query(Invoice).filter(
        Invoice.match_status.in_(["EXACT_MATCH", "MATCH_WITHIN_TOLERANCE"])
    ).count()

    matching_rate = (matched_count / total_count * 100.0) if total_count > 0 else 0.0

    pending_approvals = db.query(ApprovalRequest).filter(
        ApprovalRequest.status == "PENDING"
    ).count()

    exception_count = db.query(ExceptionRecord).filter(
        ExceptionRecord.status.in_(["OPEN", "INVESTIGATING"])
    ).count()

    duplicate_alerts = db.query(RiskAlert).filter(
        RiskAlert.rule_triggered.like("%DUPLICATE%")
    ).count()

    # Overdue payables
    today = date.today()
    overdue_val = sum(
        float(inv.total_amount_inr)
        for inv in invoices
        if inv.due_date < today and inv.payment_status != "PAID"
    )

    return KPIDashboardResponse(
        total_invoices_processed=total_count,
        total_invoice_value_inr=total_val,
        total_outstanding_payables_inr=outstanding_val,
        matched_invoices_count=matched_count,
        matching_rate_percent=round(matching_rate, 1),
        pending_approvals_count=pending_approvals,
        exception_count=exception_count,
        duplicate_alerts_count=duplicate_alerts,
        overdue_payables_inr=overdue_val,
        avg_processing_time_hours=1.8,
        estimated_annual_savings_inr=3450000.0,
        straight_through_processing_percent=78.2,
    )

# --- Vendors ---
@api_router.get("/vendors", response_model=List[VendorResponse])
def list_vendors(db: Session = Depends(get_db)):
    vendors = db.query(Vendor).all()
    return vendors

# --- Purchase Orders ---
@api_router.get("/purchase-orders", response_model=List[POResponse])
def list_purchase_orders(db: Session = Depends(get_db)):
    return db.query(PurchaseOrder).all()

# --- Goods Receipt Notes ---
@api_router.get("/grn", response_model=List[GRNResponse])
def list_goods_receipt_notes(db: Session = Depends(get_db)):
    return db.query(GoodsReceiptNote).all()

def build_invoice_response(inv: Invoice, db: Session) -> InvoiceResponse:
    from app.document_processing.parser import DocumentParser

    vendor_name = inv.vendor.name if inv.vendor else inv.vendor_id

    # 1. Locate matching Document record
    doc = None
    if inv.document_id:
        doc = db.query(Document).filter(Document.id == inv.document_id).first()
    if not doc:
        clean_inv = inv.id.replace("-", "_")
        doc = (
            db.query(Document)
            .filter(
                (Document.ocr_raw_text.ilike(f"%{inv.id}%"))
                | (Document.file_name.ilike(f"%{clean_inv}%"))
            )
            .order_by(Document.uploaded_at.desc())
            .first()
        )

    ocr_data = None
    discrepancies = []

    if doc and doc.ocr_raw_text:
        ocr_data = DocumentParser.parse_invoice(
            doc.ocr_raw_text, is_scanned_image=not doc.mime_type.endswith("pdf")
        )

        ocr_vendor_name = ocr_data.get("vendor_name")
        ocr_gstin = ocr_data.get("vendor_gstin")
        ledger_vendor_name = inv.vendor.name if inv.vendor else inv.vendor_id

        # Supplier Name Discrepancy
        if ocr_vendor_name and ocr_vendor_name.lower() not in ledger_vendor_name.lower():
            discrepancies.append(
                OCRDiscrepancyItem(
                    field="vendor_name",
                    label="Supplier Name",
                    ledger_value=ledger_vendor_name,
                    ocr_value=ocr_vendor_name,
                    has_conflict=True,
                    description=f"Supplier Identity Conflict: Ledger records supplier as '{ledger_vendor_name}' ({inv.vendor_id}), but physical document OCR extracts '{ocr_vendor_name}'.",
                )
            )
        else:
            discrepancies.append(
                OCRDiscrepancyItem(
                    field="vendor_name",
                    label="Supplier Name",
                    ledger_value=ledger_vendor_name,
                    ocr_value=ocr_vendor_name or ledger_vendor_name,
                    has_conflict=False,
                    description="Supplier identity verified and matches.",
                )
            )

        # Supplier GSTIN Discrepancy
        if ocr_gstin and ocr_gstin.upper() != inv.vendor_gstin.upper():
            discrepancies.append(
                OCRDiscrepancyItem(
                    field="vendor_gstin",
                    label="Supplier GSTIN",
                    ledger_value=inv.vendor_gstin,
                    ocr_value=ocr_gstin,
                    has_conflict=True,
                    description=f"GSTIN Mismatch: Ledger specifies '{inv.vendor_gstin}', but document OCR extracted '{ocr_gstin}'.",
                )
            )
        else:
            discrepancies.append(
                OCRDiscrepancyItem(
                    field="vendor_gstin",
                    label="Supplier GSTIN",
                    ledger_value=inv.vendor_gstin,
                    ocr_value=ocr_gstin or inv.vendor_gstin,
                    has_conflict=False,
                    description="GSTIN verified and matches.",
                )
            )

        # PO Reference Discrepancy
        ocr_po = ocr_data.get("po_reference")
        ledger_po = inv.po_reference or "N/A"
        po_in_db = (
            db.query(PurchaseOrder).filter(PurchaseOrder.id == inv.po_reference).first()
            if inv.po_reference
            else None
        )

        if ocr_po and ocr_po != inv.po_reference:
            po_desc = (
                f"PO Reference Conflict: Ledger has '{ledger_po}' (which does not exist in PO database), while document OCR extracts valid '{ocr_po}'."
                if not po_in_db
                else f"PO Reference Conflict: Ledger has '{ledger_po}', OCR has '{ocr_po}'."
            )
            discrepancies.append(
                OCRDiscrepancyItem(
                    field="po_reference",
                    label="Purchase Order Ref",
                    ledger_value=ledger_po,
                    ocr_value=ocr_po,
                    has_conflict=True,
                    description=po_desc,
                )
            )
        else:
            discrepancies.append(
                OCRDiscrepancyItem(
                    field="po_reference",
                    label="Purchase Order Ref",
                    ledger_value=ledger_po,
                    ocr_value=ocr_po or ledger_po,
                    has_conflict=False,
                    description="Purchase order reference matches.",
                )
            )

        # Total Amount Check
        ocr_total = float(ocr_data.get("total_amount") or 0.0)
        ledger_total = float(inv.total_amount_inr)
        if abs(ocr_total - ledger_total) > 1.0:
            discrepancies.append(
                OCRDiscrepancyItem(
                    field="total_amount_inr",
                    label="Total Invoice Amount",
                    ledger_value=ledger_total,
                    ocr_value=ocr_total,
                    has_conflict=True,
                    description=f"Financial Amount Variance: Ledger is ₹{ledger_total:,.2f}, OCR extracted ₹{ocr_total:,.2f}.",
                )
            )
        else:
            discrepancies.append(
                OCRDiscrepancyItem(
                    field="total_amount_inr",
                    label="Total Invoice Amount",
                    ledger_value=ledger_total,
                    ocr_value=ocr_total or ledger_total,
                    has_conflict=False,
                    description="Financial totals agree within zero tolerance.",
                )
            )

    return InvoiceResponse(
        id=inv.id,
        vendor_id=inv.vendor_id,
        vendor_name=vendor_name,
        po_reference=inv.po_reference,
        document_id=doc.id if doc else inv.document_id,
        invoice_date=inv.invoice_date,
        due_date=inv.due_date,
        vendor_gstin=inv.vendor_gstin,
        recipient_gstin=inv.recipient_gstin,
        place_of_supply=inv.place_of_supply,
        taxable_value_inr=float(inv.taxable_value_inr),
        cgst_amount_inr=float(inv.cgst_amount_inr or 0.0),
        sgst_amount_inr=float(inv.sgst_amount_inr or 0.0),
        igst_amount_inr=float(inv.igst_amount_inr or 0.0),
        total_tax_inr=float(inv.total_tax_inr),
        total_amount_inr=float(inv.total_amount_inr),
        currency=inv.currency,
        status=inv.status,
        match_status=inv.match_status,
        extraction_confidence=float(inv.extraction_confidence or 0.95),
        payment_status=inv.payment_status,
        items=inv.items,
        ocr_data=ocr_data,
        ocr_discrepancies=discrepancies if discrepancies else None,
    )

# --- Invoices ---
@api_router.get("/invoices", response_model=List[InvoiceResponse])
def list_invoices(
    status: Optional[str] = None,
    match_status: Optional[str] = None,
    db: Session = Depends(get_db),
):
    query = db.query(Invoice)
    if status:
        query = query.filter(Invoice.status == status)
    if match_status:
        query = query.filter(Invoice.match_status == match_status)
    invoices = query.all()
    return [build_invoice_response(inv, db) for inv in invoices]

@api_router.get("/invoices/{invoice_id}", response_model=InvoiceResponse)
def get_invoice(invoice_id: str, db: Session = Depends(get_db)):
    invoice = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")
    return build_invoice_response(invoice, db)

@api_router.post("/invoices/{invoice_id}/reconcile-ocr", response_model=InvoiceReconcileOCRResponse)
def reconcile_invoice_ocr(
    invoice_id: str,
    payload: InvoiceReconcileOCRRequest,
    db: Session = Depends(get_db),
):
    from app.document_processing.parser import DocumentParser

    authorized_roles = {"AP_MANAGER", "FINANCE_CONTROLLER", "CFO", "ADMIN", "AUDITOR"}
    if payload.user_role not in authorized_roles:
        raise HTTPException(
            status_code=403,
            detail=f"Unauthorized role '{payload.user_role}' for OCR reconciliation. Requires AP_MANAGER, CFO, or AUDITOR.",
        )

    inv = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    if not inv:
        raise HTTPException(status_code=404, detail="Invoice not found")

    # Locate the matching document
    doc = None
    if inv.document_id:
        doc = db.query(Document).filter(Document.id == inv.document_id).first()
    if not doc:
        clean_inv = inv.id.replace("-", "_")
        doc = (
            db.query(Document)
            .filter(
                (Document.ocr_raw_text.ilike(f"%{inv.id}%"))
                | (Document.file_name.ilike(f"%{clean_inv}%"))
            )
            .order_by(Document.uploaded_at.desc())
            .first()
        )

    if not doc or not doc.ocr_raw_text:
        raise HTTPException(
            status_code=400,
            detail="No OCR extraction artifact found for this invoice. Cannot reconcile without document artifact.",
        )

    parsed = DocumentParser.parse_invoice(
        doc.ocr_raw_text, is_scanned_image=not doc.mime_type.endswith("pdf")
    )

    old_state = {
        "vendor_id": inv.vendor_id,
        "vendor_gstin": inv.vendor_gstin,
        "po_reference": inv.po_reference,
        "document_id": inv.document_id,
    }
    updated_fields = []

    # 1. Reconcile Vendor if requested
    if payload.accept_ocr_vendor:
        ocr_gstin = parsed.get("vendor_gstin")
        ocr_vendor_name = parsed.get("vendor_name")
        target_vendor = None
        if ocr_gstin:
            target_vendor = db.query(Vendor).filter(Vendor.gstin == ocr_gstin).first()
        if not target_vendor and ocr_vendor_name:
            target_vendor = db.query(Vendor).filter(Vendor.name.ilike(f"%{ocr_vendor_name}%")).first()

        if not target_vendor:
            raise HTTPException(
                status_code=400,
                detail=f"Vendor with GSTIN '{ocr_gstin}' or Name '{ocr_vendor_name}' not found in vendor master database.",
            )
        inv.vendor_id = target_vendor.id
        inv.vendor_gstin = target_vendor.gstin
        updated_fields.extend(["vendor_id", "vendor_gstin"])

    # 2. Reconcile PO Reference if requested
    if payload.accept_ocr_po:
        ocr_po = parsed.get("po_reference")
        if ocr_po:
            target_po = db.query(PurchaseOrder).filter(PurchaseOrder.id == ocr_po).first()
            if not target_po:
                raise HTTPException(
                    status_code=400,
                    detail=f"Purchase Order '{ocr_po}' extracted from OCR does not exist in PO database.",
                )
            inv.po_reference = target_po.id
            updated_fields.append("po_reference")

    # 3. Link Document ID
    inv.document_id = doc.id
    updated_fields.append("document_id")

    # Record Audit Log
    new_state = {
        "vendor_id": inv.vendor_id,
        "vendor_gstin": inv.vendor_gstin,
        "po_reference": inv.po_reference,
        "document_id": inv.document_id,
    }
    audit_id = str(uuid.uuid4())
    audit = AuditLog(
        id=audit_id,
        entity_type="INVOICE_OCR_RECONCILIATION",
        entity_id=inv.id,
        action="HUMAN_CONFIRMED_OCR_RECONCILIATION",
        actor_type="USER",
        actor_id=payload.confirmed_by,
        old_state=old_state,
        new_state=new_state,
    )
    db.add(audit)
    db.commit()
    db.refresh(inv)

    v_name = inv.vendor.name if inv.vendor else inv.vendor_id

    return InvoiceReconcileOCRResponse(
        invoice_id=inv.id,
        status="RECONCILED",
        updated_fields=updated_fields,
        vendor_id=inv.vendor_id,
        vendor_name=v_name,
        vendor_gstin=inv.vendor_gstin,
        po_reference=inv.po_reference,
        audit_log_id=audit_id,
        message=f"Invoice successfully reconciled with verified document artifact by {payload.confirmed_by}.",
    )

# --- Purchase Order Details ---
@api_router.get("/purchase-orders/{po_id}", response_model=POResponse)
def get_purchase_order(po_id: str, db: Session = Depends(get_db)):
    po = db.query(PurchaseOrder).filter(PurchaseOrder.id == po_id).first()
    if not po:
        raise HTTPException(status_code=404, detail="Purchase Order not found")
    return po

# --- Goods Receipt Notes for PO ---
@api_router.get("/grn/by-po/{po_id}", response_model=List[GRNResponse])
def get_grns_by_po(po_id: str, db: Session = Depends(get_db)):
    return db.query(GoodsReceiptNote).filter(GoodsReceiptNote.po_id == po_id).all()

# --- Three-Way Matching Engine Endpoints ---
@api_router.get("/matching", response_model=List[MatchingResponse])
def list_matching_results(
    match_status: Optional[str] = None,
    db: Session = Depends(get_db),
):
    query = db.query(MatchingResult)
    if match_status:
        query = query.filter(MatchingResult.match_status == match_status)
    records = query.all()
    results = []
    for r in records:
        inv = db.query(Invoice).filter(Invoice.id == r.invoice_id).first()
        vendor_name = inv.vendor.name if inv and inv.vendor else (inv.vendor_id if inv else "Unknown")
        results.append(
            MatchingResponse(
                invoice_id=r.invoice_id,
                vendor_id=inv.vendor_id if inv else None,
                vendor_name=vendor_name,
                po_id=r.po_id,
                grn_id=r.grn_id,
                match_status=r.match_status,
                price_variance_percent=float(r.price_variance_percent or 0.0),
                quantity_variance_percent=float(r.quantity_variance_percent or 0.0),
                tax_variance_inr=float(r.tax_variance_inr or 0.0),
                total_financial_impact_inr=float(r.total_financial_impact_inr or 0.0),
                is_matched=r.is_matched,
                evaluation_notes=r.evaluation_notes,
                discrepancies=r.discrepancies or [],
                line_evaluations=r.line_evaluations or [],
                evaluated_at=r.evaluated_at.isoformat() if r.evaluated_at else None,
            )
        )
    return results

@api_router.get("/matching/{invoice_id}", response_model=TriangulationDetailResponse)
def get_triangulation_detail(invoice_id: str, db: Session = Depends(get_db)):
    invoice = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")
    
    vendor = invoice.vendor
    po = db.query(PurchaseOrder).filter(PurchaseOrder.id == invoice.po_reference).first() if invoice.po_reference else None
    grns = db.query(GoodsReceiptNote).filter(GoodsReceiptNote.po_id == po.id).all() if po else []
    
    match_rec = db.query(MatchingResult).filter(MatchingResult.invoice_id == invoice.id).first()
    matching_resp = None
    if match_rec:
        matching_resp = MatchingResponse(
            invoice_id=match_rec.invoice_id,
            vendor_id=invoice.vendor_id,
            vendor_name=vendor.name if vendor else invoice.vendor_id,
            po_id=match_rec.po_id,
            grn_id=match_rec.grn_id,
            match_status=match_rec.match_status,
            price_variance_percent=float(match_rec.price_variance_percent or 0.0),
            quantity_variance_percent=float(match_rec.quantity_variance_percent or 0.0),
            tax_variance_inr=float(match_rec.tax_variance_inr or 0.0),
            total_financial_impact_inr=float(match_rec.total_financial_impact_inr or 0.0),
            is_matched=match_rec.is_matched,
            evaluation_notes=match_rec.evaluation_notes,
            discrepancies=match_rec.discrepancies or [],
            line_evaluations=match_rec.line_evaluations or [],
            evaluated_at=match_rec.evaluated_at.isoformat() if match_rec.evaluated_at else None,
        )
    
    return TriangulationDetailResponse(
        invoice=invoice,
        vendor=vendor,
        purchase_order=po,
        goods_receipt_notes=grns,
        matching_result=matching_resp,
    )

@api_router.post("/matching/evaluate/{invoice_id}", response_model=MatchingResponse)
def evaluate_matching_for_invoice(
    invoice_id: str,
    payload: Optional[MatchingEvaluateRequest] = None,
    db: Session = Depends(get_db),
):
    try:
        price_tol = Decimal(str(payload.price_tolerance_pct)) if payload and payload.price_tolerance_pct is not None else Decimal("2.0")
        qty_tol = Decimal(str(payload.qty_tolerance_pct)) if payload and payload.qty_tolerance_pct is not None else Decimal("0.0")
        tax_tol = Decimal(str(payload.tax_tolerance_inr)) if payload and payload.tax_tolerance_inr is not None else Decimal("5.0")
        classify_partial = payload.classify_partial_receipt if payload and payload.classify_partial_receipt is not None else True

        result_dict = MatchingService.evaluate_invoice_matching(
            invoice_id=invoice_id,
            db=db,
            price_tolerance_pct=price_tol,
            qty_tolerance_pct=qty_tol,
            tax_tolerance_inr=tax_tol,
            classify_partial_receipt=classify_partial,
        )
        return MatchingResponse(**result_dict)
    except ValueError as ve:
        raise HTTPException(status_code=404, detail=str(ve))
    except Exception as ex:
        raise HTTPException(status_code=500, detail=f"Matching evaluation failed: {str(ex)}")

@api_router.post("/matching/evaluate-all")
def evaluate_all_invoices(db: Session = Depends(get_db)):
    invoices = db.query(Invoice).all()
    evaluated = []
    for inv in invoices:
        try:
            res = MatchingService.evaluate_invoice_matching(inv.id, db)
            evaluated.append({"invoice_id": inv.id, "match_status": res["match_status"]})
        except Exception as ex:
            evaluated.append({"invoice_id": inv.id, "error": str(ex)})
    return {"total_evaluated": len(evaluated), "details": evaluated}

# --- Exceptions Workbench ---
@api_router.get("/exceptions", response_model=List[ExceptionResponse])
def list_exceptions(
    status: Optional[str] = None,
    severity: Optional[str] = None,
    db: Session = Depends(get_db),
):
    query = db.query(ExceptionRecord)
    if status:
        query = query.filter(ExceptionRecord.status == status)
    if severity:
        query = query.filter(ExceptionRecord.severity == severity)
    records = query.all()
    results = []
    for r in records:
        v_name = "Supplier Partner"
        if r.invoice and r.invoice.vendor:
            v_name = r.invoice.vendor.name
        results.append(
            ExceptionResponse(
                id=r.id,
                invoice_id=r.invoice_id,
                vendor_name=v_name,
                category=r.category,
                severity=r.severity,
                expected_value=r.expected_value,
                actual_value=r.actual_value,
                difference_value=r.difference_value,
                financial_impact_inr=float(r.financial_impact_inr or 0.0),
                responsible_department=r.responsible_department,
                status=r.status,
                created_at=r.created_at,
                resolution_notes=r.resolution_notes,
            )
        )
    return results

# --- Approvals Queue ---
@api_router.get("/approvals", response_model=List[ApprovalResponse])
def list_approvals(
    status: Optional[str] = None,
    search: Optional[str] = Query(None, description="Search by invoice number, approval ID, or supplier name"),
    db: Session = Depends(get_db),
):
    query = db.query(ApprovalRequest)
    if status and status != "ALL":
        query = query.filter(ApprovalRequest.status == status)
    records = query.all()
    results = []
    clean_search = search.strip().lower() if search and search.strip() else None

    for r in records:
        invoice = db.query(Invoice).filter(Invoice.id == r.invoice_id).first()
        v_name = "Partner Supplier"
        m_status = "REQUIRES_HUMAN_REVIEW"
        inv_status = "UNKNOWN"
        blocking_count = 0
        current_amount = float(r.amount_inr)

        if invoice:
            if invoice.vendor:
                v_name = invoice.vendor.name
            m_status = invoice.match_status
            inv_status = invoice.status
            current_amount = float(invoice.total_amount_inr)
            blocking_count = db.query(ExceptionRecord).filter(
                ExceptionRecord.invoice_id == invoice.id,
                ExceptionRecord.status == "OPEN",
            ).count()

        if clean_search:
            matches_approval = clean_search in r.id.lower()
            matches_invoice = clean_search in r.invoice_id.lower()
            matches_vendor = clean_search in v_name.lower()
            if not (matches_approval or matches_invoice or matches_vendor):
                continue

        results.append(
            ApprovalResponse(
                id=r.id,
                invoice_id=r.invoice_id,
                vendor_name=v_name,
                required_role=r.required_role,
                amount_inr=current_amount,
                status=r.status,
                match_status=m_status,
                invoice_status=inv_status,
                blocking_exceptions_count=blocking_count,
                created_at=r.created_at,
            )
        )
    return results

@api_router.post("/approvals/{approval_id}/action", response_model=ApprovalResponse)
def action_approval(
    approval_id: str,
    payload: ApprovalActionRequest,
    user_role: Optional[str] = Query("FINANCE_CONTROLLER"),
    db: Session = Depends(get_db),
):
    req = db.query(ApprovalRequest).filter(ApprovalRequest.id == approval_id).first()
    if not req:
        raise HTTPException(status_code=404, detail="Approval request not found")

    invoice = db.query(Invoice).filter(Invoice.id == req.invoice_id).first()
    if not invoice:
        raise HTTPException(status_code=404, detail="Linked invoice not found")

    # Financial Control Guard on Approval Decision
    if payload.action == "APPROVED":
        # 1. Invoice Status Check: Cannot approve invoice on EXCEPTION_HOLD
        if invoice.status == "EXCEPTION_HOLD":
            raise HTTPException(
                status_code=400,
                detail=f"Financial Control Violation: Cannot approve invoice '{invoice.id}'. It is currently on EXCEPTION_HOLD.",
            )

        # 2. Match Status Check: Cannot approve invoice with discrepancy or missing documentation
        discrepancy_statuses = {
            "MISSING_PO",
            "MISSING_GRN",
            "DUPLICATE_INVOICE",
            "QUANTITY_MISMATCH",
            "PRICE_MISMATCH",
            "TAX_MISMATCH",
            "ITEM_MISMATCH",
            "VENDOR_MISMATCH",
            "REQUIRES_HUMAN_REVIEW",
        }
        if invoice.match_status in discrepancy_statuses:
            raise HTTPException(
                status_code=400,
                detail=f"Financial Control Violation: Invoice has unverified match status '{invoice.match_status}'. Approval is prohibited.",
            )

        # 3. Open Exception Check: Cannot approve invoice with unresolved exceptions
        open_exceptions = db.query(ExceptionRecord).filter(
            ExceptionRecord.invoice_id == invoice.id,
            ExceptionRecord.status == "OPEN",
        ).all()
        if open_exceptions:
            categories = ", ".join(e.category for e in open_exceptions)
            raise HTTPException(
                status_code=400,
                detail=f"Financial Control Violation: Invoice has {len(open_exceptions)} unresolved exception ticket(s) ({categories}). All exceptions must be resolved before approval.",
            )

        # 4. Role Authorization Ceilings: Delegation of Authority
        effective_role = payload.user_role or user_role or "FINANCE_CONTROLLER"
        inv_amt = float(invoice.total_amount_inr)
        if effective_role == "FINANCE_EXECUTIVE" and inv_amt > 100000.0:
            raise HTTPException(
                status_code=403,
                detail=f"Authorization Ceiling Exceeded: Finance Executive limit is ₹1,00,000. Invoice amount ₹{inv_amt:,.2f} requires AP Manager or Finance Controller.",
            )
        elif effective_role == "AP_MANAGER" and inv_amt > 1000000.0:
            raise HTTPException(
                status_code=403,
                detail=f"Authorization Ceiling Exceeded: AP Manager limit is ₹10,00,000. Invoice amount ₹{inv_amt:,.2f} requires Finance Controller.",
            )

    req.status = payload.action
    req.amount_inr = invoice.total_amount_inr

    # Update linked invoice status
    if payload.action == "APPROVED":
        invoice.status = "APPROVED"
    elif payload.action == "REJECTED":
        invoice.status = "REJECTED"
    elif payload.action == "HELD":
        invoice.status = "EXCEPTION_HOLD"

    # Write tamper-evident audit log
    audit = AuditLog(
        entity_type="INVOICE_APPROVAL",
        entity_id=req.invoice_id,
        action=f"APPROVAL_{payload.action}",
        actor_type="USER",
        actor_id=f"u-{user_role.lower().replace('_', '-')}",
        old_state={"status": req.status, "amount": float(req.amount_inr)},
        new_state={"status": payload.action, "comments": payload.comments, "amount": float(invoice.total_amount_inr)},
    )
    db.add(audit)
    db.commit()
    db.refresh(req)

    v_name = invoice.vendor.name if invoice.vendor else "Partner Supplier"
    return ApprovalResponse(
        id=req.id,
        invoice_id=req.invoice_id,
        vendor_name=v_name,
        required_role=req.required_role,
        amount_inr=float(invoice.total_amount_inr),
        status=req.status,
        match_status=invoice.match_status,
        invoice_status=invoice.status,
        blocking_exceptions_count=0,
        created_at=req.created_at,
    )

# Additional Endpoints for Advanced Finance Features
from app.analytics.roi_modeler import FinancialAnalyticsModeler
from app.analytics.copilot_engine import CopilotQueryEngine
from app.schemas.financial_schemas import (
    CopilotQueryRequest,
    CopilotQueryResponse,
    ExceptionResolveRequest,
    ExceptionResolveResponse,
)

@api_router.get("/analytics/roi-model")
def get_roi_model():
    return FinancialAnalyticsModeler.calculate_roi_scenarios()

@api_router.post("/copilot/query", response_model=CopilotQueryResponse)
def copilot_query(payload: CopilotQueryRequest, db: Session = Depends(get_db)):
    result = CopilotQueryEngine.answer_query(payload.query, db)
    return CopilotQueryResponse(**result)

@api_router.post("/exceptions/{exception_id}/resolve", response_model=ExceptionResolveResponse)
def resolve_exception(
    exception_id: str,
    payload: ExceptionResolveRequest,
    db: Session = Depends(get_db),
):
    exc = db.query(ExceptionRecord).filter(ExceptionRecord.id == exception_id).first()
    if not exc:
        raise HTTPException(status_code=404, detail="Exception ticket not found")

    # Section 3: Enforce Exception-Specific Controls
    # - Missing PO: Require valid procurement documentation (cannot bypass with ACCEPT_VARIANCE)
    if exc.category == "MISSING_PO" and payload.action == "ACCEPT_VARIANCE":
        raise HTTPException(
            status_code=400,
            detail="Policy Control Violation: Missing Purchase Order cannot be bypassed using 'ACCEPT_VARIANCE'. Valid procurement documentation or PO amendment is required.",
        )

    # - Duplicate invoice: Block approval pending duplicate investigation (cannot bypass with ACCEPT_VARIANCE)
    if exc.category == "DUPLICATE_INVOICE" and payload.action == "ACCEPT_VARIANCE":
        raise HTTPException(
            status_code=400,
            detail="Policy Control Violation: Duplicate invoice exceptions cannot be bypassed using 'ACCEPT_VARIANCE'. Fraud and duplicate verification is mandatory.",
        )

    # - Quantity mismatch: Require goods receipt verification or debit note
    if exc.category == "QUANTITY_MISMATCH" and payload.action == "ACCEPT_VARIANCE":
        raise HTTPException(
            status_code=400,
            detail="Policy Control Violation: Quantity discrepancy cannot be accepted via variance without warehouse goods receipt verification. Issue debit note or correct GRN.",
        )

    # - Tax mismatch: Cannot accept tax variance exceeding statutory rounding tolerance of ₹5.00
    if exc.category == "TAX_MISMATCH" and payload.action == "ACCEPT_VARIANCE" and float(exc.financial_impact_inr or 0) > 5.0:
        raise HTTPException(
            status_code=400,
            detail="Policy Control Violation: Statutory GST tax discrepancies exceeding ₹5.00 cannot be accepted via variance. A revised tax invoice or debit note is mandatory.",
        )

    exc.status = "RESOLVED"
    exc.resolution_notes = payload.resolution_notes
    exc.resolved_at = datetime.utcnow()

    # If action is debit note, simulate debit note creation
    debit_note_ref = None
    if payload.action == "ISSUE_DEBIT_NOTE":
        debit_note_ref = f"DN-{exc.id.replace('EXC-', '')}"

    # Section 5 requirement: Resolving an exception does NOT automatically approve an invoice!
    # If all open exceptions for this invoice are now resolved, transition invoice to PENDING_APPROVAL for human sign-off
    invoice = db.query(Invoice).filter(Invoice.id == exc.invoice_id).first()
    if invoice:
        remaining_open_excs = db.query(ExceptionRecord).filter(
            ExceptionRecord.invoice_id == invoice.id,
            ExceptionRecord.id != exc.id,
            ExceptionRecord.status == "OPEN",
        ).count()
        if remaining_open_excs == 0:
            invoice.status = "PENDING_APPROVAL"
            invoice.match_status = "RECONCILED_WITH_EXCEPTION"
            # Ensure linked approval request is PENDING (never automatically APPROVED)
            appr_req = db.query(ApprovalRequest).filter(ApprovalRequest.invoice_id == invoice.id).first()
            if appr_req:
                appr_req.status = "PENDING"
                appr_req.amount_inr = invoice.total_amount_inr

    # Log audit trail
    audit = AuditLog(
        entity_type="EXCEPTION_RESOLVED",
        entity_id=exc.id,
        action=f"RESOLVE_{payload.action}",
        actor_type="USER",
        actor_id="u-manager",
        old_state={"status": "OPEN"},
        new_state={
            "status": "RESOLVED",
            "action": payload.action,
            "debit_note_ref": debit_note_ref,
            "notes": payload.resolution_notes,
        },
    )
    db.add(audit)
    db.commit()
    db.refresh(exc)

    return ExceptionResolveResponse(
        exception_id=exc.id,
        invoice_id=exc.invoice_id,
        status="RESOLVED",
        action_taken=payload.action,
        resolution_notes=payload.resolution_notes,
        debit_note_reference=debit_note_ref,
    )

# --- Document Center & Ingestion ---
from app.document_processing.parser import DocumentParser

@api_router.get("/documents", response_model=List[DocumentResponse])
def list_documents(db: Session = Depends(get_db)):
    docs = db.query(Document).order_by(Document.uploaded_at.desc()).all()
    results = []
    for doc in docs:
        parsed = None
        if doc.ocr_raw_text and len(doc.ocr_raw_text.strip()) > 0:
            parsed = DocumentParser.parse_invoice(doc.ocr_raw_text, is_scanned_image=not doc.mime_type.endswith("pdf"))
        results.append(
            DocumentResponse(
                id=doc.id,
                file_name=doc.file_name,
                file_size_bytes=doc.file_size_bytes,
                mime_type=doc.mime_type,
                document_type=doc.document_type,
                ocr_confidence_score=float(doc.ocr_confidence_score) if doc.ocr_confidence_score is not None else None,
                ocr_raw_text=doc.ocr_raw_text,
                parsed_invoice=parsed,
                uploaded_at=doc.uploaded_at,
            )
        )
    return results

@api_router.get("/documents/{document_id}", response_model=DocumentResponse)
def get_document(document_id: str, db: Session = Depends(get_db)):
    doc = db.query(Document).filter(Document.id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    parsed = None
    if doc.ocr_raw_text and len(doc.ocr_raw_text.strip()) > 0:
        parsed = DocumentParser.parse_invoice(doc.ocr_raw_text, is_scanned_image=not doc.mime_type.endswith("pdf"))
    return DocumentResponse(
        id=doc.id,
        file_name=doc.file_name,
        file_size_bytes=doc.file_size_bytes,
        mime_type=doc.mime_type,
        document_type=doc.document_type,
        ocr_confidence_score=float(doc.ocr_confidence_score) if doc.ocr_confidence_score is not None else None,
        ocr_raw_text=doc.ocr_raw_text,
        parsed_invoice=parsed,
        uploaded_at=doc.uploaded_at,
    )

@api_router.post("/documents/upload", response_model=DocumentUploadResponse)
async def upload_document(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    # 1. File Format & Extension Validation
    allowed_extensions = {".pdf", ".jpg", ".jpeg", ".png"}
    orig_name = file.filename or "unknown_invoice"
    _, ext = os.path.splitext(orig_name.lower())
    if ext not in allowed_extensions:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file format '{ext}'. AP Intelligence accepts PDF, JPG, and PNG documents.",
        )

    # 2. File Size Validation (Max 10MB)
    content = await file.read()
    file_size = len(content)
    if file_size > 10 * 1024 * 1024:
        raise HTTPException(
            status_code=400,
            detail=f"File size exceeds 10MB limit ({file_size / (1024 * 1024):.2f}MB).",
        )

    upload_dir = os.path.join(os.path.dirname(__file__), "..", "..", "data", "uploads")
    os.makedirs(upload_dir, exist_ok=True)

    file_id = str(uuid.uuid4())
    clean_filename = f"{datetime.utcnow().strftime('%Y%m%d%H%M%S')}_{orig_name}"
    file_path = os.path.join(upload_dir, clean_filename)

    with open(file_path, "wb") as buffer:
        buffer.write(content)

    mime_type = file.content_type or ("application/pdf" if ext == ".pdf" else "image/png")

    # 3. Document Extraction & OCR
    ocr_text = ""
    parsed: Dict[str, Any] = {}
    confidence = 0.95
    is_image = ext in {".jpg", ".jpeg", ".png"}

    if ext == ".pdf":
        try:
            ocr_text = DocumentParser.extract_text_from_pdf(file_path)
            if ocr_text and ocr_text.strip():
                parsed = DocumentParser.parse_invoice(ocr_text, is_scanned_image=False)
                confidence = parsed.get("overall_confidence", 0.95)
            else:
                ocr_text = f"Scanned raster PDF invoice: '{orig_name}' contains image scans without embedded text streams. Requires optical character recognition."
                parsed = DocumentParser.parse_invoice(text="", is_scanned_image=True)
                confidence = 0.50
        except Exception as e:
            ocr_text = f"Text extraction warning: {str(e)}"
            parsed = DocumentParser.parse_invoice(text="", is_scanned_image=True)
            confidence = 0.50
    elif is_image:
        try:
            img_info = DocumentParser.inspect_image(file_path)
            ocr_text = f"Scanned raster image invoice: {orig_name} ({img_info['size'][0]}x{img_info['size'][1]} {img_info['format']})"
            parsed = DocumentParser.parse_invoice(text="", is_scanned_image=True)
            confidence = 0.65
        except Exception as e:
            ocr_text = f"Image inspection warning: {str(e)}"
            confidence = 0.50

    # 4. Save Document Record
    doc = Document(
        id=file_id,
        file_name=orig_name,
        file_path=file_path,
        file_size_bytes=file_size,
        mime_type=mime_type,
        document_type="INVOICE",
        ocr_raw_text=ocr_text[:3000] if ocr_text else None,
        ocr_confidence_score=confidence,
        uploaded_at=datetime.utcnow(),
    )
    db.add(doc)
    db.commit()
    db.refresh(doc)

    # 5. Deterministic Validation
    existing_invoices = [r[0] for r in db.query(Invoice.id).all()]
    val_result = InvoiceValidator.validate_invoice(parsed, existing_invoices=existing_invoices)

    created_inv_id = None
    workflow_status = "INGESTED"
    inv_num = parsed.get("invoice_number")

    # 6. Database Persistence of Invoice & Line Items
    if inv_num and val_result["field_validations"].get("invoice_number", True):
        # Duplicate detection
        if inv_num in existing_invoices:
            workflow_status = "DUPLICATE_ALERT"
            val_result["is_valid"] = False
            val_result["errors"].append(f"Duplicate invoice: '{inv_num}' is already persisted in the database.")
        else:
            # Match vendor
            vendor = None
            if parsed.get("vendor_gstin"):
                vendor = db.query(Vendor).filter(Vendor.gstin == parsed["vendor_gstin"]).first()
            if not vendor and parsed.get("vendor_name"):
                vendor = db.query(Vendor).filter(Vendor.name.ilike(f"%{parsed['vendor_name'][:10]}%")).first()
            if not vendor:
                vendor = db.query(Vendor).first()

            vendor_id = vendor.id if vendor else "VEND-001"

            # Parse dates safely
            inv_date = date.today()
            due_date = date.today()
            if parsed.get("invoice_date"):
                try:
                    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
                        try:
                            inv_date = datetime.strptime(str(parsed["invoice_date"]).strip(), fmt).date()
                            break
                        except ValueError:
                            pass
                except Exception:
                    pass

            if parsed.get("due_date"):
                try:
                    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
                        try:
                            due_date = datetime.strptime(str(parsed["due_date"]).strip(), fmt).date()
                            break
                        except ValueError:
                            pass
                except Exception:
                    pass

            # Create Invoice
            new_inv = Invoice(
                id=inv_num,
                vendor_id=vendor_id,
                po_reference=parsed.get("po_reference"),
                document_id=doc.id,
                invoice_date=inv_date,
                due_date=due_date,
                vendor_gstin=parsed.get("vendor_gstin") or (vendor.gstin if vendor else "27AAACT2727Q1ZW"),
                recipient_gstin=parsed.get("recipient_gstin") or "27AABCA9876K1Z5",
                place_of_supply=parsed.get("place_of_supply") or "27",
                taxable_value_inr=parsed.get("taxable_value", 0.0),
                cgst_amount_inr=parsed.get("cgst_amount", 0.0),
                sgst_amount_inr=parsed.get("sgst_amount", 0.0),
                igst_amount_inr=parsed.get("igst_amount", 0.0),
                total_tax_inr=parsed.get("total_tax", 0.0),
                total_amount_inr=parsed.get("total_amount", 0.0),
                currency=parsed.get("currency", "INR"),
                status="INGESTED" if val_result["is_valid"] else "REQUIRES_HUMAN_REVIEW",
                match_status="REQUIRES_HUMAN_REVIEW",
                extraction_confidence=confidence,
                payment_status="UNPAID",
                created_at=datetime.utcnow(),
            )
            db.add(new_inv)
            db.commit()
            db.refresh(new_inv)
            created_inv_id = new_inv.id
            workflow_status = new_inv.status

            # Create Line Items
            for item in parsed.get("line_items", []):
                inv_item = InvoiceItem(
                    invoice_id=new_inv.id,
                    line_number=item.get("line_number", 1),
                    item_code=item.get("item_code", "ITEM-GENERAL"),
                    description=item.get("description", "General Line Item"),
                    hsn_sac_code=item.get("hsn_sac_code", "9988"),
                    quantity=item.get("quantity", 1.0),
                    unit_price_inr=item.get("unit_price", 0.0),
                    gst_rate_percent=item.get("gst_rate", 18.0),
                    taxable_amount_inr=item.get("taxable_amount", 0.0),
                    total_line_amount_inr=item.get("total_amount", 0.0),
                )
                db.add(inv_item)

            # Write Audit Trail
            audit = AuditLog(
                entity_type="INVOICE_INGESTION",
                entity_id=new_inv.id,
                action="DOCUMENT_UPLOAD_AND_EXTRACTED",
                actor_type="USER",
                actor_id="u-finance-executive",
                old_state=None,
                new_state={
                    "invoice_number": new_inv.id,
                    "document_id": doc.id,
                    "validation_errors": val_result["errors"],
                    "confidence": float(confidence),
                },
            )
            db.add(audit)
            db.commit()

    return DocumentUploadResponse(
        document_id=doc.id,
        file_name=doc.file_name,
        parsed_invoice=parsed if parsed else None,
        extraction_confidence=confidence,
        ocr_preview=ocr_text[:300] if ocr_text else "No preview available",
        invoice_id=created_inv_id,
        workflow_status=workflow_status,
        is_valid=val_result["is_valid"],
        validation_errors=val_result["errors"],
        validation_warnings=val_result["warnings"],
        requires_human_review=val_result["requires_human_review"],
    )

@api_router.put("/invoices/{invoice_id}", response_model=InvoiceResponse)
def update_invoice(
    invoice_id: str,
    payload: InvoiceUpdateRequest,
    db: Session = Depends(get_db),
):
    inv = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    if not inv:
        raise HTTPException(status_code=404, detail="Invoice not found")

    old_state = {"status": inv.status, "total_amount": float(inv.total_amount_inr)}

    # Apply header updates
    if payload.vendor_gstin is not None:
        inv.vendor_gstin = payload.vendor_gstin
        inv.place_of_supply = payload.vendor_gstin[:2] if len(payload.vendor_gstin) >= 2 else inv.place_of_supply
    if payload.po_reference is not None:
        inv.po_reference = payload.po_reference
    if payload.invoice_date is not None:
        inv.invoice_date = payload.invoice_date
    if payload.due_date is not None:
        inv.due_date = payload.due_date
    if payload.taxable_value_inr is not None:
        inv.taxable_value_inr = payload.taxable_value_inr
    if payload.cgst_amount_inr is not None:
        inv.cgst_amount_inr = payload.cgst_amount_inr
    if payload.sgst_amount_inr is not None:
        inv.sgst_amount_inr = payload.sgst_amount_inr
    if payload.igst_amount_inr is not None:
        inv.igst_amount_inr = payload.igst_amount_inr
    if payload.total_amount_inr is not None:
        inv.total_amount_inr = payload.total_amount_inr
        inv.total_tax_inr = (inv.cgst_amount_inr or 0) + (inv.sgst_amount_inr or 0) + (inv.igst_amount_inr or 0)

    # Apply items updates if provided
    if payload.items is not None:
        db.query(InvoiceItem).filter(InvoiceItem.invoice_id == inv.id).delete()
        for it in payload.items:
            db_item = InvoiceItem(
                invoice_id=inv.id,
                line_number=it.line_number,
                item_code=it.item_code,
                description=it.description,
                hsn_sac_code=it.hsn_sac_code,
                quantity=it.quantity,
                unit_price_inr=it.unit_price_inr,
                gst_rate_percent=it.gst_rate_percent,
                taxable_amount_inr=it.taxable_amount_inr,
                total_line_amount_inr=it.total_line_amount_inr,
            )
            db.add(db_item)

    # Re-validate
    inv_data_for_val = {
        "invoice_number": inv.id,
        "invoice_date": inv.invoice_date,
        "due_date": inv.due_date,
        "vendor_gstin": inv.vendor_gstin,
        "recipient_gstin": inv.recipient_gstin,
        "taxable_value": float(inv.taxable_value_inr),
        "cgst_amount": float(inv.cgst_amount_inr),
        "sgst_amount": float(inv.sgst_amount_inr),
        "igst_amount": float(inv.igst_amount_inr),
        "total_tax": float(inv.total_tax_inr),
        "total_amount": float(inv.total_amount_inr),
    }
    val = InvoiceValidator.validate_invoice(inv_data_for_val)
    if val["is_valid"]:
        inv.status = "VERIFIED_VALID"
    else:
        inv.status = "REQUIRES_HUMAN_REVIEW"

    # Synchronize linked Approval Requests
    appr_reqs = db.query(ApprovalRequest).filter(ApprovalRequest.invoice_id == inv.id).all()
    for req in appr_reqs:
        req.amount_inr = inv.total_amount_inr
        if inv.match_status in (
            "MISSING_PO",
            "MISSING_GRN",
            "DUPLICATE_INVOICE",
            "QUANTITY_MISMATCH",
            "PRICE_MISMATCH",
            "TAX_MISMATCH",
        ):
            req.status = "HELD"

    # Audit Log
    audit = AuditLog(
        entity_type="INVOICE_MANUAL_CORRECTION",
        entity_id=inv.id,
        action="INVOICE_FIELDS_CORRECTED",
        actor_type="USER",
        actor_id="u-finance-executive",
        old_state=old_state,
        new_state={"status": inv.status, "total_amount": float(inv.total_amount_inr)},
    )
    db.add(audit)
    db.commit()
    db.refresh(inv)
    return inv

@api_router.post("/invoices/{invoice_id}/validate", response_model=InvoiceValidationResponse)
def validate_stored_invoice(invoice_id: str, db: Session = Depends(get_db)):
    inv = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    if not inv:
        raise HTTPException(status_code=404, detail="Invoice not found")

    items = db.query(InvoiceItem).filter(InvoiceItem.invoice_id == inv.id).all()
    inv_data = {
        "invoice_number": inv.id,
        "invoice_date": inv.invoice_date,
        "due_date": inv.due_date,
        "vendor_gstin": inv.vendor_gstin,
        "recipient_gstin": inv.recipient_gstin,
        "taxable_value": float(inv.taxable_value_inr),
        "cgst_amount": float(inv.cgst_amount_inr),
        "sgst_amount": float(inv.sgst_amount_inr),
        "igst_amount": float(inv.igst_amount_inr),
        "total_tax": float(inv.total_tax_inr),
        "total_amount": float(inv.total_amount_inr),
        "line_items": [
            {
                "line_number": it.line_number,
                "item_code": it.item_code,
                "quantity": float(it.quantity),
                "unit_price": float(it.unit_price_inr),
                "taxable_amount": float(it.taxable_amount_inr),
            }
            for it in items
        ],
    }
    val = InvoiceValidator.validate_invoice(inv_data)
    return InvoiceValidationResponse(
        invoice_id=inv.id,
        is_valid=val["is_valid"],
        requires_human_review=val["requires_human_review"],
        errors=val["errors"],
        warnings=val["warnings"],
        discrepancy_amount_inr=val["discrepancy_amount_inr"],
        field_validations=val["field_validations"],
        validated_totals=val["validated_totals"],
    )
