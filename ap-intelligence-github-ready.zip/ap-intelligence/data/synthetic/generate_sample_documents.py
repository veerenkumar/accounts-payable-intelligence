import os
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors

def generate_sample_invoices(output_dir: str):
    os.makedirs(output_dir, exist_ok=True)
    styles = getSampleStyleSheet()

    # Document 1: Tata Steel Invoice (INV-2026-00452)
    doc1_path = os.path.join(output_dir, "INV_2026_00452_TataSteel.pdf")
    doc1 = SimpleDocTemplate(doc1_path, pagesize=letter)
    story1 = []

    story1.append(Paragraph("<b>TAX INVOICE</b>", styles["Title"]))
    story1.append(Spacer(1, 10))
    story1.append(Paragraph("<b>Supplier:</b> Tata Steel Products Ltd.", styles["Normal"]))
    story1.append(Paragraph("<b>Supplier GSTIN:</b> 27AAACT2727Q1ZW", styles["Normal"]))
    story1.append(Paragraph("<b>Recipient:</b> Apex Bharat Manufacturing Pvt. Ltd.", styles["Normal"]))
    story1.append(Paragraph("<b>Recipient GSTIN:</b> 27AABCA9876K1Z5", styles["Normal"]))
    story1.append(Spacer(1, 10))
    story1.append(Paragraph("<b>Invoice Number:</b> INV-2026-00452", styles["Normal"]))
    story1.append(Paragraph("<b>PO Reference:</b> PO-2026-00101", styles["Normal"]))
    story1.append(Paragraph("<b>Invoice Date:</b> 2026-11-01", styles["Normal"]))
    story1.append(Paragraph("<b>Due Date:</b> 2026-12-01", styles["Normal"]))
    story1.append(Spacer(1, 15))

    data1 = [
        ["Line", "Item Code", "Description", "HSN", "Qty", "Unit Rate (INR)", "Total (INR)"],
        ["1", "STL-BEAM-01", "Heavy Structural Steel Beams IS2062", "7216", "50.00", "4,180.00", "209,000.00"],
    ]
    t1 = Table(data1, colWidths=[30, 90, 180, 50, 45, 85, 80])
    t1.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.navy),
        ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('GRID', (0,0), (-1,-1), 0.5, colors.grey),
    ]))
    story1.append(t1)
    story1.append(Spacer(1, 15))

    story1.append(Paragraph("<b>Taxable Value:</b> INR 209,000.00", styles["Normal"]))
    story1.append(Paragraph("<b>CGST (9%):</b> INR 18,810.00", styles["Normal"]))
    story1.append(Paragraph("<b>SGST (9%):</b> INR 18,810.00", styles["Normal"]))
    story1.append(Paragraph("<b>Total Invoice Amount:</b> INR 246,620.00", styles["Normal"]))
    doc1.build(story1)

    # Document 2: Schneider Electric Invoice (INV-2026-00454) - Inter-State IGST
    doc2_path = os.path.join(output_dir, "INV_2026_00454_Schneider.pdf")
    doc2 = SimpleDocTemplate(doc2_path, pagesize=letter)
    story2 = []

    story2.append(Paragraph("<b>TAX INVOICE</b>", styles["Title"]))
    story2.append(Spacer(1, 10))
    story2.append(Paragraph("<b>Supplier:</b> Schneider Electric India Pvt. Ltd.", styles["Normal"]))
    story2.append(Paragraph("<b>Supplier GSTIN:</b> 29AAACS6328P1Z3", styles["Normal"]))
    story2.append(Paragraph("<b>Recipient:</b> Apex Bharat Manufacturing Pvt. Ltd.", styles["Normal"]))
    story2.append(Paragraph("<b>Recipient GSTIN:</b> 27AABCA9876K1Z5", styles["Normal"]))
    story2.append(Spacer(1, 10))
    story2.append(Paragraph("<b>Invoice Number:</b> INV-2026-00454", styles["Normal"]))
    story2.append(Paragraph("<b>PO Reference:</b> PO-2026-00108", styles["Normal"]))
    story2.append(Paragraph("<b>Invoice Date:</b> 2026-11-03", styles["Normal"]))
    story2.append(Paragraph("<b>Due Date:</b> 2026-12-18", styles["Normal"]))
    story2.append(Spacer(1, 15))

    data2 = [
        ["Line", "Item Code", "Description", "HSN", "Qty", "Unit Rate (INR)", "Total (INR)"],
        ["1", "SWG-MCCB-400A", "Molded Case Circuit Breaker 400A 3P", "8536", "4.00", "120,000.00", "480,000.00"],
    ]
    t2 = Table(data2, colWidths=[30, 95, 175, 50, 45, 85, 80])
    t2.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.navy),
        ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
        ('GRID', (0,0), (-1,-1), 0.5, colors.grey),
    ]))
    story2.append(t2)
    story2.append(Spacer(1, 15))

    story2.append(Paragraph("<b>Taxable Value:</b> INR 480,000.00", styles["Normal"]))
    story2.append(Paragraph("<b>IGST (18%):</b> INR 86,400.00", styles["Normal"]))
    story2.append(Paragraph("<b>Total Invoice Amount:</b> INR 566,400.00", styles["Normal"]))
    doc2.build(story2)

    print(f"Generated sample synthetic PDF invoices in: {output_dir}")

if __name__ == "__main__":
    generate_sample_invoices("/Users/veerenkumarkonchada/.gemini/antigravity/scratch/ap-intelligence/data/sample_documents")

