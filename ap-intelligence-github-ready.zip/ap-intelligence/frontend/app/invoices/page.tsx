"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { formatINR } from "@/lib/utils";
import { APIService } from "@/services/api";
import { Invoice } from "@/types/finance";
import { mockRecentInvoices } from "@/lib/mock-data";
import { StatusBadge } from "@/components/ui/StatusBadge";
import {
  Receipt,
  Search,
  Filter,
  Sparkles,
  FileText,
  Loader2,
  Edit3,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  X,
  Save,
  ShieldCheck,
  Calendar,
  Building,
  Check,
  RefreshCw,
} from "lucide-react";

export default function InvoicesPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [invoices, setInvoices] = useState<Invoice[]>(mockRecentInvoices);
  const [loading, setLoading] = useState(true);

  // Review & Correction Modal State
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [editForm, setEditForm] = useState<any>({});
  const [saving, setSaving] = useState(false);
  const [validating, setValidating] = useState(false);
  const [validationResult, setValidationResult] = useState<any | null>(null);
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);

  const loadInvoices = () => {
    APIService.getInvoices().then((data) => {
      if (data && data.length > 0) {
        setInvoices(data);
      }
      setLoading(false);
    });
  };

  useEffect(() => {
    loadInvoices();
  }, []);

  const openReviewModal = (inv: Invoice) => {
    setSelectedInvoice(inv);
    setEditForm({
      vendorGSTIN: inv.vendorGSTIN,
      poReference: inv.poReference,
      invoiceDate: inv.invoiceDate,
      dueDate: inv.dueDate,
      taxableValue: inv.taxableValue,
      cgst: inv.cgst,
      sgst: inv.sgst,
      igst: inv.igst,
      totalAmount: inv.totalAmount,
      lineItems: inv.lineItems || [],
    });
    setValidationResult(null);
    setSaveSuccess(null);
    setSaveError(null);
  };

  const handleValidateCurrent = async () => {
    if (!selectedInvoice) return;
    setValidating(true);
    try {
      const res = await APIService.validateInvoice(selectedInvoice.id);
      setValidationResult(res);
    } catch (err: any) {
      setValidationResult({
        is_valid: false,
        errors: [err.message || "Validation call failed"],
        warnings: [],
      });
    } finally {
      setValidating(false);
    }
  };

  const applyOCRValues = () => {
    if (!selectedInvoice?.ocrData) return;
    const ocr = selectedInvoice.ocrData;
    setEditForm((prev: any) => ({
      ...prev,
      vendorGSTIN: ocr.vendor_gstin || prev.vendorGSTIN,
      poReference: ocr.po_reference || prev.poReference,
      invoiceDate: ocr.invoice_date || prev.invoiceDate,
      dueDate: ocr.due_date || prev.dueDate,
      taxableValue: ocr.taxable_value !== undefined ? ocr.taxable_value : prev.taxableValue,
      cgst: ocr.cgst_amount !== undefined ? ocr.cgst_amount : prev.cgst,
      sgst: ocr.sgst_amount !== undefined ? ocr.sgst_amount : prev.sgst,
      igst: ocr.igst_amount !== undefined ? ocr.igst_amount : prev.igst,
      totalAmount: ocr.total_amount !== undefined ? ocr.total_amount : prev.totalAmount,
    }));
  };

  const handleReconcileOCR = async () => {
    if (!selectedInvoice) return;
    setSaving(true);
    setSaveError(null);
    setSaveSuccess(null);
    try {
      const res = await APIService.reconcileInvoiceOCR(selectedInvoice.id, {
        confirmed_by: "USR-002",
        user_role: "AP_MANAGER",
        accept_ocr_vendor: true,
        accept_ocr_po: true,
        accept_ocr_dates: true,
        comments: "Authorized human verification: reconciled invoice ledger with verified supplier document artifact.",
      });
      setSaveSuccess(`Reconciliation verified: ${res.message} (Audit Log: ${res.audit_log_id})`);
      loadInvoices();
    } catch (err: any) {
      setSaveError(err.message || "Failed to reconcile with OCR document.");
    } finally {
      setSaving(false);
    }
  };

  const handleSaveInvoice = async () => {
    if (!selectedInvoice) return;
    setSaving(true);
    setSaveError(null);
    setSaveSuccess(null);

    try {
      const payload = {
        vendor_gstin: editForm.vendorGSTIN,
        po_reference: editForm.poReference,
        invoice_date: editForm.invoiceDate,
        due_date: editForm.dueDate,
        taxable_value_inr: Number(editForm.taxableValue),
        cgst_amount_inr: Number(editForm.cgst),
        sgst_amount_inr: Number(editForm.sgst),
        igst_amount_inr: Number(editForm.igst),
        total_amount_inr: Number(editForm.totalAmount),
        items: (editForm.lineItems || []).map((li: any) => ({
          line_number: li.lineNumber || 1,
          item_code: li.itemCode || "ITEM-01",
          description: li.description || "Line Item",
          hsn_sac_code: li.hsnSac || "9988",
          quantity: Number(li.quantity),
          unit_price_inr: Number(li.unitPrice),
          gst_rate_percent: Number(li.gstRate || 18.0),
          taxable_amount_inr: Number(li.taxableAmount),
          total_line_amount_inr: Number(li.totalAmount),
        })),
      };

      await APIService.updateInvoice(selectedInvoice.id, payload);
      setSaveSuccess("Invoice updated and deterministic financial totals verified.");
      loadInvoices();
    } catch (err: any) {
      setSaveError(err.message || "Failed to update invoice.");
    } finally {
      setSaving(false);
    }
  };

  const filteredInvoices = invoices.filter((inv) => {
    const matchesSearch =
      inv.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.vendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.poReference.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.vendorGSTIN.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus =
      statusFilter === "ALL" ||
      inv.matchStatus === statusFilter ||
      inv.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono font-semibold text-accent-cyan tracking-wider uppercase">
              Agent 1: Invoice Intelligence
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-xs text-slate-400">OCR Extraction & Field Correction</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            Supplier Invoices Ledger
          </h1>
        </div>

        <div className="flex items-center space-x-3">
          <Link
            href="/documents"
            className="px-4 py-2 bg-gradient-to-r from-accent-blue to-accent-cyan text-white text-xs font-semibold rounded-lg shadow hover:opacity-90 transition flex items-center space-x-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Upload New Invoice</span>
          </Link>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-navy-900 border border-navy-800 rounded-xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search invoice number, PO, supplier, or GSTIN..."
            className="w-full bg-navy-950/80 border border-navy-700/80 rounded-lg pl-9 pr-4 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-accent-blue/60 transition"
          />
        </div>

        <div className="flex items-center space-x-3 w-full md:w-auto justify-between md:justify-end">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-navy-950/80 border border-navy-700/80 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-accent-blue"
          >
            <option value="ALL">All Statuses</option>
            <option value="EXACT_MATCH">Exact Match</option>
            <option value="MATCH_WITHIN_TOLERANCE">Within Tolerance</option>
            <option value="PRICE_MISMATCH">Price Mismatch</option>
            <option value="QUANTITY_MISMATCH">Quantity Mismatch</option>
            <option value="REQUIRES_HUMAN_REVIEW">Requires Review</option>
          </select>

          <div className="flex items-center space-x-2 text-xs text-slate-400 font-mono">
            {loading && <Loader2 className="w-3.5 h-3.5 animate-spin text-accent-cyan" />}
            <span>{filteredInvoices.length} invoices</span>
          </div>
        </div>
      </div>

      {/* Invoices Master Table */}
      <div className="bg-navy-900 border border-navy-800 rounded-xl p-6 space-y-4">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-navy-950/60 text-slate-400 uppercase text-[10px] tracking-wider border-b border-navy-800">
              <tr>
                <th className="py-2.5 px-3">Invoice Details</th>
                <th className="py-2.5 px-3 font-sans">Supplier & GSTIN</th>
                <th className="py-2.5 px-3">Taxable Value</th>
                <th className="py-2.5 px-3">CGST / SGST / IGST</th>
                <th className="py-2.5 px-3">Total Amount</th>
                <th className="py-2.5 px-3">OCR Conf.</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-navy-800/60">
              {filteredInvoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-navy-800/40 transition">
                  <td className="py-3 px-3">
                    <div className="font-bold text-accent-cyan">{inv.id}</div>
                    <div className="text-[10px] text-slate-400">PO: {inv.poReference || "None"}</div>
                  </td>
                  <td className="py-3 px-3 font-sans">
                    <div className="text-slate-200 font-medium">{inv.vendorName || inv.vendorId}</div>
                    <div className="text-[10px] font-mono text-slate-400">{inv.vendorGSTIN}</div>
                  </td>
                  <td className="py-3 px-3 text-slate-300">
                    {formatINR(inv.taxableValue)}
                  </td>
                  <td className="py-3 px-3 text-slate-400 text-[11px]">
                    {inv.igst > 0 ? (
                      <span>IGST: {formatINR(inv.igst)}</span>
                    ) : (
                      <span>C: {formatINR(inv.cgst)} | S: {formatINR(inv.sgst)}</span>
                    )}
                  </td>
                  <td className="py-3 px-3 font-bold text-white">
                    {formatINR(inv.totalAmount)}
                  </td>
                  <td className="py-3 px-3">
                    <span
                      className={`text-[11px] font-semibold ${
                        (inv.extractionConfidence || 0.95) >= 0.85
                          ? "text-accent-emerald"
                          : "text-accent-amber"
                      }`}
                    >
                      {((inv.extractionConfidence || 0.95) * 100).toFixed(1)}%
                    </span>
                  </td>
                  <td className="py-3 px-3">
                    <div className="space-y-1">
                      <StatusBadge status={inv.matchStatus || inv.status} size="sm" />
                      {inv.ocrDiscrepancies?.some((d) => d.has_conflict) && (
                        <span className="inline-flex items-center space-x-1 px-1.5 py-0.5 rounded text-[9px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/30">
                          <AlertTriangle className="w-2.5 h-2.5" />
                          <span>OCR Conflict</span>
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="py-3 px-3 text-right">
                    <button
                      onClick={() => openReviewModal(inv)}
                      className="px-2.5 py-1 bg-navy-800 hover:bg-navy-700 text-slate-200 border border-navy-700 rounded text-xs transition inline-flex items-center space-x-1"
                    >
                      <Edit3 className="w-3 h-3 text-accent-cyan" />
                      <span>Review / Edit</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Review & Field Correction Modal */}
      {selectedInvoice && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-navy-900 border border-navy-800 rounded-2xl max-w-3xl w-full p-6 space-y-5 shadow-2xl my-8">
            <div className="flex items-center justify-between border-b border-navy-800 pb-3">
              <div className="flex items-center space-x-3">
                <Receipt className="w-5 h-5 text-accent-cyan" />
                <div>
                  <h3 className="font-semibold text-white text-base">
                    Review & Correct Invoice: {selectedInvoice.id}
                  </h3>
                  <div className="text-xs text-slate-400 font-mono">
                    Supplier: {selectedInvoice.vendorName} • OCR Confidence:{" "}
                    {((selectedInvoice.extractionConfidence || 0.95) * 100).toFixed(1)}%
                  </div>
                </div>
              </div>
              <button
                onClick={() => setSelectedInvoice(null)}
                className="p-1 rounded-lg hover:bg-navy-800 text-slate-400 hover:text-white transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Notification Banners */}
            {saveSuccess && (
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-lg flex items-center space-x-2 text-xs text-emerald-300">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{saveSuccess}</span>
              </div>
            )}
            {saveError && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-lg flex items-center space-x-2 text-xs text-rose-300">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{saveError}</span>
              </div>
            )}

            {/* Document OCR vs Ledger Reconciliation Panel */}
            {selectedInvoice.ocrDiscrepancies && selectedInvoice.ocrDiscrepancies.length > 0 && (
              <div className="bg-navy-950 border border-amber-500/40 rounded-xl p-4 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-navy-800 pb-3">
                  <div className="flex items-center space-x-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                    <div>
                      <h4 className="text-xs font-semibold text-white">Document OCR vs Ledger Reconciliation Conflict</h4>
                      <p className="text-[11px] text-slate-400">
                        Discrepancies detected between scanned PDF artifact and ERP Ledger. Safe reconciliation requires authorized human verification.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 shrink-0">
                    <button
                      type="button"
                      onClick={applyOCRValues}
                      className="px-2.5 py-1.5 bg-navy-800 hover:bg-navy-700 text-slate-200 border border-navy-600 rounded text-xs font-mono transition"
                    >
                      Fill Form with OCR
                    </button>
                    <button
                      type="button"
                      onClick={handleReconcileOCR}
                      disabled={saving}
                      className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-medium rounded text-xs transition flex items-center space-x-1.5 shadow"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{saving ? "Reconciling..." : "Authorize & Reconcile Ledger"}</span>
                    </button>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-mono">
                    <thead>
                      <tr className="border-b border-navy-800 text-slate-400">
                        <th className="py-1.5 px-2">Field</th>
                        <th className="py-1.5 px-2">ERP Ledger Value</th>
                        <th className="py-1.5 px-2">Extracted Document OCR</th>
                        <th className="py-1.5 px-2">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-navy-900">
                      {selectedInvoice.ocrDiscrepancies.map((disc: any, idx: number) => (
                        <tr key={idx} className={disc.has_conflict ? "bg-amber-500/5" : ""}>
                          <td className="py-2 px-2 text-slate-300 font-medium">{disc.label || disc.field}</td>
                          <td className="py-2 px-2 text-rose-300 font-semibold">{disc.ledger_value || "—"}</td>
                          <td className="py-2 px-2 text-cyan-300 font-semibold">{disc.ocr_value || "—"}</td>
                          <td className="py-2 px-2">
                            {disc.has_conflict ? (
                              <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30">
                                ⚠️ Discrepancy
                              </span>
                            ) : (
                              <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                                ✓ Verified Match
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Editable Form Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
              <div>
                <label className="text-slate-400 block mb-1">Supplier GSTIN</label>
                <input
                  type="text"
                  value={editForm.vendorGSTIN || ""}
                  onChange={(e) => setEditForm({ ...editForm, vendorGSTIN: e.target.value })}
                  className="w-full bg-navy-950 border border-navy-700 rounded px-3 py-1.5 text-white focus:outline-none focus:border-accent-cyan"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">PO Reference</label>
                <input
                  type="text"
                  value={editForm.poReference || ""}
                  onChange={(e) => setEditForm({ ...editForm, poReference: e.target.value })}
                  className="w-full bg-navy-950 border border-navy-700 rounded px-3 py-1.5 text-white focus:outline-none focus:border-accent-cyan"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Invoice Date (YYYY-MM-DD)</label>
                <input
                  type="date"
                  value={editForm.invoiceDate || ""}
                  onChange={(e) => setEditForm({ ...editForm, invoiceDate: e.target.value })}
                  className="w-full bg-navy-950 border border-navy-700 rounded px-3 py-1.5 text-white focus:outline-none focus:border-accent-cyan"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Due Date (YYYY-MM-DD)</label>
                <input
                  type="date"
                  value={editForm.dueDate || ""}
                  onChange={(e) => setEditForm({ ...editForm, dueDate: e.target.value })}
                  className="w-full bg-navy-950 border border-navy-700 rounded px-3 py-1.5 text-white focus:outline-none focus:border-accent-cyan"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Taxable Value (INR)</label>
                <input
                  type="number"
                  step="0.01"
                  value={editForm.taxableValue || 0}
                  onChange={(e) => setEditForm({ ...editForm, taxableValue: e.target.value })}
                  className="w-full bg-navy-950 border border-navy-700 rounded px-3 py-1.5 text-white focus:outline-none focus:border-accent-cyan"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">CGST Amount (INR)</label>
                <input
                  type="number"
                  step="0.01"
                  value={editForm.cgst || 0}
                  onChange={(e) => setEditForm({ ...editForm, cgst: e.target.value })}
                  className="w-full bg-navy-950 border border-navy-700 rounded px-3 py-1.5 text-white focus:outline-none focus:border-accent-cyan"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">SGST Amount (INR)</label>
                <input
                  type="number"
                  step="0.01"
                  value={editForm.sgst || 0}
                  onChange={(e) => setEditForm({ ...editForm, sgst: e.target.value })}
                  className="w-full bg-navy-950 border border-navy-700 rounded px-3 py-1.5 text-white focus:outline-none focus:border-accent-cyan"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">IGST Amount (INR)</label>
                <input
                  type="number"
                  step="0.01"
                  value={editForm.igst || 0}
                  onChange={(e) => setEditForm({ ...editForm, igst: e.target.value })}
                  className="w-full bg-navy-950 border border-navy-700 rounded px-3 py-1.5 text-white focus:outline-none focus:border-accent-cyan"
                />
              </div>

              <div className="md:col-span-2">
                <label className="text-slate-400 block mb-1">Total Invoice Amount (INR)</label>
                <input
                  type="number"
                  step="0.01"
                  value={editForm.totalAmount || 0}
                  onChange={(e) => setEditForm({ ...editForm, totalAmount: e.target.value })}
                  className="w-full bg-navy-950 border border-navy-700 rounded px-3 py-1.5 text-white font-bold focus:outline-none focus:border-accent-cyan"
                />
              </div>
            </div>

            {/* Extracted Line Items Display */}
            <div className="space-y-2">
              <span className="text-xs font-semibold text-white block">Extracted Line Items</span>
              <div className="border border-navy-800 rounded-lg overflow-x-auto max-h-48">
                <table className="w-full text-left text-[11px] font-mono">
                  <thead className="bg-navy-950/80 text-slate-400 border-b border-navy-800">
                    <tr>
                      <th className="py-2 px-2.5">Line</th>
                      <th className="py-2 px-2.5">Item Code</th>
                      <th className="py-2 px-2.5">Description</th>
                      <th className="py-2 px-2.5">Qty</th>
                      <th className="py-2 px-2.5">Unit Price</th>
                      <th className="py-2 px-2.5">Taxable</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-navy-800/50">
                    {(editForm.lineItems || []).map((li: any, i: number) => (
                      <tr key={i} className="hover:bg-navy-800/30">
                        <td className="py-2 px-2.5 text-accent-cyan">{li.lineNumber || i + 1}</td>
                        <td className="py-2 px-2.5 text-white">{li.itemCode}</td>
                        <td className="py-2 px-2.5 text-slate-300 truncate max-w-[180px] font-sans">
                          {li.description}
                        </td>
                        <td className="py-2 px-2.5">{li.quantity}</td>
                        <td className="py-2 px-2.5">{formatINR(li.unitPrice)}</td>
                        <td className="py-2 px-2.5 font-bold text-white">{formatINR(li.taxableAmount)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Validation Feedback */}
            {validationResult && (
              <div
                className={`p-3 rounded-lg border text-xs space-y-1.5 ${
                  validationResult.is_valid
                    ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-300"
                    : "bg-rose-500/10 border-rose-500/30 text-rose-300"
                }`}
              >
                <div className="flex items-center space-x-2 font-semibold">
                  {validationResult.is_valid ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-400" />
                  )}
                  <span>
                    {validationResult.is_valid
                      ? "All Deterministic Arithmetic & GST Invariance Rules Verified!"
                      : "Validation Warnings / Discrepancies Detected:"}
                  </span>
                </div>
                {validationResult.errors && validationResult.errors.length > 0 && (
                  <ul className="list-disc list-inside space-y-0.5 font-mono text-[11px]">
                    {validationResult.errors.map((e: string, i: number) => (
                      <li key={i}>{e}</li>
                    ))}
                  </ul>
                )}
              </div>
            )}

            {/* Modal Actions */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-navy-800">
              <button
                onClick={handleValidateCurrent}
                disabled={validating}
                className="w-full sm:w-auto px-4 py-2 bg-navy-800 hover:bg-navy-700 text-slate-200 border border-navy-700 rounded-lg text-xs font-semibold flex items-center justify-center space-x-2 transition"
              >
                {validating ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <ShieldCheck className="w-3.5 h-3.5 text-accent-cyan" />
                )}
                <span>Run Validation Check</span>
              </button>

              <div className="flex items-center space-x-3 w-full sm:w-auto justify-end">
                <button
                  onClick={() => setSelectedInvoice(null)}
                  className="px-4 py-2 bg-navy-800 hover:bg-navy-700 text-slate-300 border border-navy-700 rounded-lg text-xs font-medium transition"
                >
                  Cancel
                </button>

                <button
                  onClick={handleSaveInvoice}
                  disabled={saving}
                  className="px-4 py-2 bg-accent-blue hover:bg-blue-600 disabled:opacity-50 text-white rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition shadow-lg shadow-accent-blue/20"
                >
                  {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                  <span>Save & Update Invoice</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
