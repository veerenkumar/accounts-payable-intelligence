"use client";

import React, { useState, useEffect } from "react";
import { formatINR } from "@/lib/utils";
import { APIService } from "@/services/api";
import { ExceptionTicket } from "@/types/finance";
import { mockExceptions } from "@/lib/mock-data";
import {
  AlertTriangle,
  CheckCircle,
  ShieldAlert,
  UserCheck,
  MessageSquare,
  Loader2,
  Search,
  Filter,
  ArrowUpDown,
} from "lucide-react";

export default function ExceptionsPage() {
  const [exceptions, setExceptions] = useState<ExceptionTicket[]>(mockExceptions);
  const [loading, setLoading] = useState(true);
  const [resolvingId, setResolvingId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("ALL");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [sortOrder, setSortOrder] = useState<"NEWEST" | "OLDEST">("NEWEST");

  useEffect(() => {
    APIService.getExceptions().then((data) => {
      if (data && data.length > 0) {
        setExceptions(data);
      }
      setLoading(false);
    });
  }, []);

  const handleResolve = async (id: string, action: string) => {
    setResolvingId(id);
    try {
      const res = await APIService.resolveException(
        id,
        action,
        `Resolved via AP Exception Workbench. Adjustment liability credited.`
      );
      setExceptions((prev) =>
        prev.map((e) =>
          e.id === id
            ? { ...e, status: "RESOLVED" }
            : e
        )
      );
    } catch (err) {
      console.error("Failed to resolve exception:", err);
    } finally {
      setResolvingId(null);
    }
  };

  // Filter and Sort Exceptions
  const filteredExceptions = exceptions
    .filter((exc) => {
      const matchesSearch =
        exc.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        exc.invoiceId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        exc.vendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        exc.category.toLowerCase().includes(searchTerm.toLowerCase());

      if (!matchesSearch) return false;

      if (categoryFilter !== "ALL") {
        if (categoryFilter === "MISSING_PO" && exc.category !== "MISSING_PO") return false;
        if (categoryFilter === "PRICE" && !exc.category.includes("PRICE")) return false;
        if (categoryFilter === "QUANTITY" && !exc.category.includes("QUANTITY")) return false;
        if (categoryFilter === "TAX" && !exc.category.includes("TAX")) return false;
        if (categoryFilter === "DUPLICATE" && !exc.category.includes("DUPLICATE")) return false;
      }

      if (statusFilter !== "ALL") {
        if (statusFilter === "OPEN" && exc.status === "RESOLVED") return false;
        if (statusFilter === "RESOLVED" && exc.status !== "RESOLVED") return false;
      }

      return true;
    })
    .sort((a, b) => {
      // Sort newest first by default so freshly created exceptions appear at the top
      if (sortOrder === "NEWEST") {
        return b.id.localeCompare(a.id);
      } else {
        return a.id.localeCompare(b.id);
      }
    });

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono font-semibold text-accent-cyan tracking-wider uppercase">
              Agent 6: Exception Resolution Agent
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-xs text-slate-400">Human-in-the-Loop Investigation Workbench</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            Exception Workbench
          </h1>
        </div>

        <div className="flex items-center space-x-3 text-xs text-slate-400 font-mono">
          {loading && <Loader2 className="w-3.5 h-3.5 animate-spin text-accent-cyan" />}
          <span>
            {exceptions.filter((e) => e.status !== "RESOLVED").length} open exceptions requiring HITL
          </span>
        </div>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="bg-navy-900 border border-navy-800 rounded-xl p-4 space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by Invoice # (e.g. INV-2026-00452), Exception ID or Vendor..."
              className="w-full bg-navy-950 border border-navy-800 pl-9 pr-3 py-1.5 rounded-lg text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-accent-cyan"
            />
          </div>

          <div className="flex items-center space-x-2 text-xs font-mono">
            <button
              onClick={() => setSortOrder(sortOrder === "NEWEST" ? "OLDEST" : "NEWEST")}
              className="flex items-center space-x-1 px-3 py-1.5 rounded-lg border border-navy-800 bg-navy-950 hover:bg-navy-800 text-slate-300 transition"
            >
              <ArrowUpDown className="w-3 h-3 text-accent-cyan" />
              <span>{sortOrder === "NEWEST" ? "Newest First" : "Oldest First"}</span>
            </button>
          </div>
        </div>

        {/* Category & Status Filter Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs font-mono pt-1 border-t border-navy-800/60">
          <span className="text-slate-500 mr-1 text-[11px]">Category:</span>
          {[
            { id: "ALL", label: "All Categories" },
            { id: "MISSING_PO", label: "Missing PO" },
            { id: "PRICE", label: "Price Variance" },
            { id: "QUANTITY", label: "Quantity Discrepancy" },
            { id: "TAX", label: "Tax Discrepancy" },
            { id: "DUPLICATE", label: "Duplicate Alert" },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setCategoryFilter(cat.id)}
              className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition border ${
                categoryFilter === cat.id
                  ? "bg-accent-blue/20 border-accent-blue text-accent-cyan"
                  : "bg-navy-950 border-navy-800 text-slate-400 hover:text-white"
              }`}
            >
              {cat.label}
            </button>
          ))}

          <span className="text-slate-600 mx-2">|</span>

          <span className="text-slate-500 mr-1 text-[11px]">Status:</span>
          {[
            { id: "ALL", label: "All" },
            { id: "OPEN", label: "Open" },
            { id: "RESOLVED", label: "Resolved" },
          ].map((st) => (
            <button
              key={st.id}
              onClick={() => setStatusFilter(st.id)}
              className={`px-2 py-0.5 rounded text-[11px] font-semibold transition ${
                statusFilter === st.id
                  ? "bg-slate-700 text-white"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {st.label}
            </button>
          ))}
        </div>
      </div>

      {/* Exception Cards Grid */}
      <div className="grid grid-cols-1 gap-4">
        {filteredExceptions.map((exc) => (
          <div
            key={exc.id}
            className={`bg-navy-900 border rounded-xl p-6 space-y-4 transition ${
              exc.status === "RESOLVED"
                ? "border-emerald-500/30 opacity-75"
                : "border-navy-800 hover:border-navy-700"
            }`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-navy-800 pb-3">
              <div className="flex items-center space-x-3 flex-wrap gap-y-1">
                <span className="text-sm font-mono font-bold text-accent-cyan">{exc.id}</span>
                <span className="text-xs text-slate-300 font-mono font-semibold">Invoice: {exc.invoiceId}</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-500/20 text-rose-300 font-mono">
                  {exc.category}
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/20 text-amber-300 font-mono">
                  SEVERITY: {exc.severity}
                </span>
                {exc.status === "RESOLVED" && (
                  <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 font-mono">
                    RESOLVED
                  </span>
                )}
              </div>
              <span className="text-xs text-slate-400 font-mono">{exc.createdAt}</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
              <div>
                <span className="text-slate-400 block mb-1">Supplier</span>
                <span className="font-semibold text-white">{exc.vendorName}</span>
              </div>
              <div>
                <span className="text-slate-400 block mb-1">Expected Baseline</span>
                <span className="font-mono text-emerald-400">{exc.expectedValue}</span>
              </div>
              <div>
                <span className="text-slate-400 block mb-1">Actual Invoiced</span>
                <span className="font-mono text-rose-400">{exc.actualValue}</span>
              </div>
              <div>
                <span className="text-slate-400 block mb-1">Financial Impact</span>
                <span className="font-mono font-bold text-white text-sm">
                  {formatINR(exc.financialImpactINR)}
                </span>
              </div>
            </div>

            <div className="bg-navy-950/80 p-3 rounded-lg border border-navy-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="text-slate-300">
                <span className="font-semibold text-accent-cyan">AI Resolution Recommendation:</span>{" "}
                {exc.status === "RESOLVED"
                  ? "Debit note generated. Accounts payable subledger adjusted accordingly."
                  : exc.category === "MISSING_PO"
                  ? "Procurement verification required: Request valid PO reference from supplier or initiate retroactive PO approval."
                  : "Draft vendor debit note for excess amount or route for Purchase Manager price amendment."}
              </div>
              <div className="flex items-center space-x-2 shrink-0">
                {exc.status !== "RESOLVED" ? (
                  resolvingId === exc.id ? (
                    <Loader2 className="w-4 h-4 animate-spin text-accent-cyan" />
                  ) : (
                    <>
                      <button
                        onClick={() => handleResolve(exc.id, "ACCEPT_VARIANCE")}
                        className="px-3 py-1.5 bg-navy-800 hover:bg-navy-700 text-slate-200 rounded font-medium text-xs border border-navy-700 transition"
                      >
                        Accept Variance
                      </button>
                      <button
                        onClick={() => handleResolve(exc.id, "ISSUE_DEBIT_NOTE")}
                        className="px-3 py-1.5 bg-accent-blue hover:bg-blue-600 text-white rounded font-medium text-xs transition"
                      >
                        Issue Debit Note
                      </button>
                    </>
                  )
                ) : (
                  <span className="text-emerald-400 flex items-center space-x-1 font-mono text-[11px]">
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>Resolution Documented</span>
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}

        {filteredExceptions.length === 0 && (
          <div className="p-8 text-center bg-navy-900 border border-navy-800 rounded-xl text-slate-400 font-mono text-xs">
            No exception tickets match the current filter criteria.
          </div>
        )}
      </div>
    </div>
  );
}
