"use client";

import React, { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { APIService } from "@/services/api";
import {
  FolderOpen,
  FileText,
  CheckCircle2,
  UploadCloud,
  Loader2,
  AlertCircle,
  FileCheck,
  Search,
  ExternalLink,
  Eye,
  X,
  FileImage,
  ShieldCheck,
  ArrowRight,
} from "lucide-react";
import { formatINR } from "@/lib/utils";

interface DocItem {
  id: string;
  file_name: string;
  file_size_bytes: number;
  mime_type: string;
  document_type: string;
  ocr_confidence_score?: number;
  uploaded_at: string;
  ocr_raw_text?: string;
  parsed_invoice?: {
    invoice_number?: string;
    invoice_date?: string;
    due_date?: string;
    po_reference?: string;
    vendor_name?: string;
    vendor_gstin?: string;
    recipient_gstin?: string;
    place_of_supply?: string;
    currency?: string;
    taxable_value?: number;
    cgst_amount?: number;
    sgst_amount?: number;
    igst_amount?: number;
    total_tax?: number;
    total_amount?: number;
    line_items?: any[];
    field_confidences?: Record<string, number>;
    overall_confidence?: number;
  };
}

export default function DocumentCenterPage() {
  const [documents, setDocuments] = useState<DocItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<string>("");
  const [uploadResult, setUploadResult] = useState<any | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState<DocItem | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const loadDocuments = () => {
    APIService.getDocuments().then((data) => {
      if (data && data.length > 0) {
        setDocuments(data);
      }
      setLoading(false);
    });
  };

  useEffect(() => {
    loadDocuments();
  }, []);

  const handleProcessFile = async (file: File) => {
    // 1. File Validation
    const validExtensions = [".pdf", ".png", ".jpg", ".jpeg"];
    const ext = "." + file.name.split(".").pop()?.toLowerCase();
    if (!validExtensions.includes(ext)) {
      setUploadError(`Invalid file format '${ext}'. Please upload PDF, JPG, or PNG invoice documents.`);
      return;
    }

    // 2. File Size Validation (10MB)
    if (file.size > 10 * 1024 * 1024) {
      setUploadError(`File size exceeds 10MB limit (${(file.size / (1024 * 1024)).toFixed(1)}MB).`);
      return;
    }

    setUploading(true);
    setUploadProgress("Uploading & extracting OCR text...");
    setUploadResult(null);
    setUploadError(null);

    try {
      setUploadProgress("Running Agent 1 Invoice Intelligence & GST Verification...");
      const result = await APIService.uploadDocument(file);
      setUploadResult(result);
      loadDocuments();
    } catch (err: any) {
      setUploadError(err.message || "Failed to process and ingest document");
    } finally {
      setUploading(false);
      setUploadProgress("");
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleProcessFile(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleProcessFile(file);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono font-semibold text-accent-cyan tracking-wider uppercase">
              Phase 2.1: Document Center & Repository
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-xs text-slate-400">PDF & Image Storage with OCR Telemetry</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            Invoice Ingestion & Document Center
          </h1>
        </div>

        <div className="flex items-center space-x-3">
          <Link
            href="/invoices"
            className="px-4 py-2 bg-navy-800 hover:bg-navy-700 text-slate-200 border border-navy-700 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition"
          >
            <FileText className="w-3.5 h-3.5 text-accent-cyan" />
            <span>Go to Invoices Ledger</span>
          </Link>
        </div>
      </div>

      {/* Hidden File Input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileSelect}
        accept=".pdf,.png,.jpg,.jpeg"
        className="hidden"
      />

      {/* Drag & Drop Upload Zone */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => !uploading && fileInputRef.current?.click()}
        className={`p-8 border-2 border-dashed rounded-xl flex flex-col items-center justify-center text-center space-y-3 cursor-pointer transition ${
          isDragOver
            ? "border-accent-cyan bg-accent-blue/15 scale-[1.01]"
            : "border-navy-700 hover:border-accent-blue/50 bg-navy-900/60 hover:bg-navy-800/40"
        }`}
      >
        <div className="p-3 bg-accent-blue/10 rounded-full text-accent-cyan">
          {uploading ? (
            <Loader2 className="w-8 h-8 animate-spin" />
          ) : (
            <UploadCloud className="w-8 h-8" />
          )}
        </div>
        <div>
          <div className="text-sm font-semibold text-white">
            {uploading ? uploadProgress : "Upload Supplier Invoices (PDF, PNG, JPG)"}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            {uploading
              ? "Deterministic GST arithmetic verification in progress..."
              : "Drag & drop file here or click to browse (Max 10MB • Preserves original file integrity)"}
          </div>
        </div>
      </div>

      {/* Extraction & Ingestion Result Card */}
      {uploadResult && (
        <div
          className={`bg-navy-900 border rounded-xl p-5 space-y-4 ${
            uploadResult.is_valid
              ? "border-emerald-500/40 shadow-lg shadow-emerald-500/5"
              : "border-amber-500/40 shadow-lg shadow-amber-500/5"
          }`}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-navy-800 pb-3">
            <div className="flex items-center space-x-2">
              {uploadResult.is_valid ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              ) : (
                <AlertCircle className="w-5 h-5 text-amber-400" />
              )}
              <span className="font-semibold text-white text-sm">
                {uploadResult.is_valid
                  ? "Invoice Ingested & Verified Successfully"
                  : `Ingested with Flag: ${uploadResult.workflow_status}`}
              </span>
            </div>
            {uploadResult.invoice_id && (
              <Link
                href="/invoices"
                className="px-3 py-1 bg-accent-blue/20 hover:bg-accent-blue/30 text-accent-cyan border border-accent-blue/40 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition self-start sm:self-auto"
              >
                <span>Review Invoices Ledger</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono bg-navy-950/80 p-3.5 rounded-lg border border-navy-800">
            <div>
              <span className="text-slate-400 block mb-0.5">File Name</span>
              <span className="text-white font-medium truncate block">{uploadResult.file_name}</span>
            </div>
            <div>
              <span className="text-slate-400 block mb-0.5">Extracted Invoice</span>
              <span className="text-accent-cyan font-bold">{uploadResult.invoice_id || "Unassigned"}</span>
            </div>
            <div>
              <span className="text-slate-400 block mb-0.5">Extraction Confidence</span>
              <span className="text-emerald-400 font-bold">
                {(uploadResult.extraction_confidence * 100).toFixed(1)}%
              </span>
            </div>
            <div>
              <span className="text-slate-400 block mb-0.5">Workflow Status</span>
              <span
                className={`font-bold px-2 py-0.5 rounded text-[11px] ${
                  uploadResult.workflow_status === "INGESTED"
                    ? "bg-emerald-500/20 text-emerald-300"
                    : "bg-amber-500/20 text-amber-300"
                }`}
              >
                {uploadResult.workflow_status}
              </span>
            </div>
          </div>

          {/* Validation Warnings/Errors */}
          {uploadResult.validation_errors && uploadResult.validation_errors.length > 0 && (
            <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-xs text-rose-300 space-y-1">
              <span className="font-semibold block">Validation Errors:</span>
              <ul className="list-disc list-inside space-y-0.5 font-mono text-[11px]">
                {uploadResult.validation_errors.map((err: string, i: number) => (
                  <li key={i}>{err}</li>
                ))}
              </ul>
            </div>
          )}

          {uploadResult.ocr_preview && (
            <div className="text-xs text-slate-300 font-mono bg-navy-950/40 p-2.5 rounded border border-navy-800/60 truncate">
              <span className="text-slate-400 font-sans">OCR Snippet:</span> {uploadResult.ocr_preview}
            </div>
          )}
        </div>
      )}

      {uploadError && (
        <div className="bg-rose-500/10 border border-rose-500/40 rounded-xl p-4 flex items-center space-x-2 text-rose-300 text-xs">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{uploadError}</span>
        </div>
      )}

      {/* Document Ingestion Repository */}
      <div className="bg-navy-900 border border-navy-800 rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-white">Document Repository Ledger</h2>
          <span className="text-xs font-mono text-slate-400">
            {documents.length} ingested document{documents.length !== 1 ? "s" : ""}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-navy-950/60 text-slate-400 uppercase text-[10px] tracking-wider border-b border-navy-800">
              <tr>
                <th className="py-2.5 px-3">Document ID</th>
                <th className="py-2.5 px-3 font-sans">File Name</th>
                <th className="py-2.5 px-3">Size</th>
                <th className="py-2.5 px-3">MIME Type</th>
                <th className="py-2.5 px-3">OCR Confidence</th>
                <th className="py-2.5 px-3">Uploaded Date</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-navy-800/60">
              {documents.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-6 text-center text-slate-400 font-sans">
                    No documents uploaded yet. Upload a supplier invoice above.
                  </td>
                </tr>
              ) : (
                documents.map((doc) => (
                  <tr key={doc.id} className="hover:bg-navy-800/40 transition">
                    <td className="py-3 px-3 font-bold text-accent-cyan truncate max-w-[120px]">
                      {doc.id.substring(0, 8)}...
                    </td>
                    <td className="py-3 px-3 font-sans text-slate-200 font-medium">
                      <div className="flex items-center space-x-2">
                        {doc.mime_type.includes("pdf") ? (
                          <FileText className="w-4 h-4 text-accent-cyan shrink-0" />
                        ) : (
                          <FileImage className="w-4 h-4 text-accent-amber shrink-0" />
                        )}
                        <span className="truncate max-w-[200px]">{doc.file_name}</span>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-slate-400">
                      {(doc.file_size_bytes / 1024).toFixed(1)} KB
                    </td>
                    <td className="py-3 px-3 text-slate-400">{doc.mime_type}</td>
                    <td className="py-3 px-3">
                      <span
                        className={`font-bold ${
                          Number(doc.ocr_confidence_score || 0.95) >= 0.85
                            ? "text-emerald-400"
                            : "text-amber-400"
                        }`}
                      >
                        {((doc.ocr_confidence_score ? Number(doc.ocr_confidence_score) : 0.95) * 100).toFixed(1)}%
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-400">
                      {doc.uploaded_at ? doc.uploaded_at.substring(0, 16) : "Just now"}
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => setSelectedDoc(doc)}
                        className="px-2.5 py-1 bg-navy-800 hover:bg-navy-700 text-slate-200 border border-navy-700 rounded text-xs transition inline-flex items-center space-x-1"
                      >
                        <Eye className="w-3 h-3 text-accent-cyan" />
                        <span>Inspect</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Document Inspector Modal */}
      {selectedDoc && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-navy-900 border border-navy-800 rounded-2xl max-w-3xl w-full p-6 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-navy-800 pb-3">
              <div className="flex items-center space-x-2">
                <FileCheck className="w-5 h-5 text-accent-cyan" />
                <h3 className="font-semibold text-white text-base truncate max-w-md">
                  {selectedDoc.file_name}
                </h3>
              </div>
              <button
                onClick={() => setSelectedDoc(null)}
                className="p-1 rounded-lg hover:bg-navy-800 text-slate-400 hover:text-white transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Document Metadata Strip */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono bg-navy-950/80 p-3 rounded-lg border border-navy-800">
              <div>
                <span className="text-slate-400 block">Document ID</span>
                <span className="text-white font-medium truncate block">{selectedDoc.id.substring(0, 8)}...</span>
              </div>
              <div>
                <span className="text-slate-400 block">File Size</span>
                <span className="text-white font-medium">{(selectedDoc.file_size_bytes / 1024).toFixed(1)} KB</span>
              </div>
              <div>
                <span className="text-slate-400 block">Format</span>
                <span className="text-white font-medium">{selectedDoc.mime_type}</span>
              </div>
              <div>
                <span className="text-slate-400 block">OCR Confidence</span>
                <span
                  className={`font-bold ${
                    Number(selectedDoc.ocr_confidence_score || 0.95) >= 0.85
                      ? "text-emerald-400"
                      : "text-amber-400"
                  }`}
                >
                  {((selectedDoc.ocr_confidence_score ? Number(selectedDoc.ocr_confidence_score) : 0.95) * 100).toFixed(1)}%
                </span>
              </div>
            </div>

            {/* Structured Extracted Invoice Attributes */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-white flex items-center space-x-1.5">
                  <ShieldCheck className="w-4 h-4 text-accent-cyan" />
                  <span>Agent 1 Structured Financial Attributes</span>
                </span>
                <span className="text-[10px] font-mono text-slate-400">
                  {selectedDoc.parsed_invoice?.invoice_number ? "Extraction Verified" : "Awaiting Verification"}
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs font-mono bg-navy-950 p-3.5 rounded-lg border border-navy-800">
                <div className="space-y-0.5">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Invoice Number</span>
                  <span className="font-bold text-white">
                    {selectedDoc.parsed_invoice?.invoice_number || (
                      <span className="text-amber-400 font-sans italic text-[11px]">Not detected</span>
                    )}
                  </span>
                </div>
                <div className="space-y-0.5">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Supplier Name</span>
                  <span className="font-semibold text-slate-200 truncate block">
                    {selectedDoc.parsed_invoice?.vendor_name || (
                      <span className="text-amber-400 font-sans italic text-[11px]">Not detected</span>
                    )}
                  </span>
                </div>
                <div className="space-y-0.5">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Supplier GSTIN</span>
                  <span className="font-bold text-accent-cyan">
                    {selectedDoc.parsed_invoice?.vendor_gstin || (
                      <span className="text-amber-400 font-sans italic text-[11px]">Not detected</span>
                    )}
                  </span>
                </div>
                <div className="space-y-0.5">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Invoice Date</span>
                  <span className="text-white">
                    {selectedDoc.parsed_invoice?.invoice_date || (
                      <span className="text-amber-400 font-sans italic text-[11px]">Not detected</span>
                    )}
                  </span>
                </div>
                <div className="space-y-0.5">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">PO Reference</span>
                  <span className="text-white">
                    {selectedDoc.parsed_invoice?.po_reference || (
                      <span className="text-amber-400 font-sans italic text-[11px]">Not detected</span>
                    )}
                  </span>
                </div>
                <div className="space-y-0.5">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Taxable Amount</span>
                  <span className="font-bold text-white">
                    {selectedDoc.parsed_invoice?.taxable_value !== undefined
                      ? formatINR(selectedDoc.parsed_invoice.taxable_value)
                      : "—"}
                  </span>
                </div>
                <div className="space-y-0.5">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">CGST + SGST</span>
                  <span className="text-slate-300">
                    {formatINR((selectedDoc.parsed_invoice?.cgst_amount || 0) + (selectedDoc.parsed_invoice?.sgst_amount || 0))}
                  </span>
                </div>
                <div className="space-y-0.5">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">IGST Amount</span>
                  <span className="text-slate-300">
                    {formatINR(selectedDoc.parsed_invoice?.igst_amount || 0)}
                  </span>
                </div>
                <div className="space-y-0.5">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Total Amount</span>
                  <span className="font-bold text-emerald-400 text-sm">
                    {selectedDoc.parsed_invoice?.total_amount !== undefined
                      ? formatINR(selectedDoc.parsed_invoice.total_amount)
                      : "—"}
                  </span>
                </div>
              </div>
            </div>

            {/* Extracted Raw OCR Text Stream */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-semibold text-white">
                  Extracted Raw OCR Text Stream
                </span>
                <span className="text-[10px] font-mono text-slate-400">
                  {selectedDoc.ocr_raw_text ? `${selectedDoc.ocr_raw_text.length} characters extracted` : "0 characters"}
                </span>
              </div>
              <pre className="bg-navy-950 p-4 rounded-lg border border-navy-800 text-[11px] font-mono text-slate-300 max-h-48 overflow-y-auto whitespace-pre-wrap selection:bg-accent-blue selection:text-white">
                {selectedDoc.ocr_raw_text || "No raw text stream recorded for this artifact. If this is a scanned document without embedded text, optical character recognition pre-processing is required."}
              </pre>
            </div>

            <div className="flex justify-end space-x-3 pt-2">
              <button
                onClick={() => setSelectedDoc(null)}
                className="px-4 py-2 bg-navy-800 hover:bg-navy-700 text-slate-200 border border-navy-700 rounded-lg text-xs font-medium transition"
              >
                Close
              </button>
              <Link
                href="/invoices"
                className="px-4 py-2 bg-accent-blue hover:bg-blue-600 text-white rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition"
              >
                <span>View Invoices Ledger</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
