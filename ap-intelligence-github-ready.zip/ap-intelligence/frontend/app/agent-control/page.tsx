"use client";

import React from "react";
import { Cpu, Activity, Clock, ShieldCheck, CheckCircle2 } from "lucide-react";

const mockAgents = [
  { id: 1, name: "Invoice Intelligence Agent", status: "HEALTHY", latencyMs: 340, tokens: 420 },
  { id: 2, name: "Purchase Order Analysis Agent", status: "HEALTHY", latencyMs: 120, tokens: 180 },
  { id: 3, name: "Goods Receipt Verification Agent", status: "HEALTHY", latencyMs: 140, tokens: 190 },
  { id: 4, name: "Three-Way Matching Agent (Deterministic)", status: "ACTIVE", latencyMs: 45, tokens: 0 },
  { id: 5, name: "Fraud & Duplicate Detection Agent", status: "HEALTHY", latencyMs: 210, tokens: 280 },
  { id: 6, name: "Exception Resolution Agent", status: "HEALTHY", latencyMs: 380, tokens: 510 },
  { id: 7, name: "Approval Management Agent", status: "HEALTHY", latencyMs: 110, tokens: 160 },
  { id: 8, name: "Finance Analytics Agent", status: "HEALTHY", latencyMs: 290, tokens: 430 },
];

export default function AgentControlPage() {
  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center space-x-2">
          <span className="text-xs font-mono font-semibold text-accent-cyan tracking-wider uppercase">
            Supervisor-Worker Multi-Agent Orchestrator
          </span>
          <span className="text-slate-600">•</span>
          <span className="text-xs text-slate-400">LangGraph Telemetry & Health Status</span>
        </div>
        <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
          AI Agent Control Center
        </h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {mockAgents.map((ag) => (
          <div key={ag.id} className="bg-navy-900 border border-navy-800 rounded-xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Agent #{ag.id}</span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded font-mono font-bold">
                {ag.status}
              </span>
            </div>
            <div className="text-sm font-semibold text-white">{ag.name}</div>
            <div className="text-xs font-mono text-slate-400 flex items-center justify-between pt-1 border-t border-navy-800">
              <span>Latency: {ag.latencyMs}ms</span>
              <span>Tokens: {ag.tokens}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

