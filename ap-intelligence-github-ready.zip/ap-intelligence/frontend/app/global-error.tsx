"use client";

import React from "react";
import { AlertTriangle, RefreshCw } from "lucide-react";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html lang="en" className="dark">
      <body className="bg-navy-950 text-slate-100 min-h-screen flex items-center justify-center p-6 font-sans">
        <div className="max-w-md w-full p-8 bg-navy-900 border border-navy-800 rounded-2xl text-center space-y-4 shadow-2xl">
          <div className="w-12 h-12 mx-auto bg-rose-500/10 border border-rose-500/30 rounded-xl flex items-center justify-center text-rose-400">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            System Error Intercepted
          </h2>
          <p className="text-xs text-slate-400">
            A fatal UI rendering fault was caught by AP Intelligence. Press below to restore the application runtime.
          </p>
          <button
            onClick={() => reset()}
            className="w-full py-2.5 bg-accent-blue hover:bg-blue-600 text-white rounded-lg text-xs font-semibold flex items-center justify-center space-x-2 transition"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Reload AP Intelligence</span>
          </button>
        </div>
      </body>
    </html>
  );
}

