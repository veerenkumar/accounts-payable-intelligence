"use client";

import React, { useState, useEffect } from "react";
import { formatINR } from "@/lib/utils";
import { APIService } from "@/services/api";
import { FileSpreadsheet, Search, Loader2 } from "lucide-react";

interface POData {
  id: string;
  vendor_id?: string;
  vendorName?: string;
  po_date?: string;
  delivery_due_date?: string;
  total_amount_inr?: number;
  totalAmount?: number;
  status: string;
  payment_terms?: string;
}

const fallbackPOs = [
  {
    id: "PO-2026-00101",
    vendor_id: "VEND-001",
    po_date: "2026-10-03",
    total_amount_inr: 246620,
    status: "FULFILLED",
  },
  {
    id: "PO-2026-00104",
    vendor_id: "VEND-004",
    po_date: "2026-10-09",
    total_amount_inr: 92040,
    status: "PARTIALLY_FULFILLED",
  },
  {
    id: "PO-2026-00108",
    vendor_id: "VEND-008",
    po_date: "2026-10-17",
    total_amount_inr: 566400,
    status: "FULFILLED",
  },
];

export default function PurchaseOrdersPage() {
  const [pos, setPOs] = useState<POData[]>(fallbackPOs);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    APIService.getPurchaseOrders().then((data) => {
      if (data && data.length > 0) {
        setPOs(data);
      }
      setLoading(false);
    });
  }, []);

  const filtered = pos.filter(
    (p) =>
      p.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.vendor_id && p.vendor_id.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono font-semibold text-accent-cyan tracking-wider uppercase">
              Agent 2: Purchase Order Analysis
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-xs text-slate-400">Budgeted Commitments & Master Terms</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            Purchase Orders
          </h1>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-navy-900 border border-navy-800 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-96">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search PO number or vendor..."
            className="w-full bg-navy-950/80 border border-navy-700/80 rounded-lg pl-9 pr-4 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-accent-blue/60 transition"
          />
        </div>

        <div className="flex items-center space-x-3 text-xs text-slate-400 font-mono">
          {loading && <Loader2 className="w-3.5 h-3.5 animate-spin text-accent-cyan" />}
          <span>Showing {filtered.length} purchase orders</span>
        </div>
      </div>

      <div className="bg-navy-900 border border-navy-800 rounded-xl p-6 space-y-4">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-navy-950/60 text-slate-400 uppercase text-[10px] tracking-wider border-b border-navy-800">
              <tr>
                <th className="py-2.5 px-3">PO Number</th>
                <th className="py-2.5 px-3 font-sans">Vendor Code</th>
                <th className="py-2.5 px-3">PO Date</th>
                <th className="py-2.5 px-3">Total (INR)</th>
                <th className="py-2.5 px-3">Terms</th>
                <th className="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-navy-800/60">
              {filtered.map((po) => (
                <tr key={po.id} className="hover:bg-navy-800/40 transition">
                  <td className="py-3 px-3 font-bold text-accent-cyan">{po.id}</td>
                  <td className="py-3 px-3 font-sans text-slate-200">{po.vendor_id || "Supplier"}</td>
                  <td className="py-3 px-3 text-slate-400">{po.po_date || "2026-10-15"}</td>
                  <td className="py-3 px-3 font-bold text-white">
                    {formatINR(Number(po.total_amount_inr || po.totalAmount || 0))}
                  </td>
                  <td className="py-3 px-3 text-slate-300">{po.payment_terms || "Net 30"}</td>
                  <td className="py-3 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        po.status === "FULFILLED"
                          ? "bg-emerald-500/20 text-emerald-400"
                          : "bg-amber-500/20 text-amber-400"
                      }`}
                    >
                      {po.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

