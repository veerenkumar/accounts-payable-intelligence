"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { formatINR } from "@/lib/utils";
import { APIService } from "@/services/api";
import { ApprovalItem } from "@/types/finance";
import { mockApprovals } from "@/lib/mock-data";
import { StatusBadge } from "@/components/ui/StatusBadge";
import {
  CheckCircle2,
  XCircle,
  PauseCircle,
  Shield,
  Loader2,
  AlertOctagon,
  AlertTriangle,
  Search,
  ArrowUpDown,
  Filter,
  X,
  ExternalLink,
} from "lucide-react";

export default function ApprovalsPage() {
  const [approvals, setApprovals] = useState<ApprovalItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [sortOrder, setSortOrder] = useState<"NEWEST" | "OLDEST" | "AMOUNT_DESC" | "AMOUNT_ASC">("NEWEST");
  const [actionInProgress, setActionInProgress] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Sync search query from URL parameter if present
  useEffect(() => {
    if (typeof window !== "undefined") {
      const q = new URLSearchParams(window.location.search).get("search");
      if (q) {
        setSearchTerm(q);
      }
    }
  }, []);

  // Listen for global search events from TopNavigation
  useEffect(() => {
    const handleGlobalSearch = (e: any) => {
      if (typeof e.detail === "string") {
        setSearchTerm(e.detail);
      }
    };
    if (typeof window !== "undefined") {
      window.addEventListener("ap-global-search", handleGlobalSearch);
    }
    return () => {
      if (typeof window !== "undefined") {
        window.removeEventListener("ap-global-search", handleGlobalSearch);
      }
    };
  }, []);

  const loadApprovals = () => {
    setLoading(true);
    APIService.getApprovals().then((data) => {
      if (data && data.length > 0) {
        setApprovals(data);
      } else {
        setApprovals(mockApprovals);
      }
      setLoading(false);
    });
  };

  useEffect(() => {
    loadApprovals();
  }, []);

  const handleAction = async (id: string, action: "APPROVED" | "REJECTED" | "HELD") => {
    setActionInProgress(id);
    setErrorMessage(null);
    try {
      const res = await APIService.submitApprovalAction(
        id,
        action,
        `Authorization decision recorded in AP Intelligence by authenticated executive.`
      );
      if (res && res.detail) {
        setErrorMessage(res.detail);
      } else {
        setApprovals((prev) =>
          prev.map((item) => (item.id === id ? { ...item, status: action } : item))
        );
      }
    } catch (err: any) {
      console.error("Failed to submit approval action:", err);
      setErrorMessage(err.message || "Failed to submit approval action.");
    } finally {
      setActionInProgress(null);
    }
  };

  const isBlockedFromApproval = (appr: ApprovalItem) => {
    const blockingStatuses = [
      "MISSING_PO",
      "MISSING_GRN",
      "DUPLICATE_INVOICE",
      "QUANTITY_MISMATCH",
      "PRICE_MISMATCH",
      "TAX_MISMATCH",
      "ITEM_MISMATCH",
      "VENDOR_MISMATCH",
      "REQUIRES_HUMAN_REVIEW",
    ];
    return (
      (appr.blockingExceptionsCount || 0) > 0 ||
      blockingStatuses.includes(appr.matchStatus) ||
      appr.status === "HELD"
    );
  };

  // Filter and sort approvals
  const filteredApprovals = approvals
    .filter((appr) => {
      // 1. Search Query Filter: checks invoice ID, approval ID, and supplier name
      if (searchTerm.trim()) {
        const query = searchTerm.trim().toLowerCase();
        const matchesInvoice = appr.invoiceId.toLowerCase().includes(query);
        const matchesApproval = appr.id.toLowerCase().includes(query);
        const matchesVendor = (appr.vendorName || "").toLowerCase().includes(query);
        if (!matchesInvoice && !matchesApproval && !matchesVendor) {
          return false;
        }
      }

      // 2. Decision Status Filter
      if (statusFilter !== "ALL") {
        if (appr.status !== statusFilter) {
          return false;
        }
      }

      return true;
    })
    .sort((a, b) => {
      if (sortOrder === "AMOUNT_DESC") {
        return b.amountINR - a.amountINR;
      }
      if (sortOrder === "AMOUNT_ASC") {
        return a.amountINR - b.amountINR;
      }
      if (sortOrder === "OLDEST") {
        return (a.submittedAt || "").localeCompare(b.submittedAt || "");
      }
      // Default: NEWEST
      return (b.submittedAt || "").localeCompare(a.submittedAt || "");
    });

  const pendingCount = approvals.filter((a) => a.status === "PENDING" && !isBlockedFromApproval(a)).length;
  const heldCount = approvals.filter((a) => a.status === "HELD" || isBlockedFromApproval(a)).length;
  const approvedCount = approvals.filter((a) => a.status === "APPROVED").length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono font-semibold text-accent-cyan tracking-wider uppercase">
              Agent 7: Approval Management Agent
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-xs text-slate-400">Tiered Monetary Delegation of Authority</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            Approval Center
          </h1>
        </div>

        <div className="flex items-center space-x-3 text-xs text-slate-400 font-mono">
          {loading && <Loader2 className="w-3.5 h-3.5 animate-spin text-accent-cyan" />}
          <span>{pendingCount} eligible for sign-off</span>
          <span className="text-slate-600">•</span>
          <span className="text-rose-400">{heldCount} on exception hold</span>
        </div>
      </div>

      {/* KPI Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-navy-900 border border-navy-800 rounded-xl p-4">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Total Approvals</div>
          <div className="text-2xl font-bold text-white mt-1 font-mono">{approvals.length}</div>
        </div>
        <div className="bg-navy-900 border border-navy-800 rounded-xl p-4">
          <div className="text-[11px] font-mono text-emerald-400 uppercase tracking-wider">Eligible Pending</div>
          <div className="text-2xl font-bold text-emerald-300 mt-1 font-mono">{pendingCount}</div>
        </div>
        <div className="bg-navy-900 border border-navy-800 rounded-xl p-4">
          <div className="text-[11px] font-mono text-rose-400 uppercase tracking-wider">Exception Holds</div>
          <div className="text-2xl font-bold text-rose-300 mt-1 font-mono">{heldCount}</div>
        </div>
        <div className="bg-navy-900 border border-navy-800 rounded-xl p-4">
          <div className="text-[11px] font-mono text-accent-cyan uppercase tracking-wider">Approved</div>
          <div className="text-2xl font-bold text-accent-cyan mt-1 font-mono">{approvedCount}</div>
        </div>
      </div>

      {/* Financial Policy Violation Alert Banner */}
      {errorMessage && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs font-mono flex items-start space-x-3">
          <AlertOctagon className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
          <div className="space-y-1">
            <div className="font-bold">Approval Blocked by Financial Control Policy:</div>
            <div>{errorMessage}</div>
          </div>
        </div>
      )}

      {/* Search & Filter Toolbar */}
      <div className="bg-navy-900 border border-navy-800 rounded-xl p-4 space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* Search Input */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by Invoice # (e.g. INV-2026-00452), Approval ID, or Supplier..."
              className="w-full bg-navy-950 border border-navy-800 pl-9 pr-8 py-1.5 rounded-lg text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-accent-cyan"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm("")}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                title="Clear search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Filters & Sorting */}
          <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
            {/* Status Filter */}
            <div className="flex items-center space-x-1 bg-navy-950 border border-navy-800 rounded-lg p-0.5">
              {["ALL", "PENDING", "HELD", "APPROVED", "REJECTED"].map((st) => (
                <button
                  key={st}
                  onClick={() => setStatusFilter(st)}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition ${
                    statusFilter === st
                      ? "bg-accent-blue text-white"
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>

            {/* Sort Dropdown */}
            <select
              value={sortOrder}
              onChange={(e: any) => setSortOrder(e.target.value)}
              className="bg-navy-950 border border-navy-800 text-slate-300 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-accent-cyan"
            >
              <option value="NEWEST">Newest First</option>
              <option value="OLDEST">Oldest First</option>
              <option value="AMOUNT_DESC">Highest Amount</option>
              <option value="AMOUNT_ASC">Lowest Amount</option>
            </select>
          </div>
        </div>

        {/* Results Counter / Active Filter Bar */}
        {(searchTerm || statusFilter !== "ALL") && (
          <div className="flex items-center justify-between text-xs text-slate-400 font-mono pt-2 border-t border-navy-800/60">
            <span>
              Showing {filteredApprovals.length} of {approvals.length} approvals
              {searchTerm && (
                <> matching &ldquo;<span className="text-accent-cyan">{searchTerm}</span>&rdquo;</>
              )}
              {statusFilter !== "ALL" && (
                <> with decision &ldquo;<span className="text-white">{statusFilter}</span>&rdquo;</>
              )}
            </span>
            <button
              onClick={() => {
                setSearchTerm("");
                setStatusFilter("ALL");
              }}
              className="text-accent-cyan hover:underline text-[11px]"
            >
              Reset all filters
            </button>
          </div>
        )}
      </div>

      {/* Approvals Table */}
      <div className="bg-navy-900 border border-navy-800 rounded-xl p-6 space-y-4">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-navy-950/60 text-slate-400 uppercase text-[10px] tracking-wider border-b border-navy-800">
              <tr>
                <th className="py-2.5 px-3">Approval ID</th>
                <th className="py-2.5 px-3">Invoice #</th>
                <th className="py-2.5 px-3 font-sans">Supplier</th>
                <th className="py-2.5 px-3">Amount (INR)</th>
                <th className="py-2.5 px-3">Required Tier</th>
                <th className="py-2.5 px-3">Match Status</th>
                <th className="py-2.5 px-3">Decision</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-navy-800/60">
              {filteredApprovals.map((appr) => {
                const blocked = isBlockedFromApproval(appr);
                return (
                  <tr key={appr.id} className="hover:bg-navy-800/40 transition">
                    <td className="py-3 px-3 font-bold text-accent-cyan">{appr.id}</td>
                    <td className="py-3 px-3 text-white font-semibold">{appr.invoiceId}</td>
                    <td className="py-3 px-3 font-sans text-slate-200">{appr.vendorName}</td>
                    <td className="py-3 px-3 font-bold text-white">{formatINR(appr.amountINR)}</td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-navy-800 text-slate-300 border border-navy-700">
                        {appr.requiredRole}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <StatusBadge status={appr.matchStatus} size="sm" />
                    </td>
                    <td className="py-3 px-3">
                      <StatusBadge status={appr.status} size="sm" />
                    </td>
                    <td className="py-3 px-3 text-right">
                      {appr.status === "PENDING" && !blocked ? (
                        <div className="flex items-center justify-end space-x-2">
                          {actionInProgress === appr.id ? (
                            <Loader2 className="w-4 h-4 animate-spin text-accent-cyan" />
                          ) : (
                            <>
                              <button
                                onClick={() => handleAction(appr.id, "APPROVED")}
                                className="px-2.5 py-1 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 rounded text-xs transition"
                              >
                                Approve
                              </button>
                              <button
                                onClick={() => handleAction(appr.id, "HELD")}
                                className="px-2.5 py-1 bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/40 rounded text-xs transition"
                              >
                                Hold
                              </button>
                              <button
                                onClick={() => handleAction(appr.id, "REJECTED")}
                                className="px-2.5 py-1 bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/40 rounded text-xs transition"
                              >
                                Reject
                              </button>
                            </>
                          )}
                        </div>
                      ) : blocked ? (
                        <div className="flex flex-col items-end space-y-1">
                          <span
                            title="Approval prohibited: Invoice has active blocking exceptions"
                            className="px-2.5 py-1 bg-rose-500/10 text-rose-400 border border-rose-500/20 rounded text-[10px] font-semibold flex items-center space-x-1 cursor-not-allowed"
                          >
                            <AlertTriangle className="w-3 h-3 shrink-0" />
                            <span>Exception Hold</span>
                          </span>
                          <Link
                            href={`/exceptions?search=${encodeURIComponent(appr.invoiceId)}`}
                            className="text-[10px] text-accent-cyan hover:underline flex items-center space-x-1"
                          >
                            <span>View in Exception Workbench &rarr;</span>
                          </Link>
                        </div>
                      ) : (
                        <span className="text-[11px] text-slate-400 font-sans">
                          Decision logged ({appr.status})
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {/* Empty State when no results match */}
          {filteredApprovals.length === 0 && !loading && (
            <div className="py-12 text-center space-y-3">
              <div className="w-10 h-10 rounded-full bg-navy-800 text-slate-400 mx-auto flex items-center justify-center">
                <Search className="w-5 h-5 text-accent-cyan" />
              </div>
              <div className="text-sm font-semibold text-white">No matching approvals found</div>
              <div className="text-xs text-slate-400 max-w-sm mx-auto">
                No approval requests match &ldquo;{searchTerm}&rdquo;. Try clearing your search filter or checking the{" "}
                <Link href="/invoices" className="text-accent-cyan hover:underline">Invoice Ledger</Link> or{" "}
                <Link href="/exceptions" className="text-accent-cyan hover:underline">Exception Workbench</Link>.
              </div>
              <button
                onClick={() => {
                  setSearchTerm("");
                  setStatusFilter("ALL");
                }}
                className="mt-2 px-3 py-1.5 bg-navy-800 hover:bg-navy-700 text-accent-cyan border border-navy-700 rounded-lg text-xs transition"
              >
                Clear Search &amp; Filters
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
