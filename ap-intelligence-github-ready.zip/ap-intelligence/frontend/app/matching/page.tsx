"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { formatINR } from "@/lib/utils";
import { APIService } from "@/services/api";
import { Invoice, MatchStatus } from "@/types/finance";
import { StatusBadge } from "@/components/ui/StatusBadge";
import {
  GitCompare,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Boxes,
  Truck,
  Receipt,
  Search,
  Filter,
  RefreshCw,
  Sliders,
  ArrowRight,
  Loader2,
  AlertOctagon,
  Layers,
} from "lucide-react";

export default function MatchingPage() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string>("");
  const [triangulation, setTriangulation] = useState<any | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [evaluating, setEvaluating] = useState<boolean>(false);
  const [batchEvaluating, setBatchEvaluating] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [filterTab, setFilterTab] = useState<string>("ALL");
  const [evaluationFeedback, setEvaluationFeedback] = useState<{
    type: "SUCCESS" | "EXCEPTION";
    message: string;
  } | null>(null);

  // Configurable Master Tolerances
  const [priceTolerance, setPriceTolerance] = useState<number>(2.0);
  const [taxTolerance, setTaxTolerance] = useState<number>(5.0);
  const [qtyTolerance, setQtyTolerance] = useState<number>(0.0);

  // Load Invoices Ledger
  const loadInvoices = async () => {
    try {
      const data = await APIService.getInvoices();
      if (data && data.length > 0) {
        setInvoices(data);
        if (!selectedInvoiceId) {
          setSelectedInvoiceId(data[0].id);
        }
      }
    } catch (err) {
      console.error("Failed to load invoices:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadInvoices();
  }, []);

  // Fetch Triangulation Details when Selected Invoice Changes
  useEffect(() => {
    if (!selectedInvoiceId) return;

    let isSubscribed = true;
    APIService.getTriangulationDetail(selectedInvoiceId).then((data) => {
      if (isSubscribed && data) {
        setTriangulation(data);
      }
    });

    return () => {
      isSubscribed = false;
    };
  }, [selectedInvoiceId]);

  // Execute Deterministic 3-Way Match
  const handleRunMatch = async () => {
    if (!selectedInvoiceId) return;
    setEvaluating(true);
    setEvaluationFeedback(null);

    try {
      const res = await APIService.evaluateMatching(selectedInvoiceId, {
        price_tolerance_pct: priceTolerance,
        qty_tolerance_pct: qtyTolerance,
        tax_tolerance_inr: taxTolerance,
        classify_partial_receipt: true,
      });

      // Reload triangulation detail and update invoice in list
      const freshTriangulation = await APIService.getTriangulationDetail(selectedInvoiceId);
      setTriangulation(freshTriangulation);

      setInvoices((prev) =>
        prev.map((inv) =>
          inv.id === selectedInvoiceId
            ? { ...inv, matchStatus: res.match_status as MatchStatus }
            : inv
        )
      );

      if (res.is_matched) {
        setEvaluationFeedback({
          type: "SUCCESS",
          message: `Reconciliation Verified: ${res.match_status.replace(/_/g, " ")}. Routed to Human Approvals Queue.`,
        });
      } else {
        setEvaluationFeedback({
          type: "EXCEPTION",
          message: `Discrepancy Exception: ${res.match_status.replace(/_/g, " ")}. Financial impact: ${formatINR(res.total_financial_impact_inr)}. Routed to Exception Workbench.`,
        });
      }
    } catch (err: any) {
      console.error("Matching evaluation error:", err);
      setEvaluationFeedback({
        type: "EXCEPTION",
        message: err.message || "Failed to evaluate matching.",
      });
    } finally {
      setEvaluating(false);
    }
  };

  // Run Batch Evaluation
  const handleBatchEvaluate = async () => {
    setBatchEvaluating(true);
    try {
      await APIService.evaluateAllMatching();
      await loadInvoices();
      if (selectedInvoiceId) {
        const fresh = await APIService.getTriangulationDetail(selectedInvoiceId);
        setTriangulation(fresh);
      }
    } catch (err) {
      console.error("Batch evaluate error:", err);
    } finally {
      setBatchEvaluating(false);
    }
  };

  // Filtered Invoices List
  const filteredInvoices = invoices.filter((inv) => {
    const matchesSearch =
      inv.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inv.vendorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inv.poReference.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (filterTab === "ALL") return true;
    if (filterTab === "EXACT_MATCH") return inv.matchStatus === "EXACT_MATCH";
    if (filterTab === "MATCH_WITHIN_TOLERANCE")
      return inv.matchStatus === "MATCH_WITHIN_TOLERANCE";
    if (filterTab === "PARTIAL_RECEIPT")
      return inv.matchStatus === "PARTIAL_RECEIPT";
    if (filterTab === "DISCREPANCIES")
      return [
        "PRICE_MISMATCH",
        "QUANTITY_MISMATCH",
        "TAX_MISMATCH",
        "VENDOR_MISMATCH",
        "MISSING_PO",
        "MISSING_GRN",
        "DUPLICATE_INVOICE",
      ].includes(inv.matchStatus);

    return true;
  });

  const selectedInvoice = invoices.find((inv) => inv.id === selectedInvoiceId) || invoices[0];
  const poData = triangulation?.purchase_order;
  const grnList = triangulation?.goods_receipt_notes || [];
  const matchResult = triangulation?.matching_result;

  // Aggregate GRN quantities across multiple GRNs
  const totalGRNAcceptedQty = grnList.reduce((acc: number, grn: any) => {
    const sum = (grn.items || []).reduce(
      (s: number, itm: any) => s + (itm.quantity_accepted || 0),
      0
    );
    return acc + sum;
  }, 0);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono font-semibold text-accent-cyan tracking-wider uppercase">
              Agent 4: Three-Way Matching Agent
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-xs text-slate-400">
              Deterministic Python Mathematical Reconciliation (Zero LLM Math)
            </span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            Three-Way Matching & Discrepancy Engine
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Triangulates Supplier Invoices ↔ Purchase Orders ↔ Warehouse Goods Receipt Notes with statutory GST & tolerance rules.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleBatchEvaluate}
            disabled={batchEvaluating}
            className="flex items-center space-x-1.5 px-3 py-2 bg-navy-900 border border-navy-700 hover:border-slate-500 rounded-lg text-xs font-medium text-slate-200 transition"
          >
            {batchEvaluating ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin text-accent-cyan" />
            ) : (
              <RefreshCw className="w-3.5 h-3.5 text-accent-cyan" />
            )}
            <span>Batch Evaluate All</span>
          </button>

          <button
            onClick={handleRunMatch}
            disabled={evaluating || !selectedInvoiceId}
            className="flex items-center space-x-2 px-4 py-2 bg-accent-blue hover:bg-blue-600 disabled:opacity-50 text-white rounded-lg text-xs font-semibold shadow-lg shadow-blue-500/20 transition"
          >
            {evaluating ? (
              <Loader2 className="w-4 h-4 animate-spin text-white" />
            ) : (
              <GitCompare className="w-4 h-4" />
            )}
            <span>Run 3-Way Match</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs & Invoice Selector Bar */}
      <div className="bg-navy-900 border border-navy-800 rounded-xl p-4 space-y-3">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-1.5 text-xs font-mono">
            {[
              { id: "ALL", label: "All Invoices" },
              { id: "EXACT_MATCH", label: "Exact Match" },
              { id: "MATCH_WITHIN_TOLERANCE", label: "Within Tolerance" },
              { id: "PARTIAL_RECEIPT", label: "Partial Delivery" },
              { id: "DISCREPANCIES", label: "Discrepancies / Holds" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setFilterTab(tab.id)}
                className={`px-3 py-1.5 rounded-lg border text-xs font-semibold transition ${
                  filterTab === tab.id
                    ? "bg-accent-blue/20 border-accent-blue text-accent-cyan"
                    : "bg-navy-950/60 border-navy-800 text-slate-400 hover:text-white"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="relative w-full lg:w-72">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search Invoice #, PO or Vendor..."
              className="w-full bg-navy-950 border border-navy-800 pl-9 pr-3 py-1.5 rounded-lg text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-accent-cyan"
            />
          </div>
        </div>

        {/* Horizontal Invoice Carousel / Chips */}
        <div className="flex items-center space-x-2 overflow-x-auto pb-1 pt-1">
          {filteredInvoices.map((inv) => (
            <button
              key={inv.id}
              onClick={() => setSelectedInvoiceId(inv.id)}
              className={`flex-shrink-0 flex items-center space-x-2 px-3 py-2 rounded-lg border font-mono text-xs transition ${
                selectedInvoiceId === inv.id
                  ? "bg-accent-blue/25 border-accent-blue text-white shadow-sm"
                  : "bg-navy-950/50 border-navy-800 text-slate-400 hover:border-slate-700"
              }`}
            >
              <Receipt className="w-3.5 h-3.5 text-accent-cyan" />
              <span className="font-bold">{inv.id}</span>
              <span className="text-slate-500 text-[10px]">•</span>
              <span className="text-slate-300 text-[11px]">{formatINR(inv.totalAmount)}</span>
              <StatusBadge status={inv.matchStatus} size="sm" />
            </button>
          ))}
          {filteredInvoices.length === 0 && (
            <div className="text-xs text-slate-500 font-mono py-2">
              No invoices match the filter criteria.
            </div>
          )}
        </div>
      </div>

      {/* Evaluation Feedback Alert */}
      {evaluationFeedback && (
        <div
          className={`p-4 rounded-xl border flex items-start space-x-3 text-xs font-mono ${
            evaluationFeedback.type === "SUCCESS"
              ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-300"
              : "bg-rose-500/10 border-rose-500/30 text-rose-300"
          }`}
        >
          {evaluationFeedback.type === "SUCCESS" ? (
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
          ) : (
            <AlertOctagon className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
          )}
          <div className="space-y-1">
            <div className="font-bold">{evaluationFeedback.message}</div>
            <div className="text-slate-400 text-[11px]">
              {evaluationFeedback.type === "SUCCESS" ? (
                <span>
                  Requires manual sign-off by an authorized finance executive.{" "}
                  <Link href="/approvals" className="text-accent-cyan underline">
                    Open Approvals Queue →
                  </Link>
                </span>
              ) : (
                <span>
                  Review discrepancy details and initiate debit note or PO amendment.{" "}
                  <Link href="/exceptions" className="text-accent-cyan underline">
                    Open Exception Workbench →
                  </Link>
                </span>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 3-Way Triangulation Banner (PO ↔ GRN ↔ Invoice) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* 1. Purchase Order */}
        <div className="bg-navy-900 border border-navy-800 rounded-xl p-5 space-y-3 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-xs font-mono font-semibold text-accent-blue uppercase">
              <FileText className="w-4 h-4" />
              <span>1. Purchase Order</span>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold">
              {poData?.status || "APPROVED"}
            </span>
          </div>

          <div>
            <div className="text-lg font-bold text-white font-mono">
              {selectedInvoice?.poReference || "N/A"}
            </div>
            <div className="text-xs text-slate-300 truncate">
              Supplier: {triangulation?.vendor?.name || selectedInvoice?.vendorName || "Authorized Vendor"}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-2 border-t border-navy-800/80">
            <div>
              <span className="text-slate-500 block text-[10px]">PO Approved Value</span>
              <span className="text-white font-bold">
                {poData ? formatINR(poData.total_amount_inr) : "₹0.00"}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">PO Delivery Date</span>
              <span className="text-slate-300">{poData?.delivery_due_date || "2026-11-30"}</span>
            </div>
          </div>
        </div>

        {/* 2. Goods Receipt Note (Multi-GRN Support) */}
        <div className="bg-navy-900 border border-navy-800 rounded-xl p-5 space-y-3 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-xs font-mono font-semibold text-accent-cyan uppercase">
              <Truck className="w-4 h-4" />
              <span>2. Goods Receipt Note(s)</span>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold">
              {grnList.length > 1 ? `${grnList.length} GRNs LINKED` : grnList[0]?.status || "ACCEPTED"}
            </span>
          </div>

          <div>
            <div className="text-lg font-bold text-white font-mono flex items-center space-x-1.5 flex-wrap">
              {grnList.length > 0 ? (
                grnList.map((g: any, i: number) => (
                  <span key={g.id} className="text-white">
                    {g.id}
                    {i < grnList.length - 1 ? ", " : ""}
                  </span>
                ))
              ) : (
                <span className="text-amber-400">NO GRN FOUND</span>
              )}
            </div>
            <div className="text-xs text-slate-300">
              Warehouse: Central Logistics Hub
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-2 border-t border-navy-800/80">
            <div>
              <span className="text-slate-500 block text-[10px]">Total Accepted Qty</span>
              <span className="text-emerald-400 font-bold">{totalGRNAcceptedQty.toFixed(2)} units</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">Multi-GRN Delivery</span>
              <span className="text-slate-300">{grnList.length > 1 ? "Consolidated" : "Single Receipt"}</span>
            </div>
          </div>
        </div>

        {/* 3. Supplier Invoice */}
        <div className="bg-navy-900 border border-navy-800 rounded-xl p-5 space-y-3 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-xs font-mono font-semibold text-accent-emerald uppercase">
              <Receipt className="w-4 h-4" />
              <span>3. Supplier Invoice</span>
            </div>
            <StatusBadge status={selectedInvoice?.matchStatus || "REQUIRES_HUMAN_REVIEW"} size="sm" />
          </div>

          <div>
            <div className="text-lg font-bold text-white font-mono">
              {selectedInvoice?.id || "N/A"}
            </div>
            <div className="text-xs text-slate-300 truncate">
              GSTIN: {selectedInvoice?.vendorGSTIN || "N/A"}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-2 border-t border-navy-800/80">
            <div>
              <span className="text-slate-500 block text-[10px]">Invoiced Grand Total</span>
              <span className="text-white font-bold">
                {formatINR(selectedInvoice?.totalAmount || 0)}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">Statutory Taxes</span>
              <span className="text-slate-300">
                {formatINR(
                  (selectedInvoice?.cgst || 0) +
                    (selectedInvoice?.sgst || 0) +
                    (selectedInvoice?.igst || 0)
                )}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Tolerance Policy Controls & Variance Summary */}
      <div className="bg-navy-900 border border-navy-800 rounded-xl p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-3 border-b border-navy-800">
          <div>
            <h2 className="text-base font-semibold text-white flex items-center space-x-2">
              <Sliders className="w-4 h-4 text-accent-cyan" />
              <span>Tolerance Policies & Variance Audit</span>
            </h2>
            <p className="text-xs text-slate-400">
              Deterministic limits applied to line-item unit prices, tax roundings, and physical receipts.
            </p>
          </div>

          <div className="flex items-center space-x-4 text-xs font-mono">
            <div className="bg-navy-950 px-3 py-1.5 rounded-lg border border-navy-800 flex items-center space-x-2">
              <span className="text-slate-400">Price Tolerance:</span>
              <span className="text-accent-cyan font-bold">±{priceTolerance.toFixed(1)}%</span>
            </div>
            <div className="bg-navy-950 px-3 py-1.5 rounded-lg border border-navy-800 flex items-center space-x-2">
              <span className="text-slate-400">Tax Rounding:</span>
              <span className="text-emerald-400 font-bold">≤ ₹{taxTolerance.toFixed(2)}</span>
            </div>
            <div className="bg-navy-950 px-3 py-1.5 rounded-lg border border-navy-800 flex items-center space-x-2">
              <span className="text-slate-400">Qty Variance:</span>
              <span className="text-amber-400 font-bold">0.0% (Zero Tolerance)</span>
            </div>
          </div>
        </div>

        {/* Variances Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono">
          <div className="bg-navy-950/70 p-3 rounded-lg border border-navy-800">
            <span className="text-slate-500 block text-[10px]">Price Variance</span>
            <span
              className={`text-sm font-bold ${
                (matchResult?.price_variance_percent || 0) > priceTolerance
                  ? "text-rose-400"
                  : (matchResult?.price_variance_percent || 0) > 0
                  ? "text-blue-400"
                  : "text-emerald-400"
              }`}
            >
              {(matchResult?.price_variance_percent || 0).toFixed(2)}%
            </span>
          </div>

          <div className="bg-navy-950/70 p-3 rounded-lg border border-navy-800">
            <span className="text-slate-500 block text-[10px]">Quantity Variance</span>
            <span
              className={`text-sm font-bold ${
                (matchResult?.quantity_variance_percent || 0) > 0
                  ? "text-rose-400"
                  : "text-emerald-400"
              }`}
            >
              {(matchResult?.quantity_variance_percent || 0).toFixed(2)}%
            </span>
          </div>

          <div className="bg-navy-950/70 p-3 rounded-lg border border-navy-800">
            <span className="text-slate-500 block text-[10px]">Tax Discrepancy</span>
            <span
              className={`text-sm font-bold ${
                (matchResult?.tax_variance_inr || 0) > taxTolerance
                  ? "text-rose-400"
                  : "text-emerald-400"
              }`}
            >
              {formatINR(matchResult?.tax_variance_inr || 0)}
            </span>
          </div>

          <div className="bg-navy-950/70 p-3 rounded-lg border border-navy-800">
            <span className="text-slate-500 block text-[10px]">Financial Exposure</span>
            <span
              className={`text-sm font-bold ${
                (matchResult?.total_financial_impact_inr || 0) > 0
                  ? "text-rose-400"
                  : "text-emerald-400"
              }`}
            >
              {formatINR(matchResult?.total_financial_impact_inr || 0)}
            </span>
          </div>
        </div>
      </div>

      {/* Line-Item Reconciliation Matrix */}
      <div className="bg-navy-900 border border-navy-800 rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold text-white">Line-by-Line Reconciliation Table</h2>
            <p className="text-xs text-slate-400">
              Evaluates PO line specifications, warehouse receipts, and supplier billed rates.
            </p>
          </div>
          <StatusBadge status={selectedInvoice?.matchStatus || "REQUIRES_HUMAN_REVIEW"} />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-navy-950/80 text-slate-400 uppercase text-[10px] tracking-wider border-b border-navy-800">
              <tr>
                <th className="py-2.5 px-3">Item Code & Desc</th>
                <th className="py-2.5 px-3">PO Qty / Rate</th>
                <th className="py-2.5 px-3">GRN Accepted</th>
                <th className="py-2.5 px-3">Invoice Qty / Rate</th>
                <th className="py-2.5 px-3">Variance %</th>
                <th className="py-2.5 px-3">Financial Impact</th>
                <th className="py-2.5 px-3">Verdict</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-navy-800/60">
              {matchResult?.line_evaluations && matchResult.line_evaluations.length > 0 ? (
                matchResult.line_evaluations.map((line: any, idx: number) => (
                  <tr key={idx} className="hover:bg-navy-950/40">
                    <td className="py-3 px-3">
                      <div className="font-bold text-white">{line.item_code}</div>
                      <div className="text-[10px] font-sans text-slate-400 max-w-xs truncate">
                        {line.description || "Material item"}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-slate-300">
                      Rate: {formatINR(line.po_unit_price)}
                    </td>
                    <td className="py-3 px-3 font-bold text-emerald-400">
                      {line.grn_accepted_qty.toFixed(2)}
                    </td>
                    <td className="py-3 px-3 text-white">
                      {line.invoice_qty.toFixed(2)} @ {formatINR(line.invoice_unit_price)}
                    </td>
                    <td className="py-3 px-3">
                      <div
                        className={
                          line.price_variance_pct > priceTolerance
                            ? "text-rose-400 font-bold"
                            : line.price_variance_pct > 0
                            ? "text-blue-400"
                            : "text-emerald-400"
                        }
                      >
                        P: {line.price_variance_pct.toFixed(2)}%
                      </div>
                      <div
                        className={
                          line.quantity_variance_pct > 0
                            ? "text-rose-400 font-bold"
                            : "text-slate-400"
                        }
                      >
                        Q: {line.quantity_variance_pct.toFixed(2)}%
                      </div>
                    </td>
                    <td className="py-3 px-3 font-bold text-white">
                      {formatINR(line.financial_impact_inr)}
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                          line.status === "EXACT"
                            ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                            : line.status === "TOLERANCE_PASSED"
                            ? "bg-blue-500/20 text-blue-400 border border-blue-500/30"
                            : "bg-rose-500/20 text-rose-400 border border-rose-500/30"
                        }`}
                      >
                        {line.status}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7} className="py-6 text-center text-slate-400">
                    No line reconciliation items recorded. Click &quot;Run 3-Way Match&quot; to evaluate this invoice.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
