"use client";

import React, { useEffect, useState } from "react";
import {
  FileText,
  DollarSign,
  CheckCircle2,
  AlertCircle,
  Clock,
  ShieldCheck,
  TrendingUp,
  Percent,
  ArrowUpRight,
  Sparkles,
} from "lucide-react";
import { KPICard } from "@/components/ui/KPICard";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { formatINR } from "@/lib/utils";
import { APIService } from "@/services/api";
import { KPISummary, Invoice, ExceptionTicket, RiskAlert } from "@/types/finance";
import { mockKPISummary, mockRecentInvoices, mockExceptions, mockRiskAlerts } from "@/lib/mock-data";

export default function DashboardPage() {
  const [kpi, setKpi] = useState<KPISummary>(mockKPISummary);
  const [invoices, setInvoices] = useState<Invoice[]>(mockRecentInvoices);
  const [exceptions, setExceptions] = useState<ExceptionTicket[]>(mockExceptions);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      try {
        const [liveKpi, liveInvoices, liveExceptions] = await Promise.all([
          APIService.getDashboardKPIs(),
          APIService.getInvoices(),
          APIService.getExceptions(),
        ]);
        setKpi(liveKpi);
        if (liveInvoices && liveInvoices.length > 0) setInvoices(liveInvoices.slice(0, 5));
        if (liveExceptions && liveExceptions.length > 0) setExceptions(liveExceptions.slice(0, 3));
      } catch (err) {
        console.warn("Using fallback data for dashboard", err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono font-semibold text-accent-cyan tracking-wider uppercase">
              CFO Executive Overview
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-xs text-slate-400">
              Live Database Integration • Deterministic Invariance
            </span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            Accounts Payable Executive Dashboard
          </h1>
        </div>

        <div className="flex items-center space-x-3">
          <button className="px-4 py-2 bg-navy-800 hover:bg-navy-700 text-xs font-medium text-slate-200 rounded-lg border border-navy-700 transition">
            Export Financial Report
          </button>
          <a
            href="/documents"
            className="px-4 py-2 bg-gradient-to-r from-accent-blue to-accent-cyan text-white text-xs font-semibold rounded-lg shadow-md hover:opacity-90 transition flex items-center space-x-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Process New Invoice Batch</span>
          </a>
        </div>
      </div>

      {/* Row 1: Primary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard
          title="Total Invoices Processed"
          value={(kpi?.totalInvoicesProcessed ?? 0).toString()}
          subtitle="FY 2026-27 YTD"
          icon={FileText}
          trend={{ value: "+14.2% MoM", isPositive: true }}
          variant="default"
        />
        <KPICard
          title="Total Invoice Value"
          value={formatINR(kpi?.totalInvoiceValueINR ?? 0)}
          subtitle="Cumulative Invoiced Liability"
          icon={DollarSign}
          variant="accent"
        />
        <KPICard
          title="Outstanding Payables"
          value={formatINR(kpi?.totalOutstandingPayablesINR ?? 0)}
          subtitle={`Overdue: ${formatINR(kpi?.overduePayablesINR ?? 0)}`}
          icon={Clock}
          trend={{ value: "DPO: 34 Days", isNeutral: true }}
          variant="warning"
        />
        <KPICard
          title="3-Way Matching Rate"
          value={`${kpi?.matchingRatePercent ?? 0}%`}
          subtitle={`${kpi?.matchedInvoicesCount ?? 0} Verified Exact / Within Tolerance`}
          icon={CheckCircle2}
          trend={{ value: "+6.8% lift", isPositive: true }}
          variant="success"
        />
      </div>

      {/* Row 2: Secondary Performance & Cost Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard
          title="Straight-Through Processing"
          value={`${kpi?.straightThroughProcessingPercent ?? 0}%`}
          subtitle="Zero Manual Data Entry"
          icon={Percent}
          variant="accent"
        />
        <KPICard
          title="Avg. Processing Time"
          value={`${kpi?.avgProcessingTimeHours ?? 0} hrs`}
          subtitle="Baseline was 48.0 hrs"
          icon={Clock}
          trend={{ value: "-96% time saved", isPositive: true }}
          variant="success"
        />
        <KPICard
          title="Estimated Annual Savings"
          value={formatINR(kpi?.estimatedAnnualSavingsINR ?? 0)}
          subtitle="Labor & Error Reduction"
          icon={TrendingUp}
          trend={{ value: "ROI: 342%", isPositive: true }}
          variant="success"
        />
        <KPICard
          title="Active Discrepancies"
          value={(kpi?.exceptionCount ?? 0).toString()}
          subtitle={`${kpi?.duplicateAlertsCount ?? 0} Potential Duplicate Alerts`}
          icon={AlertCircle}
          trend={{ value: "Requires Review", isNeutral: false }}
          variant="danger"
        />
      </div>

      {/* Row 3: Recent Invoices Ledger & Exception Workbench Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Invoices Table (2 Cols) */}
        <div className="lg:col-span-2 bg-navy-900 border border-navy-800 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-semibold text-white">
                Live Invoices & 3-Way Reconciliation
              </h2>
              <p className="text-xs text-slate-400">
                Live verification across Purchase Orders and Goods Receipt Notes
              </p>
            </div>
            <a
              href="/invoices"
              className="text-xs text-accent-cyan hover:underline flex items-center space-x-1"
            >
              <span>View All</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </a>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-navy-950/60 text-slate-400 uppercase text-[10px] tracking-wider border-b border-navy-800">
                <tr>
                  <th className="py-2.5 px-3">Invoice / PO</th>
                  <th className="py-2.5 px-3">Supplier Name</th>
                  <th className="py-2.5 px-3">Amount (INR)</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Due Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-navy-800/60 font-mono">
                {invoices.map((inv) => (
                  <tr key={inv.id} className="hover:bg-navy-800/40 transition">
                    <td className="py-3 px-3">
                      <div className="font-semibold text-white">{inv.id}</div>
                      <div className="text-[10px] text-slate-400">
                        {inv.poReference}
                      </div>
                    </td>
                    <td className="py-3 px-3 font-sans">
                      <div className="text-slate-200">{inv.vendorName || inv.vendorId}</div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {inv.vendorGSTIN}
                      </div>
                    </td>
                    <td className="py-3 px-3 font-bold text-slate-100">
                      {formatINR(inv.totalAmount)}
                    </td>
                    <td className="py-3 px-3">
                      <StatusBadge status={inv.matchStatus} size="sm" />
                    </td>
                    <td className="py-3 px-3 text-slate-400">{inv.dueDate}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Action Priority Queue (1 Col) */}
        <div className="space-y-6">
          {/* Active Exceptions */}
          <div className="bg-navy-900 border border-navy-800 rounded-xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 text-accent-rose" />
                <span>Exception Workbench</span>
              </h3>
              <span className="text-[10px] bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded font-mono">
                {exceptions.length} PENDING
              </span>
            </div>

            <div className="space-y-2.5">
              {exceptions.map((exc) => (
                <div
                  key={exc.id}
                  className="p-3 rounded-lg bg-navy-950/70 border border-navy-800 text-xs space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-accent-cyan font-medium">
                      {exc.invoiceId}
                    </span>
                    <span className="text-[10px] uppercase font-semibold text-accent-rose">
                      {exc.category}
                    </span>
                  </div>
                  <div className="text-slate-300 text-[11px] font-sans">
                    {exc.expectedValue}
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Financial Impact:{" "}
                    <span className="text-white font-mono font-medium">
                      {formatINR(exc.financialImpactINR)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Risk Alerts */}
          <div className="bg-navy-900 border border-navy-800 rounded-xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-accent-amber" />
                <span>Fraud & Anomaly Alerts</span>
              </h3>
              <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded font-mono">
                EXPLAINABLE AI
              </span>
            </div>

            <div className="space-y-2.5">
              {mockRiskAlerts.map((alert) => (
                <div
                  key={alert.id}
                  className="p-3 rounded-lg bg-navy-950/70 border border-navy-800 text-xs space-y-1"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs text-white">
                      Risk Score: {alert.riskScore}/100
                    </span>
                    <span className="text-[10px] text-amber-400 font-semibold uppercase">
                      {alert.category}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300">
                    {alert.explanation}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
