"use client";

import React from "react";
import { formatINR } from "@/lib/utils";
import { mockRiskAlerts } from "@/lib/mock-data";
import { ShieldAlert, AlertTriangle, FileWarning, TrendingUp } from "lucide-react";

export default function FraudRiskPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono font-semibold text-accent-cyan tracking-wider uppercase">
              Agent 5: Fraud & Duplicate Detection Agent
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-xs text-slate-400">Explainable Anomaly & Risk Scoring</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            Fraud & Financial Risk Detection
          </h1>
        </div>
      </div>

      <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-xl text-xs text-amber-300">
        <span className="font-bold">MBA Governance Notice:</span> Risk alerts indicate heuristic and
        statistical anomalies requiring human verification. No transaction is automatically
        classified as fraud or penalized without authenticated controller review.
      </div>

      <div className="grid grid-cols-1 gap-4">
        {mockRiskAlerts.map((alert) => (
          <div
            key={alert.id}
            className="bg-navy-900 border border-navy-800 rounded-xl p-6 space-y-4 hover:border-navy-700 transition"
          >
            <div className="flex items-center justify-between border-b border-navy-800 pb-3">
              <div className="flex items-center space-x-3">
                <span className="text-sm font-mono font-bold text-accent-cyan">{alert.id}</span>
                <span className="text-xs text-slate-400 font-mono">Invoice: {alert.invoiceId}</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/20 text-amber-300 font-mono">
                  RISK SCORE: {alert.riskScore}/100
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-navy-800 text-slate-300 font-mono border border-navy-700">
                  {alert.ruleTriggered}
                </span>
              </div>
            </div>

            <div className="text-xs space-y-2">
              <div className="text-slate-300">
                <span className="font-semibold text-white">Vendor:</span> {alert.vendorName}
              </div>
              <div className="text-slate-300">
                <span className="font-semibold text-accent-amber">Anomaly Explanation:</span>{" "}
                {alert.explanation}
              </div>
              <div className="text-slate-300">
                <span className="font-semibold text-accent-cyan">Recommended Action:</span>{" "}
                {alert.suggestedAction}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

