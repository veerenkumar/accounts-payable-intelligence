"use client";

import React, { useState, useEffect } from "react";
import { formatINR } from "@/lib/utils";
import { APIService } from "@/services/api";
import { TrendingUp, DollarSign, Clock, ShieldCheck, Loader2, AlertTriangle, RefreshCw } from "lucide-react";
import { KPICard } from "@/components/ui/KPICard";

export default function AnalyticsPage() {
  const [roiData, setRoiData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadData = () => {
    setLoading(true);
    setError(null);
    APIService.getROIModel()
      .then((data) => {
        if (data) setRoiData(data);
      })
      .catch((err) => {
        console.error("Failed to load live ROI model:", err);
        setError("Unable to connect to live analytics service. Displaying baseline reference model.");
      })
      .finally(() => {
        setLoading(false);
      });
  };

  useEffect(() => {
    loadData();
  }, []);

  const scenarioList: any[] = Array.isArray(roiData?.scenarios)
    ? roiData.scenarios
    : [];

  const findScenario = (nameSnippet: string, fallback: any) => {
    const found = scenarioList.find((s: any) =>
      s.scenario_name?.toLowerCase().includes(nameSnippet.toLowerCase())
    );
    if (!found) {
      // Support object format if returned as { scenarios: { base_case: ... } }
      const key = nameSnippet.toLowerCase();
      if (roiData?.scenarios && typeof roiData.scenarios === "object" && !Array.isArray(roiData.scenarios)) {
        const objFound = roiData.scenarios[key] || roiData.scenarios[`${key}_case`];
        if (objFound) return { ...fallback, ...objFound };
      }
      return fallback;
    }
    return {
      annual_invoice_volume: found.annual_invoice_volume ?? fallback.annual_invoice_volume,
      straight_through_processing_percent:
        found.straight_through_rate_pct ?? found.straight_through_processing_percent ?? fallback.straight_through_processing_percent,
      annual_net_savings_inr: found.annual_net_savings_inr ?? fallback.annual_net_savings_inr,
      three_year_net_benefit_inr:
        found.three_year_net_benefit_inr ??
        (found.annual_net_savings_inr ? found.annual_net_savings_inr * 3 : fallback.three_year_net_benefit_inr),
      roi_percent: found.roi_percent ?? fallback.roi_percent,
      payback_months: found.payback_period_months ?? found.payback_months ?? fallback.payback_months,
    };
  };

  const conservative = findScenario("conservative", {
    annual_net_savings_inr: 1920000,
    three_year_net_benefit_inr: 5760000,
    roi_percent: 160.0,
    payback_months: 7.5,
    straight_through_processing_percent: 60.0,
    annual_invoice_volume: 8000,
  });

  const baseCase = findScenario("base", {
    annual_net_savings_inr: 3450000,
    three_year_net_benefit_inr: 9850000,
    roi_percent: 342.0,
    payback_months: 4.2,
    straight_through_processing_percent: 78.2,
    annual_invoice_volume: 12000,
  });

  const optimistic = findScenario("optimistic", {
    annual_net_savings_inr: 5120000,
    three_year_net_benefit_inr: 15360000,
    roi_percent: 426.0,
    payback_months: 2.8,
    straight_through_processing_percent: 88.0,
    annual_invoice_volume: 16000,
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono font-semibold text-accent-cyan tracking-wider uppercase">
              Module M5: Business Impact & ROI
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-xs text-slate-400">Financial Performance & Cost-Benefit Analysis</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            Financial Analytics & ROI Modeler
          </h1>
        </div>

        <div className="flex items-center space-x-2 text-xs text-slate-400 font-mono">
          {loading && <Loader2 className="w-3.5 h-3.5 animate-spin text-accent-cyan" />}
          <span>Verified against live NPV model</span>
        </div>
      </div>

      {error && (
        <div className="flex items-center justify-between p-3.5 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-300 text-xs font-mono">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{error}</span>
          </div>
          <button
            onClick={loadData}
            className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 rounded text-xs transition flex items-center space-x-1"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Retry</span>
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard
          title="Baseline Cost Per Invoice"
          value="₹450.00"
          subtitle="Manual Entry + Physical Routing"
          icon={DollarSign}
          variant="warning"
        />
        <KPICard
          title="Automated Cost Per Invoice"
          value="₹42.50"
          subtitle="Direct OCR + Agentic 3-Way Match"
          icon={TrendingUp}
          trend={{ value: "-90.5% Cost Reduction", isPositive: true }}
          variant="success"
        />
        <KPICard
          title="3-Year Net Benefit"
          value={formatINR(baseCase.three_year_net_benefit_inr)}
          subtitle="Labor, Errors & Duplicate Avoidance"
          icon={TrendingUp}
          variant="accent"
        />
        <KPICard
          title="Payback Period"
          value={`${baseCase.payback_months} Months`}
          subtitle="Initial Investment ₹12,00,000"
          icon={Clock}
          variant="success"
        />
      </div>

      <div className="bg-navy-900 border border-navy-800 rounded-xl p-6 space-y-4">
        <h2 className="text-base font-semibold text-white">Cost-Benefit Scenarios (MBA Model)</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-navy-950/60 text-slate-400 uppercase text-[10px] tracking-wider border-b border-navy-800">
              <tr>
                <th className="py-2.5 px-3 font-sans">Scenario</th>
                <th className="py-2.5 px-3">Annual Invoice Volume</th>
                <th className="py-2.5 px-3">Straight-Through Rate</th>
                <th className="py-2.5 px-3">Annual Net Savings (INR)</th>
                <th className="py-2.5 px-3">ROI (%)</th>
                <th className="py-2.5 px-3">Payback (Months)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-navy-800/60">
              <tr className="hover:bg-navy-800/40 transition">
                <td className="py-3 px-3 font-sans font-semibold text-rose-300">Conservative / Worst-Case</td>
                <td className="py-3 px-3">{conservative.annual_invoice_volume?.toLocaleString() || "8,000"}</td>
                <td className="py-3 px-3">{conservative.straight_through_processing_percent}%</td>
                <td className="py-3 px-3 font-bold text-white">{formatINR(conservative.annual_net_savings_inr)}</td>
                <td className="py-3 px-3 text-emerald-400">{conservative.roi_percent}%</td>
                <td className="py-3 px-3 text-slate-300">{conservative.payback_months}</td>
              </tr>
              <tr className="hover:bg-navy-800/40 transition bg-navy-850/40">
                <td className="py-3 px-3 font-sans font-bold text-accent-cyan">Base-Case (Expected)</td>
                <td className="py-3 px-3">{baseCase.annual_invoice_volume?.toLocaleString() || "12,000"}</td>
                <td className="py-3 px-3">{baseCase.straight_through_processing_percent}%</td>
                <td className="py-3 px-3 font-bold text-white">{formatINR(baseCase.annual_net_savings_inr)}</td>
                <td className="py-3 px-3 text-emerald-400 font-bold">{baseCase.roi_percent}%</td>
                <td className="py-3 px-3 text-slate-300">{baseCase.payback_months}</td>
              </tr>
              <tr className="hover:bg-navy-800/40 transition">
                <td className="py-3 px-3 font-sans font-semibold text-emerald-300">Optimistic / Best-Case</td>
                <td className="py-3 px-3">{optimistic.annual_invoice_volume?.toLocaleString() || "16,000"}</td>
                <td className="py-3 px-3">{optimistic.straight_through_processing_percent}%</td>
                <td className="py-3 px-3 font-bold text-white">{formatINR(optimistic.annual_net_savings_inr)}</td>
                <td className="py-3 px-3 text-emerald-400 font-bold">{optimistic.roi_percent}%</td>
                <td className="py-3 px-3 text-slate-300">{optimistic.payback_months}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

