import React from "react";
import { Loader2 } from "lucide-react";

export default function Loading() {
  return (
    <div className="min-h-[50vh] flex flex-col items-center justify-center space-y-3">
      <div className="relative">
        <Loader2 className="w-8 h-8 animate-spin text-accent-cyan" />
        <div className="absolute inset-0 rounded-full blur-md bg-accent-cyan/20 animate-pulse" />
      </div>
      <div className="text-xs font-mono text-slate-400 tracking-wider uppercase">
        Loading AP Intelligence Ledger...
      </div>
    </div>
  );
}

