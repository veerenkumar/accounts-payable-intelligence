"use client";

import React, { useState, useEffect } from "react";
import { APIService } from "@/services/api";
import { PackageCheck, Search, Loader2 } from "lucide-react";

interface GRNData {
  id: string;
  po_id?: string;
  poId?: string;
  vendor_id?: string;
  vendorName?: string;
  receipt_date?: string;
  receiptDate?: string;
  status: string;
  items?: any[];
}

const fallbackGRNs = [
  {
    id: "GRN-2026-00085",
    po_id: "PO-2026-00101",
    vendor_id: "VEND-001",
    receipt_date: "2026-10-08",
    status: "ACCEPTED",
  },
  {
    id: "GRN-2026-00088",
    po_id: "PO-2026-00104",
    vendor_id: "VEND-004",
    receipt_date: "2026-10-14",
    status: "ACCEPTED",
  },
];

export default function GRNPage() {
  const [grns, setGRNs] = useState<GRNData[]>(fallbackGRNs);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    APIService.getGRNs().then((data) => {
      if (data && data.length > 0) {
        setGRNs(data);
      }
      setLoading(false);
    });
  }, []);

  const filtered = grns.filter(
    (g) =>
      g.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (g.po_id && g.po_id.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (g.vendor_id && g.vendor_id.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono font-semibold text-accent-cyan tracking-wider uppercase">
              Agent 3: Goods Receipt Verification
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-xs text-slate-400">Physical Inward Inspection</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            Goods Receipt Notes (GRN)
          </h1>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-navy-900 border border-navy-800 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-96">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search GRN number, PO, or supplier..."
            className="w-full bg-navy-950/80 border border-navy-700/80 rounded-lg pl-9 pr-4 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-accent-blue/60 transition"
          />
        </div>

        <div className="flex items-center space-x-3 text-xs text-slate-400 font-mono">
          {loading && <Loader2 className="w-3.5 h-3.5 animate-spin text-accent-cyan" />}
          <span>Showing {filtered.length} GRN inward receipts</span>
        </div>
      </div>

      <div className="bg-navy-900 border border-navy-800 rounded-xl p-6 space-y-4">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-navy-950/60 text-slate-400 uppercase text-[10px] tracking-wider border-b border-navy-800">
              <tr>
                <th className="py-2.5 px-3">GRN #</th>
                <th className="py-2.5 px-3">Linked PO</th>
                <th className="py-2.5 px-3 font-sans">Supplier Code</th>
                <th className="py-2.5 px-3">Receipt Date</th>
                <th className="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-navy-800/60">
              {filtered.map((grn) => (
                <tr key={grn.id} className="hover:bg-navy-800/40 transition">
                  <td className="py-3 px-3 font-bold text-accent-cyan">{grn.id}</td>
                  <td className="py-3 px-3 text-slate-300">{grn.po_id || grn.poId}</td>
                  <td className="py-3 px-3 font-sans text-slate-200">{grn.vendor_id || "Supplier"}</td>
                  <td className="py-3 px-3 text-slate-400">{grn.receipt_date || grn.receiptDate || "2026-10-18"}</td>
                  <td className="py-3 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        grn.status === "ACCEPTED"
                          ? "bg-emerald-500/20 text-emerald-400"
                          : grn.status === "REJECTED"
                          ? "bg-rose-500/20 text-rose-400"
                          : "bg-amber-500/20 text-amber-400"
                      }`}
                    >
                      {grn.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

