"use client";

import React, { useEffect } from "react";
import { AlertTriangle, RefreshCw, Home } from "lucide-react";
import Link from "next/link";

export default function ErrorBoundary({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("AP Intelligence Caught UI Error:", error);
  }, [error]);

  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center p-6 text-center space-y-4">
      <div className="p-4 bg-rose-500/10 border border-rose-500/30 rounded-2xl text-rose-400">
        <AlertTriangle className="w-10 h-10 animate-pulse" />
      </div>

      <div className="space-y-2 max-w-md">
        <h2 className="text-xl font-bold tracking-tight text-white">
          Interface Rendering Disruption Caught
        </h2>
        <p className="text-xs text-slate-400 leading-relaxed">
          An unexpected interface anomaly was intercepted by the AP Intelligence Error Boundary.
          Underlying deterministic ledger data remains secure.
        </p>
        {error.message && (
          <div className="p-2.5 bg-navy-950/80 border border-navy-800 rounded-lg text-left font-mono text-[11px] text-rose-300 truncate max-w-sm mx-auto">
            {error.message}
          </div>
        )}
      </div>

      <div className="flex items-center space-x-3 pt-2">
        <button
          onClick={() => reset()}
          className="px-4 py-2 bg-accent-blue hover:bg-blue-600 text-white rounded-lg text-xs font-semibold flex items-center space-x-2 transition shadow-lg shadow-accent-blue/20"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Retry Component</span>
        </button>

        <Link
          href="/"
          className="px-4 py-2 bg-navy-800 hover:bg-navy-700 text-slate-200 border border-navy-700 rounded-lg text-xs font-semibold flex items-center space-x-2 transition"
        >
          <Home className="w-3.5 h-3.5" />
          <span>Return to Dashboard</span>
        </Link>
      </div>
    </div>
  );
}

