"use client";

import React from "react";
import { FileCheck, Shield, Lock } from "lucide-react";

export default function AuditPage() {
  const auditLogs = [
    {
      id: "LOG-00912",
      timestamp: "2026-11-07 14:10:02",
      actor: "Veeren Kumar (FINANCE_CONTROLLER)",
      action: "APPROVE_INVOICE",
      entity: "INV-2026-00454",
      notes: "Approved payment voucher within authorized ₹50,00,000 threshold.",
    },
    {
      id: "LOG-00911",
      timestamp: "2026-11-07 14:05:44",
      actor: "Three-Way Matching Agent",
      action: "RECONCILIATION_EVALUATED",
      entity: "INV-2026-00454",
      notes: "Deterministic verification matched against PO-2026-00108 with 0% variance.",
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center space-x-2">
          <span className="text-xs font-mono font-semibold text-accent-cyan tracking-wider uppercase">
            Internal Financial Controls & DPDP Compliance
          </span>
          <span className="text-slate-600">•</span>
          <span className="text-xs text-slate-400">Non-Repudiation Immutable Ledger</span>
        </div>
        <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
          Audit & Compliance Trail
        </h1>
      </div>

      <div className="bg-navy-900 border border-navy-800 rounded-xl p-6 space-y-4">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-navy-950/60 text-slate-400 uppercase text-[10px] tracking-wider border-b border-navy-800">
              <tr>
                <th className="py-2.5 px-3">Log ID</th>
                <th className="py-2.5 px-3">Timestamp</th>
                <th className="py-2.5 px-3">Actor</th>
                <th className="py-2.5 px-3">Action</th>
                <th className="py-2.5 px-3">Entity</th>
                <th className="py-2.5 px-3 font-sans">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-navy-800/60">
              {auditLogs.map((log) => (
                <tr key={log.id} className="hover:bg-navy-800/40 transition">
                  <td className="py-3 px-3 font-bold text-accent-cyan">{log.id}</td>
                  <td className="py-3 px-3 text-slate-400">{log.timestamp}</td>
                  <td className="py-3 px-3 text-white font-medium">{log.actor}</td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded text-[10px] bg-navy-800 text-slate-300 border border-navy-700">
                      {log.action}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-accent-blue">{log.entity}</td>
                  <td className="py-3 px-3 font-sans text-slate-300">{log.notes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

