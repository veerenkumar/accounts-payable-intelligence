import type { Metadata } from "next";
import "./globals.css";
import { Sidebar } from "@/components/layout/Sidebar";
import { TopNavigation } from "@/components/layout/TopNavigation";

export const metadata: Metadata = {
  title: "AP INTELLIGENCE — Agentic AI Accounts Payable & 3-Way Match Platform",
  description:
    "Enterprise financial automation platform combining multi-agent AI and deterministic 3-way matching controls.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body className="bg-navy-950 text-slate-100 min-h-screen">
        <Sidebar />
        <div className="pl-64 flex flex-col min-h-screen">
          <TopNavigation />
          <main className="flex-1 p-8 bg-gradient-to-b from-navy-950 via-navy-900 to-navy-950">
            {children}
          </main>
        </div>
      </body>
    </html>
  );
}

