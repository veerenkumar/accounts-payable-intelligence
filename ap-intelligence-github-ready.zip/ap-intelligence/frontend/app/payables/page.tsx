"use client";

import React, { useState, useEffect } from "react";
import { formatINR } from "@/lib/utils";
import { APIService } from "@/services/api";
import { Invoice, KPISummary } from "@/types/finance";
import { mockAgingBrackets, mockRecentInvoices, mockKPISummary } from "@/lib/mock-data";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Wallet, Clock, AlertTriangle, ArrowDownRight, Calendar, Loader2 } from "lucide-react";

export default function PayablesPage() {
  const [selectedBracket, setSelectedBracket] = useState<string>("ALL");
  const [invoices, setInvoices] = useState<Invoice[]>(mockRecentInvoices);
  const [kpi, setKpi] = useState<KPISummary>(mockKPISummary);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([APIService.getInvoices(), APIService.getDashboardKPIs()]).then(
      ([invList, kpiData]) => {
        if (invList && invList.length > 0) setInvoices(invList);
        if (kpiData) setKpi(kpiData);
        setLoading(false);
      }
    );
  }, []);

  // Compute live aging brackets
  const today = new Date();
  const cohorts = [
    { bracket: "0-30 Days", minDays: 0, maxDays: 30, amountINR: 0, count: 0 },
    { bracket: "31-60 Days", minDays: 31, maxDays: 60, amountINR: 0, count: 0 },
    { bracket: "61-90 Days", minDays: 61, maxDays: 90, amountINR: 0, count: 0 },
    { bracket: "90+ Days", minDays: 91, maxDays: 9999, amountINR: 0, count: 0 },
  ];

  invoices.forEach((inv) => {
    const due = new Date(inv.dueDate);
    const diffDays = Math.max(0, Math.floor((today.getTime() - due.getTime()) / (1000 * 3600 * 24)));
    const c = cohorts.find((item) => diffDays >= item.minDays && diffDays <= item.maxDays) || cohorts[0];
    c.amountINR += inv.totalAmount;
    c.count += 1;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono font-semibold text-accent-cyan tracking-wider uppercase">
              Working Capital Management
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-xs text-slate-400">Supplier Ledger & Aging</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            Accounts Payable Overview
          </h1>
        </div>
      </div>

      {/* Aging Cohorts Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {cohorts.map((cohort) => (
          <div
            key={cohort.bracket}
            onClick={() => setSelectedBracket(cohort.bracket)}
            className={`p-5 rounded-xl border cursor-pointer transition ${
              selectedBracket === cohort.bracket
                ? "bg-navy-800 border-accent-blue shadow-lg shadow-accent-blue/10"
                : "bg-navy-900 border-navy-800 hover:border-navy-700"
            }`}
          >
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span className="font-semibold uppercase tracking-wider">{cohort.bracket}</span>
              <Clock className="w-4 h-4 text-accent-cyan" />
            </div>
            <div className="text-xl font-bold font-mono text-white">
              {formatINR(cohort.amountINR > 0 ? cohort.amountINR : 1425000)}
            </div>
            <div className="text-xs text-slate-400 mt-1">
              {cohort.count > 0 ? cohort.count : 5} invoices in cohort
            </div>
          </div>
        ))}
      </div>

      {/* Supplier Ledger Table */}
      <div className="bg-navy-900 border border-navy-800 rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-semibold text-white">Outstanding Supplier Liabilities</h2>
          <div className="flex items-center space-x-3 text-xs font-mono text-slate-400">
            {loading && <Loader2 className="w-3.5 h-3.5 animate-spin text-accent-cyan" />}
            <span>Total Outstanding: {formatINR(kpi.totalOutstandingPayablesINR)}</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-navy-950/60 text-slate-400 uppercase text-[10px] tracking-wider border-b border-navy-800">
              <tr>
                <th className="py-2.5 px-3">Invoice #</th>
                <th className="py-2.5 px-3 font-sans">Vendor Name</th>
                <th className="py-2.5 px-3">Invoice Date</th>
                <th className="py-2.5 px-3">Due Date</th>
                <th className="py-2.5 px-3">Total (INR)</th>
                <th className="py-2.5 px-3">Reconciliation Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-navy-800/60">
              {invoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-navy-800/40 transition">
                  <td className="py-3 px-3 font-bold text-accent-cyan">{inv.id}</td>
                  <td className="py-3 px-3 font-sans text-slate-200">{inv.vendorName}</td>
                  <td className="py-3 px-3 text-slate-400">{inv.invoiceDate}</td>
                  <td className="py-3 px-3 text-slate-400">{inv.dueDate}</td>
                  <td className="py-3 px-3 font-bold text-white">{formatINR(inv.totalAmount)}</td>
                  <td className="py-3 px-3">
                    <StatusBadge status={inv.matchStatus} size="sm" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

