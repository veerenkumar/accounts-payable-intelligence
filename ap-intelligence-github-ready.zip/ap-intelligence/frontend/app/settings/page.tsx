"use client";

import React, { useState } from "react";
import { Settings as SettingsIcon, Save, Shield } from "lucide-react";

export default function SettingsPage() {
  const [priceTolerance, setPriceTolerance] = useState(2.0);
  const [qtyTolerance, setQtyTolerance] = useState(0.0);
  const [taxToleranceINR, setTaxToleranceINR] = useState(5.0);
  const [execLimit, setExecLimit] = useState(100000);
  const [mgrLimit, setMgrLimit] = useState(1000000);

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <div className="flex items-center space-x-2">
          <span className="text-xs font-mono font-semibold text-accent-cyan tracking-wider uppercase">
            Internal Governance & Policy Controls
          </span>
          <span className="text-slate-600">•</span>
          <span className="text-xs text-slate-400">Tolerance Limits & Approval Thresholds</span>
        </div>
        <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
          System Settings & Financial Policies
        </h1>
      </div>

      <div className="bg-navy-900 border border-navy-800 rounded-xl p-6 space-y-6">
        <div>
          <h2 className="text-sm font-semibold text-white uppercase tracking-wider text-accent-cyan font-mono">
            1. Three-Way Matching Tolerance Thresholds
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Deterministic tolerances applied by Agent 4 during reconciliation.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-4">
            <div className="space-y-1.5">
              <label className="text-xs text-slate-300">Unit Price Variance (%)</label>
              <input
                type="number"
                value={priceTolerance}
                onChange={(e) => setPriceTolerance(parseFloat(e.target.value) || 0)}
                className="w-full bg-navy-950 border border-navy-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs text-slate-300">Quantity Variance (%)</label>
              <input
                type="number"
                value={qtyTolerance}
                onChange={(e) => setQtyTolerance(parseFloat(e.target.value) || 0)}
                className="w-full bg-navy-950 border border-navy-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs text-slate-300">Tax Rounding Diff (INR)</label>
              <input
                type="number"
                value={taxToleranceINR}
                onChange={(e) => setTaxToleranceINR(parseFloat(e.target.value) || 0)}
                className="w-full bg-navy-950 border border-navy-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
              />
            </div>
          </div>
        </div>

        <div className="border-t border-navy-800 pt-6">
          <h2 className="text-sm font-semibold text-white uppercase tracking-wider text-accent-cyan font-mono">
            2. Delegation of Authority (Approval Ceilings)
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Monetary limits governing automated routing to authorized human roles.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
            <div className="space-y-1.5">
              <label className="text-xs text-slate-300">Finance Executive Limit (INR)</label>
              <input
                type="number"
                value={execLimit}
                onChange={(e) => setExecLimit(parseFloat(e.target.value) || 0)}
                className="w-full bg-navy-950 border border-navy-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs text-slate-300">AP Manager Limit (INR)</label>
              <input
                type="number"
                value={mgrLimit}
                onChange={(e) => setMgrLimit(parseFloat(e.target.value) || 0)}
                className="w-full bg-navy-950 border border-navy-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
              />
            </div>
          </div>
        </div>

        <div className="pt-4 flex justify-end">
          <button className="px-4 py-2 bg-gradient-to-r from-accent-blue to-accent-cyan text-white text-xs font-semibold rounded-lg shadow hover:opacity-90 transition flex items-center space-x-1.5">
            <Save className="w-3.5 h-3.5" />
            <span>Save Policies & Rules</span>
          </button>
        </div>
      </div>
    </div>
  );
}

