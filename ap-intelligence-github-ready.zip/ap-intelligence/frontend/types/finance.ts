export type UserRole =
  | "ADMIN"
  | "FINANCE_CONTROLLER"
  | "AP_MANAGER"
  | "FINANCE_EXECUTIVE";

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  approvalLimitINR: number;
  department: string;
}

export type MatchStatus =
  | "EXACT_MATCH"
  | "MATCH_WITHIN_TOLERANCE"
  | "QUANTITY_MISMATCH"
  | "PRICE_MISMATCH"
  | "TAX_MISMATCH"
  | "VENDOR_MISMATCH"
  | "MISSING_PO"
  | "MISSING_GRN"
  | "DUPLICATE_INVOICE"
  | "PARTIAL_RECEIPT"
  | "REQUIRES_HUMAN_REVIEW";

export type InvoiceStatus =
  | "INGESTED"
  | "EXTRACTED"
  | "MATCHING"
  | "MATCHED_EXACT"
  | "MATCHED_TOLERANCE"
  | "EXCEPTION_HOLD"
  | "PENDING_APPROVAL"
  | "APPROVED"
  | "REJECTED"
  | "PAID";

export interface LineItem {
  lineNumber: number;
  itemCode: string;
  description: string;
  hsnSac: string;
  quantity: number;
  unitPrice: number;
  gstRate: number;
  taxableAmount: number;
  totalAmount: number;
}

export interface Invoice {
  id: string;
  vendorId: string;
  vendorName: string;
  poReference: string;
  invoiceDate: string;
  dueDate: string;
  vendorGSTIN: string;
  recipientGSTIN: string;
  taxableValue: number;
  cgst: number;
  sgst: number;
  igst: number;
  totalAmount: number;
  status: InvoiceStatus;
  matchStatus: MatchStatus;
  extractionConfidence: number;
  lineItems: LineItem[];
  documentId?: string;
  ocrData?: any;
  ocrDiscrepancies?: {
    field: string;
    label: string;
    ledger_value: any;
    ocr_value: any;
    has_conflict: boolean;
    description: string;
  }[];
}

export interface Vendor {
  id: string;
  name: string;
  gstin: string;
  stateCode: string;
  paymentTermsDays: number;
  riskCategory: "LOW" | "MEDIUM" | "HIGH";
  totalSpendYTD: number;
  outstandingPayables: number;
  discrepancyRate: number;
}

export interface ExceptionTicket {
  id: string;
  invoiceId: string;
  vendorName: string;
  category: string;
  severity: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  expectedValue: string;
  actualValue: string;
  financialImpactINR: number;
  responsibleDepartment: string;
  status: "OPEN" | "INVESTIGATING" | "RESOLVED";
  createdAt: string;
}

export interface RiskAlert {
  id: string;
  invoiceId: string;
  vendorName: string;
  riskScore: number;
  category: "LOW" | "MODERATE" | "ELEVATED" | "HIGH";
  ruleTriggered: string;
  explanation: string;
  suggestedAction: string;
}

export interface ApprovalItem {
  id: string;
  invoiceId: string;
  vendorName: string;
  amountINR: number;
  requiredRole: UserRole;
  matchStatus: MatchStatus;
  status: "PENDING" | "APPROVED" | "REJECTED" | "HELD";
  submittedAt: string;
  blockingExceptionsCount?: number;
}

export interface KPISummary {
  totalInvoicesProcessed: number;
  totalInvoiceValueINR: number;
  totalOutstandingPayablesINR: number;
  matchedInvoicesCount: number;
  matchingRatePercent: number;
  pendingApprovalsCount: number;
  exceptionCount: number;
  duplicateAlertsCount: number;
  overduePayablesINR: number;
  avgProcessingTimeHours: number;
  estimatedAnnualSavingsINR: number;
  straightThroughProcessingPercent: number;
}

export interface LineMatchEvaluationData {
  item_code: string;
  description?: string;
  invoice_qty: number;
  grn_accepted_qty: number;
  invoice_unit_price: number;
  po_unit_price: number;
  price_variance_pct: number;
  quantity_variance_pct: number;
  financial_impact_inr: number;
  status: string;
  reason?: string;
}

export interface MatchingResultData {
  invoice_id: string;
  vendor_id?: string;
  vendor_name?: string;
  po_id?: string;
  grn_id?: string;
  match_status: MatchStatus;
  price_variance_percent: number;
  quantity_variance_percent: number;
  tax_variance_inr: number;
  total_financial_impact_inr: number;
  is_matched: boolean;
  evaluation_notes?: string;
  discrepancies: string[];
  line_evaluations: LineMatchEvaluationData[];
  tolerances_applied?: {
    price_tolerance_pct: number;
    tax_tolerance_inr: number;
    qty_tolerance_pct: number;
  };
  evaluated_at?: string;
}

export interface TriangulationData {
  invoice: any;
  vendor?: any;
  purchase_order?: any;
  goods_receipt_notes?: any[];
  matching_result?: MatchingResultData;
}

