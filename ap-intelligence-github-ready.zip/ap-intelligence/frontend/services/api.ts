// AP INTELLIGENCE — Typed Frontend API Client Service
// Connects to FastAPI Backend at http://localhost:8000/api/v1 (or via Next.js rewrite /api/v1)

import {
  KPISummary,
  Invoice,
  Vendor,
  ExceptionTicket,
  RiskAlert,
  ApprovalItem,
} from "@/types/finance";
import {
  mockKPISummary,
  mockRecentInvoices,
  mockExceptions,
  mockRiskAlerts,
  mockApprovals,
} from "@/lib/mock-data";

const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000/api/v1";

async function fetchJSON<T>(endpoint: string, fallback: T): Promise<T> {
  try {
    const res = await fetch(`${API_BASE_URL}${endpoint}`, {
      cache: "no-store",
    });
    if (!res.ok) {
      console.warn(`API call ${endpoint} returned status ${res.status}. Using fallback.`);
      return fallback;
    }
    return (await res.json()) as T;
  } catch (error) {
    console.warn(`API call to ${endpoint} failed. Using offline fallback.`, error);
    return fallback;
  }
}

export const APIService = {
  // 1. Executive Dashboard KPIs
  async getDashboardKPIs(): Promise<KPISummary> {
    try {
      const data = await fetchJSON<any>("/analytics/dashboard", null);
      if (!data) return mockKPISummary;
      return {
        totalInvoicesProcessed: data.total_invoices_processed ?? mockKPISummary.totalInvoicesProcessed,
        totalInvoiceValueINR: data.total_invoice_value_inr ?? mockKPISummary.totalInvoiceValueINR,
        totalOutstandingPayablesINR: data.total_outstanding_payables_inr ?? mockKPISummary.totalOutstandingPayablesINR,
        matchedInvoicesCount: data.matched_invoices_count ?? mockKPISummary.matchedInvoicesCount,
        matchingRatePercent: data.matching_rate_percent ?? mockKPISummary.matchingRatePercent,
        pendingApprovalsCount: data.pending_approvals_count ?? mockKPISummary.pendingApprovalsCount,
        exceptionCount: data.exception_count ?? mockKPISummary.exceptionCount,
        duplicateAlertsCount: data.duplicate_alerts_count ?? mockKPISummary.duplicateAlertsCount,
        overduePayablesINR: data.overdue_payables_inr ?? mockKPISummary.overduePayablesINR,
        avgProcessingTimeHours: data.avg_processing_time_hours ?? mockKPISummary.avgProcessingTimeHours,
        estimatedAnnualSavingsINR: data.estimated_annual_savings_inr ?? mockKPISummary.estimatedAnnualSavingsINR,
        straightThroughProcessingPercent: data.straight_through_processing_percent ?? mockKPISummary.straightThroughProcessingPercent,
      };
    } catch {
      return mockKPISummary;
    }
  },

  // 2. Invoices Master Ledger
  async getInvoices(): Promise<Invoice[]> {
    try {
      const raw = await fetchJSON<any[]>("/invoices", []);
      if (!raw || raw.length === 0) return mockRecentInvoices;

      return raw.map((item) => ({
        id: item.id,
        vendorId: item.vendor_id,
        vendorName: item.vendor_name || item.vendor_id,
        poReference: item.po_reference || "N/A",
        invoiceDate: item.invoice_date,
        dueDate: item.due_date,
        vendorGSTIN: item.vendor_gstin,
        recipientGSTIN: item.recipient_gstin,
        taxableValue: item.taxable_value_inr,
        cgst: item.cgst_amount_inr,
        sgst: item.sgst_amount_inr,
        igst: item.igst_amount_inr,
        totalAmount: item.total_amount_inr,
        status: item.status,
        matchStatus: item.match_status,
        extractionConfidence: item.extraction_confidence,
        documentId: item.document_id,
        ocrData: item.ocr_data,
        ocrDiscrepancies: item.ocr_discrepancies,
        lineItems: (item.items || []).map((li: any) => ({
          lineNumber: li.line_number,
          itemCode: li.item_code,
          description: li.description,
          hsnSac: li.hsn_sac_code,
          quantity: li.quantity,
          unitPrice: li.unit_price_inr,
          gstRate: li.gst_rate_percent,
          taxableAmount: li.taxable_amount_inr,
          totalAmount: li.total_line_amount_inr,
        })),
      }));
    } catch {
      return mockRecentInvoices;
    }
  },

  // 3. Vendors Master Data
  async getVendors(): Promise<Vendor[]> {
    const raw = await fetchJSON<any[]>("/vendors", []);
    if (!raw || raw.length === 0) return [];
    return raw.map((v) => ({
      id: v.id,
      name: v.name,
      gstin: v.gstin,
      stateCode: v.state_code,
      paymentTermsDays: v.payment_terms_days,
      riskCategory: v.risk_category,
      totalSpendYTD: v.total_spend_ytd_inr,
      outstandingPayables: 0,
      discrepancyRate: 2.1,
    }));
  },

  // 4. Purchase Orders
  async getPurchaseOrders(): Promise<any[]> {
    return await fetchJSON<any[]>("/purchase-orders", []);
  },

  // 5. Goods Receipt Notes
  async getGRNs(): Promise<any[]> {
    return await fetchJSON<any[]>("/grn", []);
  },

  // 6. Exception Workbench
  async getExceptions(): Promise<ExceptionTicket[]> {
    const raw = await fetchJSON<any[]>("/exceptions", []);
    if (!raw || raw.length === 0) return mockExceptions;
    return raw.map((e) => ({
      id: e.id,
      invoiceId: e.invoice_id,
      vendorName: e.vendor_name || "Supplier Partner",
      category: e.category,
      severity: e.severity,
      expectedValue: e.expected_value,
      actualValue: e.actual_value,
      financialImpactINR: e.financial_impact_inr,
      responsibleDepartment: e.responsible_department,
      status: e.status,
      createdAt: e.created_at ? e.created_at.substring(0, 16) : "2026-11-07",
    }));
  },

  // 7. Resolve Exception
  async resolveException(
    exceptionId: string,
    action: string,
    notes: string,
    adjustLiabilityINR: number = 0
  ): Promise<any> {
    const res = await fetch(`${API_BASE_URL}/exceptions/${exceptionId}/resolve`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action,
        resolution_notes: notes,
        adjust_liability_inr: adjustLiabilityINR,
      }),
    });
    return await res.json();
  },

  // 8. Approvals Queue
  async getApprovals(search?: string, status?: string): Promise<ApprovalItem[]> {
    let endpoint = "/approvals";
    const params = new URLSearchParams();
    if (search && search.trim()) params.append("search", search.trim());
    if (status && status !== "ALL") params.append("status", status);
    const qs = params.toString();
    if (qs) endpoint += `?${qs}`;

    const raw = await fetchJSON<any[] | null>(endpoint, null);
    if (raw === null || raw === undefined) {
      return mockApprovals;
    }
    return raw.map((a) => ({
      id: a.id,
      invoiceId: a.invoice_id,
      vendorName: a.vendor_name || "Partner Supplier",
      amountINR: a.amount_inr,
      requiredRole: a.required_role,
      matchStatus: a.match_status || "REQUIRES_HUMAN_REVIEW",
      status: a.status,
      submittedAt: a.created_at ? a.created_at.substring(0, 16) : "2026-11-07",
      blockingExceptionsCount: a.blocking_exceptions_count || 0,
    }));
  },

  // 9. Submit Approval Action (Approve / Reject / Hold)
  async submitApprovalAction(
    approvalId: string,
    action: "APPROVED" | "REJECTED" | "HELD",
    comments: string
  ): Promise<any> {
    const res = await fetch(`${API_BASE_URL}/approvals/${approvalId}/action`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, comments }),
    });
    return await res.json();
  },

  // 10. Finance AI Copilot Query
  async queryCopilot(query: string): Promise<any> {
    const res = await fetch(`${API_BASE_URL}/copilot/query`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query }),
    });
    return await res.json();
  },

  // 11. ROI Modeler
  async getROIModel(): Promise<any> {
    return await fetchJSON<any>("/analytics/roi-model", null);
  },

  // 12. Documents Repository & Upload
  async getDocuments(): Promise<any[]> {
    return await fetchJSON<any[]>("/documents", []);
  },

  async uploadDocument(file: File): Promise<any> {
    const formData = new FormData();
    formData.append("file", file);
    const res = await fetch(`${API_BASE_URL}/documents/upload`, {
      method: "POST",
      body: formData,
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.detail || `Upload failed with status ${res.status}`);
    }
    return await res.json();
  },

  // 13. Update & Correct Invoice Fields (Human-in-the-Loop review)
  async updateInvoice(invoiceId: string, payload: any): Promise<any> {
    const res = await fetch(`${API_BASE_URL}/invoices/${invoiceId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.detail || `Update failed with status ${res.status}`);
    }
    return await res.json();
  },

  // 14. Deterministic Invoice Validation
  async validateInvoice(invoiceId: string): Promise<any> {
    const res = await fetch(`${API_BASE_URL}/invoices/${invoiceId}/validate`, {
      method: "POST",
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.detail || `Validation call failed with status ${res.status}`);
    }
    return await res.json();
  },

  // 15. Single Document Preview Details
  async getDocument(documentId: string): Promise<any> {
    return await fetchJSON<any>(`/documents/${documentId}`, null);
  },

  // 16. Three-Way Matching Results List
  async getMatchingResults(matchStatus?: string): Promise<any[]> {
    const query = matchStatus ? `?match_status=${encodeURIComponent(matchStatus)}` : "";
    return await fetchJSON<any[]>(`/matching${query}`, []);
  },

  // 17. Triangulation Detail (Invoice + PO + Multi-GRNs + Matching Breakdown)
  async getTriangulationDetail(invoiceId: string): Promise<any> {
    return await fetchJSON<any>(`/matching/${invoiceId}`, null);
  },

  // 18. Trigger Deterministic 3-Way Match Evaluation for Invoice
  async evaluateMatching(
    invoiceId: string,
    tolerances?: {
      price_tolerance_pct?: number;
      qty_tolerance_pct?: number;
      tax_tolerance_inr?: number;
      classify_partial_receipt?: boolean;
    }
  ): Promise<any> {
    const res = await fetch(`${API_BASE_URL}/matching/evaluate/${invoiceId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(tolerances || {}),
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.detail || `Matching evaluation failed with status ${res.status}`);
    }
    return await res.json();
  },

  // 19. Batch Evaluate All Invoices
  async evaluateAllMatching(): Promise<any> {
    const res = await fetch(`${API_BASE_URL}/matching/evaluate-all`, {
      method: "POST",
    });
    return await res.json();
  },

  // 20. Single Purchase Order with Items & Status
  async getPurchaseOrder(poId: string): Promise<any> {
    return await fetchJSON<any>(`/purchase-orders/${poId}`, null);
  },

  // 21. GRNs Linked to a Purchase Order (Supporting Multi-GRN)
  async getGRNsForPO(poId: string): Promise<any[]> {
    return await fetchJSON<any[]>(`/grn/by-po/${poId}`, []);
  },

  // 22. Safe Human-in-the-Loop OCR-to-Ledger Reconciliation
  async reconcileInvoiceOCR(invoiceId: string, payload: any): Promise<any> {
    const res = await fetch(`${API_BASE_URL}/invoices/${invoiceId}/reconcile-ocr`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.detail || `Reconciliation failed with status ${res.status}`);
    }
    return await res.json();
  },
};
