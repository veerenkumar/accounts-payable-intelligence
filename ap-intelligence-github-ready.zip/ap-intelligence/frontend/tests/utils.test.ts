import { describe, it, expect } from "vitest";
import { formatINR, formatPercent, cn } from "../lib/utils";

describe("Financial Utility Functions", () => {
  it("formats Indian Rupee (INR) currency with correct commas and currency symbol", () => {
    const formatted = formatINR(246620);
    expect(formatted).toContain("2,46,620");
  });

  it("formats percentages accurately", () => {
    expect(formatPercent(78.234)).toBe("78.2%");
    expect(formatPercent(2.0)).toBe("2.0%");
  });

  it("handles clsx class merging properly", () => {
    const result = cn("text-white", true && "bg-navy-900", false && "hidden");
    expect(result).toBe("text-white bg-navy-900");
  });
});

