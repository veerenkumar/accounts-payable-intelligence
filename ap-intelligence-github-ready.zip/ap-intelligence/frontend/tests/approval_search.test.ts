import { describe, it, expect } from "vitest";
import { ApprovalItem } from "../types/finance";

describe("Approval Center Filtering & Control Rules", () => {
  const sampleApprovals: ApprovalItem[] = [
    {
      id: "APR-2026-0092",
      invoiceId: "INV-2026-00452",
      vendorName: "Larsen & Toubro Heavy Engg",
      amountINR: 246620,
      requiredRole: "FINANCE_EXECUTIVE",
      matchStatus: "MISSING_PO",
      status: "HELD",
      submittedAt: "2026-11-01 10:00",
      blockingExceptionsCount: 1,
    },
    {
      id: "APR-2026-0107",
      invoiceId: "INV-2026-00467",
      vendorName: "Tata Steel Products Ltd.",
      amountINR: 98648,
      requiredRole: "AP_MANAGER",
      matchStatus: "EXACT_MATCH",
      status: "PENDING",
      submittedAt: "2026-11-02 11:30",
      blockingExceptionsCount: 0,
    },
    {
      id: "APR-2026-0110",
      invoiceId: "INV-2026-00470",
      vendorName: "ABB India Power",
      amountINR: 1091500,
      requiredRole: "FINANCE_CONTROLLER",
      matchStatus: "EXACT_MATCH",
      status: "PENDING",
      submittedAt: "2026-11-03 14:00",
      blockingExceptionsCount: 0,
    },
  ];

  const filterApprovals = (items: ApprovalItem[], query: string, statusFilter: string = "ALL") => {
    return items.filter((appr) => {
      if (query.trim()) {
        const q = query.trim().toLowerCase();
        const matchesInvoice = appr.invoiceId.toLowerCase().includes(q);
        const matchesApproval = appr.id.toLowerCase().includes(q);
        const matchesVendor = (appr.vendorName || "").toLowerCase().includes(q);
        if (!matchesInvoice && !matchesApproval && !matchesVendor) return false;
      }
      if (statusFilter !== "ALL" && appr.status !== statusFilter) return false;
      return true;
    });
  };

  const isBlocked = (appr: ApprovalItem) => {
    const blockingStatuses = ["MISSING_PO", "MISSING_GRN", "DUPLICATE_INVOICE", "QUANTITY_MISMATCH"];
    return (appr.blockingExceptionsCount || 0) > 0 || blockingStatuses.includes(appr.matchStatus) || appr.status === "HELD";
  };

  it("filters accurately when searching for INV-2026-00452", () => {
    const results = filterApprovals(sampleApprovals, "INV-2026-00452");
    expect(results.length).toBe(1);
    expect(results[0].invoiceId).toBe("INV-2026-00452");
    expect(results[0].id).toBe("APR-2026-0092");
    expect(results.some((r) => r.invoiceId === "INV-2026-00470")).toBe(false);
  });

  it("filters accurately when searching by approval ID APR-2026-0092", () => {
    const results = filterApprovals(sampleApprovals, "APR-2026-0092");
    expect(results.length).toBe(1);
    expect(results[0].invoiceId).toBe("INV-2026-00452");
  });

  it("filters accurately by vendor name", () => {
    const results = filterApprovals(sampleApprovals, "Larsen & Toubro");
    expect(results.length).toBe(1);
    expect(results[0].invoiceId).toBe("INV-2026-00452");
  });

  it("returns empty array when search query matches no records", () => {
    const results = filterApprovals(sampleApprovals, "INV-DOES-NOT-EXIST");
    expect(results.length).toBe(0);
  });

  it("correctly identifies INV-2026-00452 as blocked due to MISSING_PO and HELD status", () => {
    const target = sampleApprovals.find((a) => a.invoiceId === "INV-2026-00452")!;
    expect(isBlocked(target)).toBe(true);
  });

  it("allows eligible exact match without open exceptions to proceed", () => {
    const eligible = sampleApprovals.find((a) => a.invoiceId === "INV-2026-00467")!;
    expect(isBlocked(eligible)).toBe(false);
  });
});

