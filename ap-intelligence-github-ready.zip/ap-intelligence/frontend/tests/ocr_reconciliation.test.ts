import { describe, it, expect } from "vitest";
import { Invoice } from "../types/finance";

describe("Invoice OCR vs Ledger Reconciliation Logic", () => {
  const sampleInvoiceWithDiscrepancies: Invoice = {
    id: "INV-2026-00452",
    vendorId: "VEND-002",
    vendorName: "Larsen & Toubro Heavy Engg",
    vendorGSTIN: "27AAACL0140P1ZH",
    poReference: "PO-2026-00101-AMENDED",
    invoiceDate: "2026-03-12",
    dueDate: "2026-04-11",
    taxableValue: 209000,
    cgst: 18810,
    sgst: 18810,
    igst: 0,
    totalAmount: 246620,
    status: "RECONCILIATION_REQUIRED",
    matchStatus: "MISSING_PO",
    extractionConfidence: 0.98,
    lineItems: [],
    documentId: "doc-tata-steel-pdf",
    ocrData: {
      invoice_number: "INV-2026-00452",
      vendor_name: "Tata Steel Products Ltd.",
      vendor_gstin: "27AAACT2727Q1ZW",
      po_reference: "PO-2026-00101",
      taxable_value: 209000,
      cgst_amount: 18810,
      sgst_amount: 18810,
      igst_amount: 0,
      total_amount: 246620,
    },
    ocrDiscrepancies: [
      {
        field: "vendor_name",
        label: "Supplier Name",
        ledger_value: "Larsen & Toubro Heavy Engg",
        ocr_value: "Tata Steel Products Ltd.",
        has_conflict: true,
        description: "Vendor mismatch",
      },
      {
        field: "vendor_gstin",
        label: "Supplier GSTIN",
        ledger_value: "27AAACL0140P1ZH",
        ocr_value: "27AAACT2727Q1ZW",
        has_conflict: true,
        description: "GSTIN mismatch",
      },
      {
        field: "po_reference",
        label: "PO Reference",
        ledger_value: "PO-2026-00101-AMENDED",
        ocr_value: "PO-2026-00101",
        has_conflict: true,
        description: "PO reference mismatch",
      },
      {
        field: "total_amount_inr",
        label: "Grand Total",
        ledger_value: 246620,
        ocr_value: 246620,
        has_conflict: false,
        description: "Total matches exactly",
      },
    ],
  };

  it("identifies active conflicts when ledger values differ from document OCR", () => {
    const conflicts = (sampleInvoiceWithDiscrepancies.ocrDiscrepancies || []).filter(
      (d) => d.has_conflict
    );
    expect(conflicts.length).toBe(3);
    const conflictingFields = conflicts.map((c) => c.field);
    expect(conflictingFields).toContain("vendor_name");
    expect(conflictingFields).toContain("vendor_gstin");
    expect(conflictingFields).toContain("po_reference");
  });

  it("safely fills review form without directly mutating the locked ledger row", () => {
    const initialForm = {
      vendorGSTIN: sampleInvoiceWithDiscrepancies.vendorGSTIN,
      poReference: sampleInvoiceWithDiscrepancies.poReference,
      totalAmount: sampleInvoiceWithDiscrepancies.totalAmount,
    };

    const ocr = sampleInvoiceWithDiscrepancies.ocrData!;
    const updatedForm = {
      ...initialForm,
      vendorGSTIN: ocr.vendor_gstin || initialForm.vendorGSTIN,
      poReference: ocr.po_reference || initialForm.poReference,
    };

    // Ledger row remains untouched
    expect(sampleInvoiceWithDiscrepancies.vendorGSTIN).toBe("27AAACL0140P1ZH");
    expect(sampleInvoiceWithDiscrepancies.poReference).toBe("PO-2026-00101-AMENDED");

    // Form is updated for human inspection
    expect(updatedForm.vendorGSTIN).toBe("27AAACT2727Q1ZW");
    expect(updatedForm.poReference).toBe("PO-2026-00101");
  });

  it("requires authorized human confirmation before approving reconciliation", () => {
    const isAuthorized = (role: string) =>
      ["AP_MANAGER", "FINANCE_CONTROLLER", "CFO", "ADMIN", "AUDITOR"].includes(role);

    expect(isAuthorized("JUNIOR_CLERK")).toBe(false);
    expect(isAuthorized("VENDOR")).toBe(false);
    expect(isAuthorized("AP_MANAGER")).toBe(true);
    expect(isAuthorized("CFO")).toBe(true);
  });
});

