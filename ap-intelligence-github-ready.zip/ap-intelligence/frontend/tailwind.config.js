/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./lib/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        navy: {
          950: "#070D1E",
          900: "#0B132B",
          850: "#111C3D",
          800: "#1C2541",
          700: "#273459",
          600: "#3A4B7C",
        },
        slate: {
          900: "#0F172A",
          800: "#1E293B",
          700: "#334155",
        },
        accent: {
          blue: "#3A86FF",
          cyan: "#48CAE4",
          emerald: "#10B981",
          amber: "#F59E0B",
          rose: "#EF4444",
          indigo: "#6366F1",
        },
      },
    },
  },
  plugins: [],
};

