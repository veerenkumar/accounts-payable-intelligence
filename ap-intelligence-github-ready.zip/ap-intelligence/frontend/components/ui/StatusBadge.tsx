import React from "react";
import { cn } from "@/lib/utils";
import { MatchStatus, InvoiceStatus } from "@/types/finance";

interface StatusBadgeProps {
  status: MatchStatus | InvoiceStatus | string;
  size?: "sm" | "md";
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({
  status,
  size = "md",
}) => {
  const getBadgeConfig = (s: string | null | undefined) => {
    const safeStatus = (s || "UNKNOWN").toString();
    switch (safeStatus) {
      case "EXACT_MATCH":
      case "MATCHED_EXACT":
      case "APPROVED":
      case "PAID":
        return {
          label: safeStatus.replace(/_/g, " "),
          classes: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
        };
      case "MATCH_WITHIN_TOLERANCE":
      case "MATCHED_TOLERANCE":
        return {
          label: "WITHIN TOLERANCE",
          classes: "bg-blue-500/15 text-blue-400 border-blue-500/30",
        };
      case "PARTIAL_RECEIPT":
        return {
          label: "PARTIAL RECEIPT",
          classes: "bg-cyan-500/15 text-cyan-400 border-cyan-500/30",
        };
      case "PENDING_APPROVAL":
      case "MATCHING":
        return {
          label: safeStatus.replace(/_/g, " "),
          classes: "bg-amber-500/15 text-amber-400 border-amber-500/30",
        };
      case "EXCEPTION_HOLD":
      case "QUANTITY_MISMATCH":
      case "PRICE_MISMATCH":
      case "TAX_MISMATCH":
      case "VENDOR_MISMATCH":
      case "REJECTED":
        return {
          label: safeStatus.replace(/_/g, " "),
          classes: "bg-rose-500/15 text-rose-400 border-rose-500/30",
        };
      case "DUPLICATE_INVOICE":
        return {
          label: "DUPLICATE ALERT",
          classes: "bg-purple-500/20 text-purple-400 border-purple-500/40",
        };
      default:
        return {
          label: safeStatus.replace(/_/g, " "),
          classes: "bg-slate-500/15 text-slate-300 border-slate-500/30",
        };
    }
  };

  const config = getBadgeConfig(status);

  return (
    <span
      className={cn(
        "inline-flex items-center font-medium font-mono uppercase border rounded-md tracking-wider",
        size === "sm" ? "px-2 py-0.5 text-[10px]" : "px-2.5 py-1 text-xs",
        config.classes
      )}
    >
      <span className="w-1.5 h-1.5 rounded-full mr-1.5 bg-current opacity-80" />
      {config.label}
    </span>
  );
};

