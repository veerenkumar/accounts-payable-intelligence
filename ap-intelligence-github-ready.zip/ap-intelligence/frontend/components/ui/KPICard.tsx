import React from "react";
import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

interface KPICardProps {
  title: string;
  value: string;
  subtitle?: string;
  icon: LucideIcon;
  trend?: {
    value: string;
    isPositive?: boolean;
    isNeutral?: boolean;
  };
  variant?: "default" | "accent" | "warning" | "danger" | "success";
}

export const KPICard: React.FC<KPICardProps> = ({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  variant = "default",
}) => {
  const borderStyles = {
    default: "border-navy-700/60 hover:border-navy-600",
    accent: "border-accent-blue/30 hover:border-accent-blue/60",
    warning: "border-accent-amber/30 hover:border-accent-amber/60",
    danger: "border-accent-rose/30 hover:border-accent-rose/60",
    success: "border-accent-emerald/30 hover:border-accent-emerald/60",
  }[variant];

  const iconStyles = {
    default: "text-slate-400 bg-navy-800",
    accent: "text-accent-cyan bg-accent-blue/10",
    warning: "text-accent-amber bg-accent-amber/10",
    danger: "text-accent-rose bg-accent-rose/10",
    success: "text-accent-emerald bg-accent-emerald/10",
  }[variant];

  return (
    <div
      className={cn(
        "bg-navy-900/90 backdrop-blur-sm rounded-xl p-5 border transition-all duration-200 shadow-lg shadow-black/20",
        borderStyles
      )}
    >
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs font-medium uppercase tracking-wider text-slate-400">
          {title}
        </span>
        <div className={cn("p-2 rounded-lg", iconStyles)}>
          <Icon className="w-4 h-4" />
        </div>
      </div>

      <div className="space-y-1">
        <div className="text-2xl font-bold tracking-tight text-white font-mono">
          {value}
        </div>
        {(subtitle || trend) && (
          <div className="flex items-center space-x-2 text-xs">
            {trend && (
              <span
                className={cn(
                  "font-medium",
                  trend.isNeutral
                    ? "text-slate-400"
                    : trend.isPositive
                    ? "text-accent-emerald"
                    : "text-accent-rose"
                )}
              >
                {trend.value}
              </span>
            )}
            {subtitle && <span className="text-slate-400">{subtitle}</span>}
          </div>
        )}
      </div>
    </div>
  );
};

