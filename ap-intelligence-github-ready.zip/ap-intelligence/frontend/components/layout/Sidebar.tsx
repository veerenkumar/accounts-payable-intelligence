"use client";

import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Wallet,
  Receipt,
  FolderOpen,
  FileSpreadsheet,
  PackageCheck,
  GitCompare,
  AlertTriangle,
  ShieldAlert,
  Building2,
  CheckCircle2,
  Bot,
  TrendingUp,
  FileCheck,
  Cpu,
  Settings,
} from "lucide-react";

const navigationItems = [
  { name: "Executive Dashboard", href: "/", icon: LayoutDashboard },
  { name: "Accounts Payable", href: "/payables", icon: Wallet },
  { name: "Invoice Intelligence", href: "/invoices", icon: Receipt },
  { name: "Document Center", href: "/documents", icon: FolderOpen },
  { name: "Purchase Orders", href: "/purchase-orders", icon: FileSpreadsheet },
  { name: "Goods Receipt Notes", href: "/grn", icon: PackageCheck },
  { name: "Three-Way Matching", href: "/matching", icon: GitCompare },
  { name: "Exception Workbench", href: "/exceptions", icon: AlertTriangle },
  { name: "Fraud & Risk Detection", href: "/fraud-risk", icon: ShieldAlert },
  { name: "Vendor Management", href: "/vendors", icon: Building2 },
  { name: "Approval Center", href: "/approvals", icon: CheckCircle2 },
  { name: "Finance AI Copilot", href: "/copilot", icon: Bot },
  { name: "Financial Analytics", href: "/analytics", icon: TrendingUp },
  { name: "Audit & Compliance", href: "/audit", icon: FileCheck },
  { name: "AI Agent Control Center", href: "/agent-control", icon: Cpu },
  { name: "Settings", href: "/settings", icon: Settings },
];

export const Sidebar: React.FC = () => {
  const pathname = usePathname();

  return (
    <aside className="w-64 bg-navy-900 border-r border-navy-800 flex flex-col h-screen fixed left-0 top-0 z-40">
      {/* Brand Header */}
      <div className="h-16 flex items-center px-6 border-b border-navy-800 bg-navy-950/60">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-accent-blue to-accent-cyan flex items-center justify-center shadow-md shadow-accent-blue/20">
            <Receipt className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-white tracking-wide">
              AP INTELLIGENCE
            </h1>
            <p className="text-[10px] text-accent-cyan/80 font-mono tracking-tighter">
              AGENTIC 3-WAY MATCH
            </p>
          </div>
        </div>
      </div>

      {/* Nav List */}
      <div className="flex-1 overflow-y-auto py-3 px-3 space-y-1">
        <div className="px-3 pb-2 text-[10px] font-semibold tracking-wider text-slate-400 uppercase">
          Finance Operations
        </div>
        {navigationItems.map((item) => {
          const isActive = pathname === item.href;
          const Icon = item.icon;
          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                "flex items-center space-x-3 px-3 py-2 rounded-lg text-xs font-medium transition-all duration-150",
                isActive
                  ? "bg-accent-blue/15 text-accent-cyan border border-accent-blue/30 shadow-sm"
                  : "text-slate-300 hover:text-white hover:bg-navy-800/80"
              )}
            >
              <Icon
                className={cn(
                  "w-4 h-4 transition-colors",
                  isActive ? "text-accent-cyan" : "text-slate-400"
                )}
              />
              <span className="truncate">{item.name}</span>
            </Link>
          );
        })}
      </div>

      {/* Academic Context Badge */}
      <div className="p-4 border-t border-navy-800 bg-navy-950/40">
        <div className="p-2.5 rounded-lg bg-navy-800/60 border border-navy-700/60 text-[11px] space-y-1">
          <div className="font-semibold text-white">MBA Finance — Group 3</div>
          <div className="text-slate-400 text-[10px]">
            Lead: Veeren Kumar Konchada
          </div>
          <div className="text-accent-emerald text-[10px] flex items-center pt-0.5">
            <span className="w-1.5 h-1.5 rounded-full bg-accent-emerald mr-1.5 animate-pulse" />
            Agent Supervisor Online
          </div>
        </div>
      </div>
    </aside>
  );
};

