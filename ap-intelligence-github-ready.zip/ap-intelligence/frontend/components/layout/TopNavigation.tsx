"use client";

import React, { useState, useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";
import { Search, Bell, Shield, Calendar, X } from "lucide-react";

export const TopNavigation: React.FC = () => {
  const router = useRouter();
  const pathname = usePathname();
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    if (typeof window !== "undefined") {
      const q = new URLSearchParams(window.location.search).get("search");
      if (q !== null) {
        setSearchQuery(q);
      }
    }
  }, [pathname]);

  const handleSearchChange = (value: string) => {
    setSearchQuery(value);
    if (typeof window !== "undefined") {
      window.dispatchEvent(new CustomEvent("ap-global-search", { detail: value }));
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      if (typeof window !== "undefined") {
        window.dispatchEvent(new CustomEvent("ap-global-search", { detail: searchQuery }));
      }
      if (pathname === "/approvals" || pathname === "/exceptions" || pathname === "/invoices") {
        router.push(`${pathname}?search=${encodeURIComponent(searchQuery)}`);
      } else {
        router.push(`/approvals?search=${encodeURIComponent(searchQuery)}`);
      }
    }
  };

  const currentDate = new Date().toLocaleDateString("en-IN", {
    weekday: "short",
    year: "numeric",
    month: "short",
    day: "numeric",
  });

  return (
    <header className="h-16 bg-navy-900/90 backdrop-blur-md border-b border-navy-800 sticky top-0 z-30 flex items-center justify-between px-8">
      {/* Search Input */}
      <div className="flex items-center w-96">
        <div className="relative w-full">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => handleSearchChange(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Search invoice number, PO, vendor GSTIN, or exception..."
            className="w-full bg-navy-950/80 border border-navy-700/80 rounded-lg pl-9 pr-8 py-1.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-accent-blue/60 transition-colors"
          />
          {searchQuery && (
            <button
              onClick={() => handleSearchChange("")}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Right Controls */}
      <div className="flex items-center space-x-5">
        {/* Date Display */}
        <div className="hidden lg:flex items-center space-x-2 text-xs text-slate-300 font-mono bg-navy-800/60 px-3 py-1.5 rounded-md border border-navy-700/40">
          <Calendar className="w-3.5 h-3.5 text-accent-cyan" />
          <span>{currentDate}</span>
        </div>

        {/* Corporate Entity */}
        <div className="text-right hidden sm:block">
          <div className="text-xs font-semibold text-white">
            Apex Bharat Mfg. Pvt. Ltd.
          </div>
          <div className="text-[10px] text-slate-400 font-mono">
            GSTIN: 27AABCA9876K1Z5
          </div>
        </div>

        {/* Notifications */}
        <button
          title="Notifications"
          className="relative p-2 rounded-lg bg-navy-800/80 border border-navy-700 text-slate-300 hover:text-white transition-colors"
        >
          <Bell className="w-4 h-4" />
          <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-accent-rose rounded-full ring-2 ring-navy-900" />
        </button>

        {/* User Profile Pill */}
        <div className="flex items-center space-x-3 pl-2 border-l border-navy-800">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-accent-blue flex items-center justify-center text-xs font-bold text-white shadow">
            VK
          </div>
          <div className="text-left">
            <div className="text-xs font-medium text-white flex items-center space-x-1.5">
              <span>Veeren Kumar</span>
              <Shield className="w-3 h-3 text-accent-cyan" />
            </div>
            <div className="text-[10px] text-accent-cyan/90 font-mono font-medium">
              FINANCE CONTROLLER
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

