# AP INTELLIGENCE
> **Agentic AI Solution for Accounts Payable Invoice Processing and Automated 3-Way Matching**  
> **Academic Programme**: MBA Finance | **Course**: Agentic AI for Business Operations  
> **Project Owner & Primary Developer**: Veeren Kumar Konchada  
> **Tagline**: *"Intelligent Finance. Accurate Decisions. Controlled Automation."*

---

## 1. Project Overview & Business Problem

Traditional Accounts Payable (AP) departments in mid-to-large enterprises face critical operational vulnerabilities:
1. **Manual Data Entry Bottlenecks**: Finance executives manually transcribe paper and PDF invoices, creating processing cycles of 8–15 days and labor costs exceeding ₹450–₹750 per invoice.
2. **Reconciliation Inaccuracies**: Discrepancies between Supplier Invoices, Purchase Orders (POs), and Goods Receipt Notes (GRNs) often pass unnoticed or cause prolonged payment disputes.
3. **Duplicate Payments & Fraud Risk**: Lack of cross-vendor duplicate checks and collision safeguards leads to unintended double payments or payment against unapproved supplier amendments.
4. **Weak Compliance & Audit Trails**: Statutory Indian GST reconciliation (CGST/SGST/IGST), Delegation of Authority (DOA) compliance, and immutable audit logs are challenging to maintain manually.

**AP INTELLIGENCE** solves these challenges by combining a **deterministic financial matching engine** with a **specialized multi-agent system**. While AI agents automate unstructured document extraction, anomaly detection, and exception proposals, all financial balances, GST arithmetic, and payment authorizations are enforced by deterministic code and human-in-the-loop (HITL) authorization gates.

---

## 2. System Architecture

The platform is designed around a dual-layer architecture separating **probabilistic document intelligence** from **deterministic financial controls**:

```mermaid
flowchart TD
    subgraph Ingestion["1. Document Ingestion Layer"]
        PDF["PDF / Image Supplier Invoices"] --> DocParser["DocumentParser (PyMuPDF / OCR)"]
        DocParser --> DocStore[("documents Table<br/>• Raw OCR Text<br/>• Confidence Score")]
    end

    subgraph AgentNetwork["2. Eight-Agent Supervisory Network"]
        DocStore --> A1["Agent 1: Invoice Intelligence"]
        A1 --> A2["Agent 2: PO Analysis"]
        A2 --> A3["Agent 3: GRN Verification"]
        A3 --> A4["Agent 4: 3-Way Matching"]
        A4 --> A5["Agent 5: Fraud & Anomaly Detection"]
        A5 --> A6["Agent 6: Exception Resolution"]
        A6 --> A7["Agent 7: Approval Management"]
        A7 --> A8["Agent 8: Finance Analytics & Copilot"]
    end

    subgraph DeterministicEngine["3. Deterministic Ledger & Rules Engine"]
        A4 --> MatchingCore["Deterministic 3-Way Matcher<br/>• Zero Tolerance Price/Qty Policies<br/>• Multi-GRN Aggregation<br/>• Intra/Inter-State GST Validation"]
        MatchingCore --> ERPDatabase[("SQLite / PostgreSQL Ledger<br/>• invoices<br/>• purchase_orders<br/>• goods_receipt_notes<br/>• matching_results<br/>• exceptions<br/>• approval_requests<br/>• audit_logs")]
    end

    subgraph Presentation["4. Enterprise Frontend (Next.js 14)"]
        ERPDatabase --> UI["AP Executive Dashboard<br/>• Invoice Ledger & Side-by-Side OCR Modal<br/>• 3-Way Triangulation Workbench<br/>• Exception Workbench & Approval Center"]
    end
```

---

## 3. Technology Stack

- **Frontend Application**:
  - Framework: Next.js 14 (App Router), React 18, TypeScript 5
  - Styling: Tailwind CSS, Lucide Icons, Recharts (Dark Navy Financial SaaS Theme)
  - Testing: Vitest 1.4
- **Backend Application**:
  - Framework: FastAPI (Python 3.11 / 3.12)
  - Data Models: Pydantic v2
  - ORM & Persistence: SQLAlchemy 2.0 with SQLite 3 (Production-ready for PostgreSQL 16)
  - Testing: Pytest 9.2 with AnyIO
- **Document Processing**:
  - Extraction: PyMuPDF (fitz), Tesseract OCR engine fallback
  - Tax Engine: Indian GST Rules (Intra-state CGST+SGST vs Inter-state IGST)
- **Agent Orchestration**:
  - LangGraph Supervisor-Worker architecture with deterministic fallback adapters

---

## 4. Eight-Agent Architecture & Responsibilities

The system divides operational tasks across eight specialized agents orchestrated by a supervisor workflow:

| Agent | Module / Class | Primary Responsibilities |
|---|---|---|
| **1. Invoice Intelligence Agent** | `run_invoice_intelligence` | Ingests PDF/PNG/JPG files; extracts raw text; parses line items, HSN/SAC codes, and GSTIN; validates format and arithmetic checksums. |
| **2. Purchase Order Analysis Agent** | `run_po_analysis` | Queries ERP purchase orders; validates supplier references; checks committed budgets, item specifications, and line quantities. |
| **3. GRN Verification Agent** | `run_grn_verification` | Reconciles warehouse receipts; aggregates partial deliveries; compares received and accepted quantities against damaged/rejected goods. |
| **4. Three-Way Matching Agent** | `run_three_way_match` | Executes deterministic 3-way matching ($Invoice \leftrightarrow PO \leftrightarrow GRN$) against configurable price (e.g. 2%) and quantity (0%) tolerance thresholds. |
| **5. Fraud & Duplicate Detection Agent** | `run_fraud_and_duplicate_detection` | Detects cross-vendor invoice collisions, duplicate billing attempts, Benford's Law distribution anomalies, and rapid unit price escalations. |
| **6. Exception Resolution Agent** | `run_exception_resolution` | Categorizes matching failures (`MISSING_PO`, `PRICE_MISMATCH`, `QUANTITY_MISMATCH`, `TAX_MISMATCH`), quantifies financial impact, and drafts debit notes. |
| **7. Approval Management Agent** | `run_approval_management` | Enforces Delegation of Authority (DOA) monetary tiers (<₹1L, <₹10L, ≥₹10L) and strictly blocks approval for invoices with open blocking exceptions. |
| **8. Finance Analytics & Copilot Agent** | `run_finance_analytics` | Tracks Straight-Through Processing (STP) rates, Days Payable Outstanding (DPO), working capital impact, and answers financial queries via NL Copilot. |

---

## 5. Installation & Execution Instructions

### Prerequisites
- Python 3.11+ or 3.12+
- Node.js 18+ or 20+ (tested on Node v20.20.2)
- npm 9+ or 10+

### Step 1: Clone Repository
```bash
git clone <repository_url>
cd ap-intelligence
```

### Step 2: Backend Setup
```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Start FastAPI server on port 8000
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```
Backend API will be live at `http://localhost:8000`. Swagger documentation available at `http://localhost:8000/docs`.

### Step 3: Frontend Setup
In a separate terminal window:
```bash
cd frontend
npm install

# Start Next.js development server on port 3000
npm run dev
```
Access the AP Intelligence Executive Dashboard at `http://localhost:3000`.

---

## 6. Environment Variables & API Configuration

Create a `.env` file in `backend/` (or copy from `.env.example`):

```bash
# Backend Configuration (.env)
APP_NAME="AP Intelligence"
APP_ENV="development"
DEBUG=True
PORT=8000
HOST="0.0.0.0"

# Database Configuration (Defaults to local SQLite)
DATABASE_URL="sqlite:///./ap_intelligence.db"

# LLM & Multi-Agent Keys (Optional - Local deterministic fallbacks included)
GEMINI_API_KEY=""
OPENAI_API_KEY=""

# Security & CORS
SECRET_KEY="ap-intelligence-super-secret-key-change-in-production"
ALLOWED_ORIGINS="http://localhost:3000,http://127.0.0.1:3000"
```

Frontend configuration in `frontend/next.config.js` automatically proxies `/api/v1/*` requests to `http://localhost:8000/api/v1/*`.

---

## 7. Database Structure & Entity Relationships

The relational schema is defined in `backend/app/models/financial_entities.py`:

```mermaid
erDiagram
    VENDORS ||--o{ PURCHASE_ORDERS : "issues"
    VENDORS ||--o{ INVOICES : "submits"
    PURCHASE_ORDERS ||--o{ PO_ITEMS : "contains"
    PURCHASE_ORDERS ||--o{ GOODS_RECEIPT_NOTES : "fulfills"
    PURCHASE_ORDERS ||--o{ INVOICES : "billed_against"
    GOODS_RECEIPT_NOTES ||--o{ GRN_ITEMS : "contains"
    INVOICES ||--o{ INVOICE_ITEMS : "contains"
    INVOICES ||--o| MATCHING_RESULTS : "evaluates"
    INVOICES ||--o{ EXCEPTIONS : "triggers"
    INVOICES ||--o{ APPROVAL_REQUESTS : "routes"
    DOCUMENTS ||--o| INVOICES : "attached_to"
    USERS ||--o{ APPROVAL_REQUESTS : "authorizes"
```

Key Tables:
- `vendors`: Supplier master data, GSTIN, PAN, state code, risk category.
- `purchase_orders` & `po_items`: Approved PO headers and line-item schedules.
- `goods_receipt_notes` & `grn_items`: Warehouse delivery challans and accepted quantities.
- `invoices` & `invoice_items`: Ingested supplier invoices, tax details, and matching status.
- `documents`: Binary file references, OCR raw text streams, and extraction confidence telemetry.
- `matching_results`: Comprehensive 3-way matching verdicts, price/quantity variance metrics.
- `exceptions`: Discrepancy tracking with root causes and exposure valuations.
- `approval_requests`: Tiered authorization records with Delegation of Authority limits.
- `audit_logs`: Append-only, tamper-evident chronological event log capturing before/after states.

---

## 8. Testing Instructions

The platform includes full automated test coverage across unit, integration, and E2E suites:

### Run Backend Tests (95 Tests across 15 Modules)
```bash
cd backend
source venv/bin/activate
pytest -v
```
*Expected Result*: **95 passed in ~3.9s**.

Key test modules include:
- `tests/test_15_scenarios.py`: Validates 15 end-to-end business scenarios (exact match, quantity mismatch, price mismatch, duplicate invoice, vendor mismatch, over/under receipt).
- `tests/test_ocr_ledger_reconciliation.py`: Validates side-by-side OCR conflict detection, role authorization checks, and audit logging.
- `tests/test_cross_vendor_collision_controls.py`: Tests duplicate invoice number collisions across distinct vendors and fulfilled PO overbilling protection.
- `tests/test_final_e2e_system_validation.py`: Tests full lifecycle, GST arithmetic, and dashboard KPI zero-variance reconciliation.

### Run Frontend Unit Tests (12 Tests)
```bash
cd frontend
npm test
```
*Expected Result*: **12 passed across 3 test files**.

### Run Next.js Production Build
```bash
cd frontend
npm run build
```
*Expected Result*: **Compiled successfully; 19 static routes generated with zero errors**.

---

## 9. Known Limitations

In the spirit of honest academic evaluation, the following operational boundaries are noted:
1. **Invoice Number Scoping**: The primary key for invoices currently relies on a unique invoice identifier string. While cross-vendor duplicate collision detection is implemented, a multi-tenant enterprise deployment should adopt a composite primary key `(vendor_id, invoice_number, financial_year)`.
2. **Local OCR vs Handwritten Documents**: Extraction achieves >95% accuracy on printed PDF and vector invoices. Severely degraded mobile scans or handwritten challans require human correction via the Review Modal.
3. **Deterministic Local Fallback**: When external LLM API keys (`GEMINI_API_KEY`) are omitted, the copilot and reasoning agents gracefully fall back to local rule-based and template-driven responses rather than dynamic generative synthesis.
4. **ERP Connectors**: Current integration utilizes REST API endpoints and SQLite/PostgreSQL schemas. Direct proprietary connectors (SAP RFC, Oracle BAPI) are modeled via standard data contracts rather than live proprietary protocols.
