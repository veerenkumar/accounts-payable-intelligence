# System Architecture & Technical Specification
## AP INTELLIGENCE: Agentic AI-Powered Accounts Payable & 3-Way Match Platform
**Academic Programme**: MBA Finance | Course: Agentic AI for Business Operations  
**Project Owner**: Veeren Kumar Konchada | Academic Project Group 3

---

## 1. Executive Summary & Design Principles

**AP INTELLIGENCE** is an enterprise-grade financial automation and intelligent reconciliation platform designed to transform corporate Accounts Payable (AP) workflows through deterministic financial controls augmented by specialized multi-agent AI.

### Core Architectural Pillars
1. **Deterministic Financial Invariance**: No Generative AI model performs financial calculations or independently approves transactions. Reconciliation, tax calculations, and tolerance evaluations use strictly typed Python modules (`decimal.Decimal`).
2. **Supervisor-Worker Multi-Agent Architecture**: Built on **LangGraph**, isolating domain intelligence across 8 specialized agents with bounded scopes, structured Pydantic input/outputs, loop prevention, and token-cost awareness.
3. **Human-in-the-Loop (HITL) Checkpoints**: Tiered approval thresholds (Finance Executive, AP Manager, Financial Controller) ensuring zero real payment execution without authenticated human authorization.
4. **Explainable Risk & Anomaly Detection**: Strict distinction between heuristic/statistical anomaly alerts and confirmed fraud. Clear traceability and audit logging for every decision.
5. **Indian Statutory & Financial Compliance**: Comprehensive support for Indian Goods and Services Tax (GST) rules (CGST/SGST vs IGST, HSN/SAC codes, reverse charge flags) and alignment with the Digital Personal Data Protection (DPDP) Act, 2023.

---

## 2. High-Level Architecture Overview

```mermaid
graph TD
    subgraph Client Layer ["Client Layer (Next.js 14 / Tailwind / shadcn/ui)"]
        UI_Dash["Executive Dashboard & Analytics"]
        UI_Match["3-Way Match & Exception Workbench"]
        UI_Appr["Approval Center & Audit Trail"]
        UI_Chat["Finance AI Copilot"]
        UI_Doc["Document Center (Upload & Viewer)"]
    end

    subgraph API Gateway ["FastAPI Gateway (Port 8000)"]
        AUTH["Auth & RBAC Middleware"]
        AUDIT["Audit & Event Logger"]
        ROUTERS["REST API Endpoints (/api/v1)"]
    end

    subgraph MultiAgent Layer ["Multi-Agent Orchestrator (LangGraph)"]
        SUP["Supervisor Agent"]
        AG1["Invoice Intelligence Agent"]
        AG2["PO Analysis Agent"]
        AG3["GRN Verification Agent"]
        AG4["3-Way Matching Agent"]
        AG5["Fraud & Risk Agent"]
        AG6["Exception Resolution Agent"]
        AG7["Approval Management Agent"]
        AG8["Finance Analytics Agent"]
    end

    subgraph Engine Layer ["Deterministic Calculation & Rule Engines"]
        CALC["Deterministic Math Engine (decimal.Decimal)"]
        RULES["GST & Statutory Tax Validator"]
        TOL["Tolerance & Matching Rule Engine"]
    end

    subgraph Data & Storage Layer ["Persistence Layer"]
        PG[("PostgreSQL 16 + pgvector / SQLite Fallback")]
        DOC_STORE["Document Storage (/data/sample_documents)"]
    end

    Client Layer -->|HTTPS / JSON REST| API Gateway
    ROUTERS --> AUTH
    AUTH --> AUDIT
    ROUTERS --> MultiAgent Layer
    MultiAgent Layer --> Engine Layer
    MultiAgent Layer --> PG
    ROUTERS --> PG
    ROUTERS --> DOC_STORE
```

---

## 3. The Eight Specialized AI Agents

| # | Agent Name | Primary Business Purpose | Trigger & Input | Output / Deliverable | Tools Available |
|---|---|---|---|---|---|
| 1 | **Invoice Intelligence Agent** | Extract structured financial data from raw invoice docs (PDF/Images) | Document upload (PDF/Image path) | `InvoiceExtractionResult` (JSON, Line items, GST, Totals, Confidences) | OCR Parser, Document Classifier, Field Normalizer |
| 2 | **Purchase Order Analysis Agent** | Verify valid PO reference, committed budget, and line specifications | PO reference from Invoice | `POAnalysisResult` (Status, Item matching, Price limits, Validity) | PO Master Lookup, Budget Checker |
| 3 | **Goods Receipt Verification Agent** | Confirm physical receipt of items, verify accepted vs rejected quantity | PO reference / Delivery note | `GRNVerificationResult` (Delivered vs Accepted qty, Damaged items, Date) | GRN Ledger Lookup, Receipt Inspector |
| 4 | **Three-Way Matching Agent** | Reconcile PO, GRN, and Invoice against tolerance thresholds | Extracted data from Agents 1, 2, 3 | `MatchEvaluationResult` (Exact, Tolerance, Mismatch details, Variance %) | Deterministic Reconciliation Engine |
| 5 | **Fraud & Duplicate Detection Agent** | Detect repeated invoices, abnormal vendor volume, split invoices | Invoice header & line items | `FraudRiskAssessment` (Risk score 0-100, Flags, Historical delta) | Duplicate Invoice Checker, Vendor Anomaly Engine |
| 6 | **Exception Resolution Agent** | Categorize mismatches, assign accountability, propose remediation | Mismatched evaluation | `ExceptionRemediationPlan` (Root cause, Action plan, Department assign) | ERP Tolerance Advisor, Vendor Communication Drafter |
| 7 | **Approval Management Agent** | Enforce internal delegations of authority and routing policies | Validated match / Exception | `ApprovalRoutingDecision` (Required tier, Escalation deadlines) | Hierarchy Policy Engine, Notification Dispatcher |
| 8 | **Finance Analytics Agent** | Synthesize working capital, DPO, aging trends, and ROI metrics | Periodic / Copilot Query | `ExecutiveAnalyticsReport` (KPI values, Cash outflow forecasts) | Financial Ledger Aggregator, Cash Flow Forecaster |

---

## 4. Multi-Agent Orchestration & Sequence

```mermaid
sequenceDiagram
    autonumber
    actor User as AP Specialist / Vendor
    participant API as FastAPI Gateway
    participant Sup as Supervisor Agent
    participant InvAg as Invoice Intelligence Agent
    participant POAg as PO Analysis Agent
    participant GRNAg as GRN Verification Agent
    participant MatchAg as 3-Way Matching Agent
    participant RiskAg as Fraud & Risk Agent
    participant ExAg as Exception Resolution Agent
    participant ApprAg as Approval Agent
    participant DB as PostgreSQL Database

    User->>API: Upload Invoice (PDF/PNG)
    API->>DB: Save Document Record & File
    API->>Sup: Initiate Processing Workflow (document_id)
    
    rect rgb(25, 35, 60)
        Note over Sup,GRNAg: Document Processing & Extraction Stage
        Sup->>InvAg: Extract Invoice Fields
        InvAg-->>Sup: Extracted Invoice Data (Pydantic Schema)
        Sup->>POAg: Lookup & Validate PO Reference
        POAg-->>Sup: PO Master Data & Line Items
        Sup->>GRNAg: Fetch Linked Goods Receipt Notes
        GRNAg-->>Sup: GRN Accepted/Rejected Quantities
    end

    rect rgb(30, 45, 75)
        Note over Sup,RiskAg: Verification & Financial Reconciliation Stage
        Sup->>MatchAg: Execute 3-Way Match (Deterministic)
        MatchAg-->>Sup: Match Status (Exact / Within Tolerance / Mismatch)
        Sup->>RiskAg: Run Duplicate & Fraud Risk Evaluation
        RiskAg-->>Sup: Risk Score (0-100) & Triggered Indicators
    end

    alt Match Failed or High Risk Exception
        Sup->>ExAg: Classify Discrepancy & Root Cause
        ExAg-->>Sup: Exception Ticket Details & Remediation Plan
        Sup->>DB: Create Exception Record & Status = 'EXCEPTION_HOLD'
    else Match Passed & Risk Low
        Sup->>ApprAg: Route to Approval Hierarchy
        ApprAg-->>Sup: Assigned Approver (Exec/Mgr/Controller)
        Sup->>DB: Create Approval Request & Status = 'PENDING_APPROVAL'
    end

    Sup->>DB: Update Invoice Status & Audit Logs
    Sup-->>API: Complete Orchestration Run Result
    API-->>User: Return Processing Response & Real-Time Status
```

---

## 5. Security, Internal Controls, and Regulatory Alignment

1. **RBAC Matrix**:
   - `FINANCE_EXECUTIVE`: Upload docs, review low-value invoices (< ₹1,00,000), submit comments.
   - `AP_MANAGER`: Review mid-value invoices (< ₹10,00,000), resolve quantity/price exceptions, assign investigations.
   - `FINANCE_CONTROLLER`: Final approval on high-value invoices (>= ₹10,00,000), policy edits, risk overrides.
   - `ADMINISTRATOR`: User management, system configuration, audit export.
2. **Indian DPDP Act (2023) Compliance**: PII masking in logs (PAN numbers, bank accounts masked to last 4 digits), synthetic demonstration dataset guaranteeing zero privacy breaches.
3. **Statutory GST Validation**:
   - Format check: 15-character alphanumeric regex `^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$`.
   - Tax segregation: Intra-state (`CGST` + `SGST`) vs Inter-state (`IGST`).
   - Reverse charge mechanism (RCM) applicability flags.

