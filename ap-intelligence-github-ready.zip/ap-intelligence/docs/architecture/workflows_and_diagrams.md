# AP INTELLIGENCE — COMPREHENSIVE ARCHITECTURAL WORKFLOWS & DIAGRAMS

This document provides detailed visual and analytical documentation for the key subsystems of **AP Intelligence**.

---

## 1. System Architecture Diagram

```mermaid
flowchart TB
    subgraph Client["Presentation Layer (Client Browser)"]
        UI["Next.js 14 Enterprise Web App<br/>• Tailwind Dark Navy SaaS Design<br/>• Recharts Visual Analytics<br/>• Real-time Reconciliation & Search"]
    end

    subgraph Gateway["API & Routing Layer"]
        Proxy["Next.js Dynamic Proxy / Rewrites"]
        FastAPI["FastAPI REST Application Server (Port 8000)<br/>• CORS & Rate Limiting Middleware<br/>• Pydantic v2 Request/Response Validation"]
    end

    subgraph Agents["Multi-Agent Supervisory Orchestration Layer"]
        Supervisor["LangGraph Supervisor Orchestrator"]
        A1["Agent 1: Invoice Intelligence"]
        A2["Agent 2: PO Analysis"]
        A3["Agent 3: GRN Verification"]
        A4["Agent 4: 3-Way Matching Engine"]
        A5["Agent 5: Fraud & Anomaly Detector"]
        A6["Agent 6: Exception Resolution"]
        A7["Agent 7: Approval Manager"]
        A8["Agent 8: Finance Analytics & Copilot"]

        Supervisor --> A1 & A2 & A3 & A4 & A5 & A6 & A7 & A8
    end

    subgraph Engine["Deterministic Financial Logic Engine"]
        MatchingCore["Deterministic Triangulation Engine<br/>• Multi-GRN Aggregation<br/>• Zero Tolerance Price/Qty Rules<br/>• Indian GST Intra/Inter-State Engine"]
        DOAChecker["Delegation of Authority (DOA) Evaluator"]
        CollisionDetector["Cross-Vendor Duplicate & Collision Guard"]
    end

    subgraph Data["Persistence & Storage Layer"]
        DB[("Relational Database (SQLite / PostgreSQL 16)<br/>• Invoices & Invoice Items<br/>• Purchase Orders & Line Items<br/>• Goods Receipt Notes & Delivery Receipts<br/>• Exceptions & Approvals<br/>• Tamper-Evident Audit Logs")]
        DocStore["Document Artifact Repository<br/>• Uploaded Supplier PDFs & Images<br/>• Raw OCR Text Streams & Telemetry"]
    end

    UI <-->|HTTP / JSON| Proxy
    Proxy <-->|FastAPI Gateway| FastAPI
    FastAPI <--> Supervisor
    FastAPI <--> MatchingCore
    MatchingCore <--> DB
    A1 <--> DocStore
    FastAPI <--> DB
```

---

## 2. Multi-Agent Orchestration Workflow

The 8 specialized agents collaborate through a LangGraph state machine with deterministic gates:

```mermaid
sequenceDiagram
    autonumber
    participant SUP as LangGraph Supervisor
    participant A1 as Agent 1: Invoice Intelligence
    participant A2 as Agent 2: PO Analysis
    participant A3 as Agent 3: GRN Verification
    participant A4 as Agent 4: 3-Way Matcher
    participant A5 as Agent 5: Fraud & Anomaly
    participant A6 as Agent 6: Exception Resolution
    participant A7 as Agent 7: Approval Manager
    participant A8 as Agent 8: Analytics & Copilot

    SUP->>A1: Pass Document Stream (PDF/Image)
    A1->>A1: OCR Extraction & Indian GSTIN Validation
    A1-->>SUP: Return Extracted Invoice State

    SUP->>A2: Query ERP for PO Reference
    A2->>A2: Validate Vendor ID & Line Specifications
    A2-->>SUP: Return PO Items & Committed Quantities

    SUP->>A3: Query Warehouse for Linked GRNs
    A3->>A3: Aggregate Partial Delivery Receipts
    A3-->>SUP: Return Accepted vs Rejected Counts

    SUP->>A4: Trigger Deterministic Three-Way Match
    A4->>A4: Compute Line Price, Qty, & Tax Variances
    A4-->>SUP: Output Match Status (EXACT_MATCH or Exception)

    alt Match Failed or Discrepancy Found
        SUP->>A5: Evaluate Anomaly & Fraud Risk
        A5->>A5: Benford's Law & Duplicate Invoice Check
        A5-->>SUP: Risk Category & Severity
        SUP->>A6: Route to Exception Workbench
        A6->>A6: Classify Root Cause & Draft Debit Note
        A6-->>SUP: Open Exception Record Created
        SUP->>A7: Place on EXCEPTION_HOLD
    else Match Succeeded within Tolerance
        SUP->>A7: Route to Approval Queue
        A7->>A7: Check Monetary DOA Limits (<₹1L, <₹10L, ≥₹10L)
        A7-->>SUP: Pending Approval or Auto-Approved
    end

    SUP->>A8: Update STP Rates, DPO & Cash Forecast
```

---

## 3. Deterministic Three-Way Matching Workflow

Three-way matching executes deterministic comparisons between three authoritative sources:

```mermaid
flowchart TD
    Inv["Supplier Invoice<br/>(Billed Qty, Unit Price, GST)"]
    PO["Purchase Order<br/>(Ordered Qty, Agreed Rate, PO Total)"]
    GRN["Goods Receipt Notes<br/>(Received & Accepted Physical Qty)"]

    Inv & PO & GRN --> Matcher{"Deterministic Matching Engine"}

    Matcher --> Test1{"1. Vendor & Reference Match?"}
    Test1 -- No --> FailVendor["Status: VENDOR_MISMATCH / MISSING_PO<br/>Trigger Exception Workbench"]
    Test1 -- Yes --> Test2{"2. Quantity Check<br/>Billed Qty == Accepted Qty?"}

    Test2 -- Billed > Accepted --> FailQty["Status: QUANTITY_MISMATCH<br/>Exposure = (Billed - Accepted) * Price"]
    Test2 -- Agreed --> Test3{"3. Price Check<br/>|Inv Price - PO Price| / PO Price <= Tolerance (2%)?"}

    Test3 -- Variance > 2% --> FailPrice["Status: PRICE_MISMATCH<br/>Exposure = Price Variance * Qty"]
    Test3 -- Within 2% --> Test4{"4. Tax Arithmetic<br/>CGST/SGST/IGST matches POS & Taxable Rate?"}

    Test4 -- No --> FailTax["Status: TAX_MISMATCH<br/>Intra/Inter-State POS Conflict"]
    Test4 -- Yes --> PassMatch["Verdict: EXACT_MATCH or MATCH_WITHIN_TOLERANCE<br/>Route to Approval Center"]
```

---

## 4. OCR vs ERP Ledger Reconciliation Workflow

When an uploaded document artifact conflicts with the existing ERP ledger record (as identified during the investigation of `INV-2026-00452`):

```mermaid
flowchart TD
    Scanned["Uploaded Document Artifact<br/>(INV_2026_00452_TataSteel.pdf)"] --> OCR["OCR Text Extraction<br/>• Extracted: Tata Steel (VEND-001)<br/>• Extracted GSTIN: 27AAACT2727Q1ZW<br/>• Extracted PO: PO-2026-00101"]
    
    Ledger[("ERP Invoices Ledger<br/>• Recorded: L&T (VEND-002)<br/>• Recorded GSTIN: 27AAACL0140P1ZH<br/>• Recorded PO: PO-2026-00101-AMENDED")]
    
    OCR & Ledger --> DiffEngine["Field-by-Field Discrepancy Engine<br/>GET /api/v1/invoices/{id}"]
    
    DiffEngine --> UIModal["Review & Reconciliation Modal<br/>• Yellow Flag: ⚠️ OCR Conflict<br/>• Side-by-side Field Comparison Table<br/>• Action: 'Fill Form with OCR'"]

    UIModal --> Gate{"Authorized Human Sign-off?"}
    Gate -- No (Junior Clerk) --> Deny["HTTP 403 Forbidden<br/>Ledger Remains Untouched"]
    Gate -- Yes (AP Manager / CFO) --> ReconcileEndpoint["POST /api/v1/invoices/{id}/reconcile-ocr"]
    
    ReconcileEndpoint --> MasterValidation{"Validate Against Masters?<br/>• Vendor exists in vendors table?<br/>• PO exists in purchase_orders table?"}
    
    MasterValidation -- Invalid PO --> Reject["HTTP 400 Bad Request<br/>Prevent Broken Association"]
    MasterValidation -- Valid --> MutateLedger["Update Invoices Ledger Columns<br/>• vendor_id -> VEND-001<br/>• po_reference -> PO-2026-00101<br/>• document_id linked"]
    
    MutateLedger --> AuditTrail[("audit_logs Table<br/>• Action: HUMAN_CONFIRMED_OCR_RECONCILIATION<br/>• Actor ID, Timestamp, Old State vs New State")]
    MutateLedger --> Rematch["Re-execute Deterministic Match"]
```

---

## 5. Database Entity-Relationship (ER) Diagram

```mermaid
erDiagram
    VENDORS {
        string id PK
        string name
        string gstin
        string pan
        string state_code
        string risk_category
    }

    PURCHASE_ORDERS {
        string id PK
        string vendor_id FK
        date order_date
        decimal total_amount_inr
        string status
    }

    PO_ITEMS {
        string id PK
        string po_id FK
        int line_number
        string item_code
        decimal quantity
        decimal unit_price_inr
        decimal total_line_amount_inr
    }

    GOODS_RECEIPT_NOTES {
        string id PK
        string po_id FK
        string vendor_id FK
        date receipt_date
        string status
    }

    GRN_ITEMS {
        string id PK
        string grn_id FK
        string item_code
        decimal quantity_received
        decimal quantity_accepted
        decimal quantity_rejected
    }

    INVOICES {
        string id PK
        string vendor_id FK
        string po_reference FK
        string document_id FK
        date invoice_date
        string vendor_gstin
        decimal taxable_value_inr
        decimal total_tax_inr
        decimal total_amount_inr
        string status
        string match_status
        string payment_status
    }

    INVOICE_ITEMS {
        string id PK
        string invoice_id FK
        int line_number
        string item_code
        decimal quantity
        decimal unit_price_inr
        decimal total_line_amount_inr
    }

    MATCHING_RESULTS {
        string id PK
        string invoice_id FK
        string po_id FK
        string grn_id FK
        string match_status
        decimal total_financial_impact_inr
        boolean is_matched
    }

    EXCEPTIONS {
        string id PK
        string invoice_id FK
        string category
        string severity
        decimal financial_impact_inr
        string status
    }

    APPROVAL_REQUESTS {
        string id PK
        string invoice_id FK
        decimal amount_inr
        string required_role
        string status
    }

    AUDIT_LOGS {
        string id PK
        string entity_type
        string entity_id
        string action
        string actor_id
        json old_state
        json new_state
        datetime timestamp
    }

    DOCUMENTS {
        string id PK
        string file_name
        string file_path
        text ocr_raw_text
        decimal ocr_confidence_score
    }

    VENDORS ||--o{ PURCHASE_ORDERS : "issues"
    VENDORS ||--o{ INVOICES : "bills"
    PURCHASE_ORDERS ||--o{ PO_ITEMS : "has_lines"
    PURCHASE_ORDERS ||--o{ GOODS_RECEIPT_NOTES : "fulfilled_by"
    GOODS_RECEIPT_NOTES ||--o{ GRN_ITEMS : "receipt_lines"
    INVOICES ||--o{ INVOICE_ITEMS : "billed_lines"
    INVOICES ||--o| MATCHING_RESULTS : "evaluated_by"
    INVOICES ||--o{ EXCEPTIONS : "triggers"
    INVOICES ||--o{ APPROVAL_REQUESTS : "routes_to"
    DOCUMENTS ||--o| INVOICES : "supports"
```

---

## 6. Human Approval & Delegation of Authority (DOA) Workflow

```mermaid
flowchart TD
    MatchedInvoice["Invoice Evaluated by Matching Engine"] --> CheckBlock{"Any Blocking Exceptions?<br/>(MISSING_PO, DUPLICATE_INVOICE, QUANTITY_MISMATCH)"}

    CheckBlock -- Yes --> HeldState["Status: EXCEPTION_HOLD<br/>Approval Request: HELD<br/>(Approval Strictly Forbidden - 400 Bad Request)"]
    
    CheckBlock -- No --> EvaluateDOA{"Evaluate Total Amount against DOA Tiers"}

    EvaluateDOA -- "Amount <= ₹1,00,000" --> Tier1["Tier 1: Finance Executive<br/>Can approve directly"]
    EvaluateDOA -- "₹1,00,000 < Amount <= ₹10,00,000" --> Tier2["Tier 2: AP Manager<br/>Requires AP Manager sign-off"]
    EvaluateDOA -- "Amount > ₹10,00,000" --> Tier3["Tier 3: Finance Controller / CFO<br/>High-value authorization required"]

    Tier1 & Tier2 & Tier3 --> Action{"User Action in Approval Center"}
    
    Action -- "Approve (within authority)" --> ApprOK["Status: APPROVED<br/>Write AuditLog: APPROVAL_APPROVED<br/>Schedule for Payment Disbursement"]
    Action -- "Approve (exceeds role authority)" --> ApprDeny["HTTP 403 Forbidden<br/>'Authorization Ceiling Exceeded'"]
    Action -- "Hold / Request Info" --> ApprHold["Status: HELD<br/>Write AuditLog: APPROVAL_HELD"]
    Action -- "Reject" --> ApprReject["Status: REJECTED<br/>Write AuditLog: APPROVAL_REJECTED<br/>Notify Supplier via Notification Engine"]
```

