# Database Schema Design Specification
## AP INTELLIGENCE: PostgreSQL Normalized Schema with pgvector
**Dialect**: PostgreSQL 16 (Compatible with SQLite fallback for offline development)  
**ORM**: SQLAlchemy 2.0 + Alembic

---

## 1. Entity-Relationship Overview

```mermaid
erDiagram
    USERS ||--o{ APPROVAL_REQUESTS : approves
    USERS ||--o{ AUDIT_LOGS : performs
    ROLES ||--o{ USERS : assigned_to
    
    VENDORS ||--o{ PURCHASE_ORDERS : issues_to
    VENDORS ||--o{ INVOICES : bills_from
    VENDORS ||--o{ RISK_ALERTS : associates_with

    PURCHASE_ORDERS ||--|{ PO_ITEMS : contains
    PURCHASE_ORDERS ||--o{ GOODS_RECEIPT_NOTES : fulfills
    PURCHASE_ORDERS ||--o{ INVOICES : references

    GOODS_RECEIPT_NOTES ||--|{ GRN_ITEMS : contains
    GOODS_RECEIPT_NOTES ||--o{ MATCHING_RESULTS : reconciles

    DOCUMENTS ||--o{ INVOICES : extracted_to
    DOCUMENTS ||--o{ PURCHASE_ORDERS : attached_to
    DOCUMENTS ||--o{ GOODS_RECEIPT_NOTES : attached_to

    INVOICES ||--|{ INVOICE_ITEMS : contains
    INVOICES ||--o| MATCHING_RESULTS : evaluated_by
    INVOICES ||--o{ EXCEPTIONS : triggers
    INVOICES ||--o{ APPROVAL_REQUESTS : routes_to
    INVOICES ||--o{ RISK_ALERTS : flags

    MATCHING_RESULTS ||--o{ EXCEPTIONS : generates
    APPROVAL_REQUESTS ||--|{ APPROVAL_HISTORY : logs
```

---

## 2. Table Definitions & Data Dictionary

### Core Master Data Tables

#### `roles`
Stores authorization roles.
- `id`: VARCHAR(32) PRIMARY KEY (`ADMIN`, `FINANCE_CONTROLLER`, `AP_MANAGER`, `FINANCE_EXECUTIVE`)
- `name`: VARCHAR(64) NOT NULL
- `description`: TEXT
- `created_at`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP

#### `users`
System operators and approvers.
- `id`: UUID PRIMARY KEY DEFAULT gen_random_uuid()
- `role_id`: VARCHAR(32) NOT NULL REFERENCES roles(id)
- `email`: VARCHAR(255) UNIQUE NOT NULL
- `full_name`: VARCHAR(255) NOT NULL
- `department`: VARCHAR(100) DEFAULT 'Finance & Accounts'
- `approval_limit_inr`: NUMERIC(15, 2) DEFAULT 0.00
- `is_active`: BOOLEAN DEFAULT TRUE
- `created_at`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP

#### `vendors`
Supplier master profiles.
- `id`: VARCHAR(32) PRIMARY KEY (e.g. `VEND-IN-001`)
- `name`: VARCHAR(255) NOT NULL
- `gstin`: VARCHAR(15) NOT NULL
- `pan`: VARCHAR(10) NOT NULL
- `address`: TEXT NOT NULL
- `state_code`: VARCHAR(2) NOT NULL
- `contact_email`: VARCHAR(255) NOT NULL
- `contact_phone`: VARCHAR(32) NOT NULL
- `payment_terms_days`: INTEGER DEFAULT 30
- `bank_account_last4`: VARCHAR(4) NOT NULL
- `bank_ifsc`: VARCHAR(11) NOT NULL
- `risk_category`: VARCHAR(16) DEFAULT 'LOW' CHECK (risk_category IN ('LOW', 'MEDIUM', 'HIGH'))
- `total_spend_ytd_inr`: NUMERIC(15, 2) DEFAULT 0.00
- `created_at`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP

---

### Procurement & Receipts Data Tables

#### `purchase_orders`
Approved purchase commitments.
- `id`: VARCHAR(32) PRIMARY KEY (e.g. `PO-2026-00101`)
- `vendor_id`: VARCHAR(32) NOT NULL REFERENCES vendors(id)
- `po_date`: DATE NOT NULL
- `delivery_due_date`: DATE NOT NULL
- `currency`: VARCHAR(3) DEFAULT 'INR'
- `subtotal_inr`: NUMERIC(15, 2) NOT NULL
- `tax_amount_inr`: NUMERIC(15, 2) NOT NULL
- `total_amount_inr`: NUMERIC(15, 2) NOT NULL
- `status`: VARCHAR(32) DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'PARTIALLY_FULFILLED', 'FULFILLED', 'CLOSED', 'CANCELLED'))
- `payment_terms`: VARCHAR(64) DEFAULT 'Net 30'
- `created_at`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP

#### `po_items`
Line items within a purchase order.
- `id`: UUID PRIMARY KEY DEFAULT gen_random_uuid()
- `po_id`: VARCHAR(32) NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE
- `line_number`: INTEGER NOT NULL
- `item_code`: VARCHAR(64) NOT NULL
- `description`: TEXT NOT NULL
- `hsn_sac_code`: VARCHAR(16) NOT NULL
- `quantity`: NUMERIC(12, 3) NOT NULL
- `unit_price_inr`: NUMERIC(15, 2) NOT NULL
- `gst_rate_percent`: NUMERIC(5, 2) NOT NULL
- `taxable_amount_inr`: NUMERIC(15, 2) NOT NULL
- `total_line_amount_inr`: NUMERIC(15, 2) NOT NULL

#### `goods_receipt_notes` (GRN)
Physical or service delivery receipts.
- `id`: VARCHAR(32) PRIMARY KEY (e.g. `GRN-2026-00085`)
- `po_id`: VARCHAR(32) NOT NULL REFERENCES purchase_orders(id)
- `vendor_id`: VARCHAR(32) NOT NULL REFERENCES vendors(id)
- `receipt_date`: DATE NOT NULL
- `delivery_challan_no`: VARCHAR(64)
- `received_by_user`: VARCHAR(100) NOT NULL
- `warehouse_location`: VARCHAR(100) DEFAULT 'Main Central Warehouse'
- `status`: VARCHAR(32) DEFAULT 'ACCEPTED' CHECK (status IN ('ACCEPTED', 'PARTIALLY_ACCEPTED', 'REJECTED'))
- `created_at`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP

#### `grn_items`
Delivered item verification.
- `id`: UUID PRIMARY KEY DEFAULT gen_random_uuid()
- `grn_id`: VARCHAR(32) NOT NULL REFERENCES goods_receipt_notes(id) ON DELETE CASCADE
- `item_code`: VARCHAR(64) NOT NULL
- `quantity_received`: NUMERIC(12, 3) NOT NULL
- `quantity_accepted`: NUMERIC(12, 3) NOT NULL
- `quantity_rejected`: NUMERIC(12, 3) DEFAULT 0.000
- `rejection_reason`: TEXT

---

### Invoicing & 3-Way Reconciliation Tables

#### `documents`
Uploaded digital artifacts (Invoices, PO copies, GRN receipts).
- `id`: UUID PRIMARY KEY DEFAULT gen_random_uuid()
- `file_name`: VARCHAR(255) NOT NULL
- `file_path`: VARCHAR(512) NOT NULL
- `file_size_bytes`: INTEGER NOT NULL
- `mime_type`: VARCHAR(64) NOT NULL
- `document_type`: VARCHAR(32) NOT NULL CHECK (document_type IN ('INVOICE', 'PO', 'GRN', 'SUPPORTING'))
- `ocr_raw_text`: TEXT
- `ocr_confidence_score`: NUMERIC(5, 4)
- `uploaded_at`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP

#### `invoices`
Supplier claims for payment.
- `id`: VARCHAR(64) PRIMARY KEY (e.g. `INV-2026-00452`)
- `vendor_id`: VARCHAR(32) NOT NULL REFERENCES vendors(id)
- `po_reference`: VARCHAR(32) REFERENCES purchase_orders(id)
- `document_id`: UUID REFERENCES documents(id)
- `invoice_date`: DATE NOT NULL
- `due_date`: DATE NOT NULL
- `vendor_gstin`: VARCHAR(15) NOT NULL
- `recipient_gstin`: VARCHAR(15) NOT NULL
- `place_of_supply`: VARCHAR(2) NOT NULL
- `is_reverse_charge`: BOOLEAN DEFAULT FALSE
- `taxable_value_inr`: NUMERIC(15, 2) NOT NULL
- `cgst_amount_inr`: NUMERIC(15, 2) DEFAULT 0.00
- `sgst_amount_inr`: NUMERIC(15, 2) DEFAULT 0.00
- `igst_amount_inr`: NUMERIC(15, 2) DEFAULT 0.00
- `total_tax_inr`: NUMERIC(15, 2) NOT NULL
- `total_amount_inr`: NUMERIC(15, 2) NOT NULL
- `currency`: VARCHAR(3) DEFAULT 'INR'
- `status`: VARCHAR(32) DEFAULT 'INGESTED' CHECK (status IN (
    'INGESTED', 'EXTRACTED', 'MATCHING', 'MATCHED_EXACT', 'MATCHED_TOLERANCE',
    'EXCEPTION_HOLD', 'PENDING_APPROVAL', 'APPROVED', 'REJECTED', 'PAID'
  ))
- `extraction_confidence`: NUMERIC(5, 4)
- `payment_status`: VARCHAR(32) DEFAULT 'UNPAID'
- `created_at`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP

#### `invoice_items`
Extracted invoice line details.
- `id`: UUID PRIMARY KEY DEFAULT gen_random_uuid()
- `invoice_id`: VARCHAR(64) NOT NULL REFERENCES invoices(id) ON DELETE CASCADE
- `line_number`: INTEGER NOT NULL
- `item_code`: VARCHAR(64) NOT NULL
- `description`: TEXT NOT NULL
- `hsn_sac_code`: VARCHAR(16) NOT NULL
- `quantity`: NUMERIC(12, 3) NOT NULL
- `unit_price_inr`: NUMERIC(15, 2) NOT NULL
- `gst_rate_percent`: NUMERIC(5, 2) NOT NULL
- `taxable_amount_inr`: NUMERIC(15, 2) NOT NULL
- `total_line_amount_inr`: NUMERIC(15, 2) NOT NULL

#### `matching_results`
Deterministic 3-Way Match evaluation outcomes.
- `id`: UUID PRIMARY KEY DEFAULT gen_random_uuid()
- `invoice_id`: VARCHAR(64) UNIQUE NOT NULL REFERENCES invoices(id)
- `po_id`: VARCHAR(32) REFERENCES purchase_orders(id)
- `grn_id`: VARCHAR(32) REFERENCES goods_receipt_notes(id)
- `match_status`: VARCHAR(32) NOT NULL CHECK (match_status IN (
    'EXACT_MATCH', 'MATCH_WITHIN_TOLERANCE', 'QUANTITY_MISMATCH', 'PRICE_MISMATCH',
    'TAX_MISMATCH', 'VENDOR_MISMATCH', 'MISSING_PO', 'MISSING_GRN', 'DUPLICATE_INVOICE'
  ))
- `price_variance_percent`: NUMERIC(6, 2) DEFAULT 0.00
- `quantity_variance_percent`: NUMERIC(6, 2) DEFAULT 0.00
- `tax_variance_inr`: NUMERIC(15, 2) DEFAULT 0.00
- `total_financial_impact_inr`: NUMERIC(15, 2) DEFAULT 0.00
- `is_matched`: BOOLEAN NOT NULL
- `evaluation_notes`: TEXT
- `evaluated_at`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP

---

### Internal Controls, Exceptions, & Governance

#### `exceptions`
Reconciliation and compliance discrepancy tickets.
- `id`: VARCHAR(32) PRIMARY KEY (e.g. `EXC-2026-00018`)
- `invoice_id`: VARCHAR(64) NOT NULL REFERENCES invoices(id)
- `category`: VARCHAR(32) NOT NULL CHECK (category IN (
    'QUANTITY_DIFF', 'PRICE_DIFF', 'TAX_DIFF', 'MISSING_PO', 'MISSING_GRN',
    'VENDOR_MISMATCH', 'DUPLICATE_INVOICE', 'INVALID_DOC', 'SUSPICIOUS_AMT', 'LOW_CONFIDENCE'
  ))
- `severity`: VARCHAR(16) NOT NULL CHECK (severity IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL'))
- `expected_value`: TEXT NOT NULL
- `actual_value`: TEXT NOT NULL
- `difference_value`: TEXT NOT NULL
- `financial_impact_inr`: NUMERIC(15, 2) NOT NULL
- `responsible_department`: VARCHAR(64) NOT NULL
- `status`: VARCHAR(32) DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'INVESTIGATING', 'RESOLVED', 'REOPENED', 'WRITTEN_OFF'))
- `assigned_to_user_id`: UUID REFERENCES users(id)
- `resolution_notes`: TEXT
- `created_at`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
- `resolved_at`: TIMESTAMP WITH TIME ZONE

#### `risk_alerts`
Fraud risk and statistical anomaly records.
- `id`: UUID PRIMARY KEY DEFAULT gen_random_uuid()
- `invoice_id`: VARCHAR(64) NOT NULL REFERENCES invoices(id)
- `vendor_id`: VARCHAR(32) NOT NULL REFERENCES vendors(id)
- `risk_score`: INTEGER NOT NULL CHECK (risk_score BETWEEN 0 AND 100)
- `risk_category`: VARCHAR(32) NOT NULL CHECK (risk_category IN ('LOW', 'MODERATE', 'ELEVATED', 'HIGH'))
- `rule_triggered`: VARCHAR(128) NOT NULL
- `explanation`: TEXT NOT NULL
- `suggested_action`: TEXT NOT NULL
- `is_acknowledged`: BOOLEAN DEFAULT FALSE
- `created_at`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP

#### `approval_requests`
Multi-tier financial authorization queue.
- `id`: VARCHAR(32) PRIMARY KEY (e.g. `APR-2026-00092`)
- `invoice_id`: VARCHAR(64) NOT NULL REFERENCES invoices(id)
- `required_role`: VARCHAR(32) NOT NULL REFERENCES roles(id)
- `amount_inr`: NUMERIC(15, 2) NOT NULL
- `status`: VARCHAR(32) DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED', 'HELD', 'ESCALATED'))
- `assigned_user_id`: UUID REFERENCES users(id)
- `created_at`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP

#### `approval_history`
Immutable decisions log.
- `id`: UUID PRIMARY KEY DEFAULT gen_random_uuid()
- `approval_request_id`: VARCHAR(32) NOT NULL REFERENCES approval_requests(id)
- `decided_by_user_id`: UUID NOT NULL REFERENCES users(id)
- `action`: VARCHAR(32) NOT NULL CHECK (action IN ('APPROVED', 'REJECTED', 'HELD', 'ESCALATED'))
- `comments`: TEXT NOT NULL
- `timestamp`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP

#### `agent_executions`
Agentic execution trace and performance metrics.
- `id`: UUID PRIMARY KEY DEFAULT gen_random_uuid()
- `agent_name`: VARCHAR(64) NOT NULL
- `workflow_run_id`: VARCHAR(64) NOT NULL
- `invoice_id`: VARCHAR(64) REFERENCES invoices(id)
- `status`: VARCHAR(32) NOT NULL CHECK (status IN ('SUCCESS', 'FAILED', 'RETRYING', 'SKIPPED'))
- `execution_duration_ms`: INTEGER NOT NULL
- `prompt_tokens`: INTEGER DEFAULT 0
- `completion_tokens`: INTEGER DEFAULT 0
- `total_cost_usd`: NUMERIC(8, 6) DEFAULT 0.000000
- `error_message`: TEXT
- `executed_at`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP

#### `audit_logs`
Comprehensive non-repudiation audit trail.
- `id`: UUID PRIMARY KEY DEFAULT gen_random_uuid()
- `entity_type`: VARCHAR(64) NOT NULL
- `entity_id`: VARCHAR(64) NOT NULL
- `action`: VARCHAR(64) NOT NULL
- `actor_type`: VARCHAR(16) NOT NULL CHECK (actor_type IN ('USER', 'AGENT', 'SYSTEM'))
- `actor_id`: VARCHAR(64) NOT NULL
- `old_state`: JSONB
- `new_state`: JSONB
- `ip_address`: VARCHAR(45)
- `timestamp`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP

---

## 3. Database Constraints & Performance Indexes

```sql
-- Unique constraint to prevent duplicate invoices from same vendor
CREATE UNIQUE INDEX idx_vendor_invoice_unique ON invoices (vendor_id, id);

-- Indexes for Fast Reconciliation and Dashboard Analytics
CREATE INDEX idx_invoices_status ON invoices (status);
CREATE INDEX idx_invoices_due_date ON invoices (due_date);
CREATE INDEX idx_invoices_po_ref ON invoices (po_reference);
CREATE INDEX idx_po_vendor ON purchase_orders (vendor_id);
CREATE INDEX idx_grn_po ON goods_receipt_notes (po_id);
CREATE INDEX idx_exceptions_status ON exceptions (status, severity);
CREATE INDEX idx_audit_entity ON audit_logs (entity_type, entity_id);
CREATE INDEX idx_agent_runs ON agent_executions (workflow_run_id, agent_name);
```

