# REST API Specifications & Contracts
## AP INTELLIGENCE: FastAPI Endpoints (/api/v1)
**Base URL**: `http://localhost:8000/api/v1`  
**Authentication**: Bearer JWT / API Key Header

---

## 1. Authentication & System Health

### `GET /api/v1/health`
- **Purpose**: System readiness, database connectivity, and agent service health.
- **Response `200 OK`**:
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "database": "connected",
  "active_llm_provider": "gemini",
  "timestamp": "2026-11-07T16:35:00Z"
}
```

### `POST /api/v1/auth/login`
- **Request**: `{ "email": "controller@apex.com", "password": "secure" }`
- **Response `200 OK`**:
```json
{
  "access_token": "eyJhbGciOi...",
  "token_type": "bearer",
  "user": {
    "id": "u-01",
    "email": "controller@apex.com",
    "role": "FINANCE_CONTROLLER",
    "approval_limit_inr": 5000000.0
  }
}
```

---

## 2. Invoices & Document Processing

### `POST /api/v1/documents/upload`
- **Purpose**: Multipart form upload for supplier invoices, purchase orders, or GRN bills.
- **Request**: `multipart/form-data` with `file: Binary`, `document_type: "INVOICE"`
- **Response `201 Created`**:
```json
{
  "document_id": "doc-uuid-9921",
  "file_name": "INV_2026_TataSteel_045.pdf",
  "file_size_bytes": 145020,
  "mime_type": "application/pdf",
  "document_type": "INVOICE",
  "upload_status": "PROCESSED",
  "ocr_confidence": 0.965
}
```

### `POST /api/v1/invoices/process-agentic`
- **Purpose**: Trigger the multi-agent LangGraph workflow for an uploaded document.
- **Request**:
```json
{
  "document_id": "doc-uuid-9921",
  "auto_route": true
}
```
- **Response `202 Accepted`**:
```json
{
  "workflow_run_id": "run-88219",
  "invoice_id": "INV-2026-00452",
  "status": "IN_PROGRESS",
  "agents_triggered": [
    "Invoice Intelligence",
    "PO Analysis",
    "GRN Verification",
    "3-Way Matching"
  ]
}
```

### `GET /api/v1/invoices`
- **Query Params**: `status`, `vendor_id`, `start_date`, `end_date`, `page`, `page_size`
- **Response `200 OK`**: Array of invoices with match statuses, amounts, and dates.

### `GET /api/v1/invoices/{id}`
- **Purpose**: Retrieve full 3-way view (Extracted Invoice + Linked PO + Linked GRNs + Match Result + Exceptions + Audit History).

---

## 3. Three-Way Matching & Exceptions

### `POST /api/v1/matching/evaluate/{invoice_id}`
- **Purpose**: Execute deterministic 3-way reconciliation against linked PO and GRNs.
- **Response `200 OK`**:
```json
{
  "invoice_id": "INV-2026-00452",
  "po_id": "PO-2026-00101",
  "grn_id": "GRN-2026-00085",
  "match_status": "MATCH_WITHIN_TOLERANCE",
  "is_matched": true,
  "tolerances_applied": {
    "price_tolerance_pct": 2.0,
    "qty_tolerance_pct": 0.0,
    "tax_tolerance_inr": 5.0
  },
  "line_reconciliation": [
    {
      "line_no": 1,
      "item_code": "STL-BEAM-01",
      "invoice_qty": 50.0,
      "grn_accepted_qty": 50.0,
      "invoice_unit_price": 4200.0,
      "po_unit_price": 4180.0,
      "price_variance_pct": 0.48,
      "status": "TOLERANCE_ACCEPTED"
    }
  ],
  "discrepancies": []
}
```

### `GET /api/v1/exceptions`
- **Query Params**: `category`, `severity`, `status`, `assigned_to`
- **Response `200 OK`**: Paginated discrepancy workbench list.

### `POST /api/v1/exceptions/{id}/resolve`
- **Request**:
```json
{
  "action": "ACCEPT_PRICE_VARIANCE",
  "resolution_notes": "Variance within vendor negotiated master adjustment limit approved by AP Manager.",
  "adjust_liability": false
}
```
- **Response `200 OK`**: Updated exception status and created audit entry.

---

## 4. Approvals & Human-in-the-Loop Controls

### `GET /api/v1/approvals/pending`
- **Purpose**: List invoices awaiting current user's role authorization.
- **Response `200 OK`**: Queue with financial exposure, risk score, and match status.

### `POST /api/v1/approvals/{id}/action`
- **Request**:
```json
{
  "action": "APPROVED", // 'APPROVED' | 'REJECTED' | 'HELD'
  "comments": "Reconciliation verified against GRN-2026-00085. Passed within policy."
}
```
- **Response `200 OK`**: State updated to `APPROVED`, next workflow action logged.

---

## 5. Risk, Fraud & Audit

### `GET /api/v1/risk/alerts`
- **Purpose**: List fraud indicators and anomaly scores with explainable justifications.

### `GET /api/v1/audit/logs`
- **Query Params**: `entity_type`, `entity_id`, `actor_type`, `limit`
- **Response `200 OK`**: Immutable chronological activity stream.

---

## 6. Executive Analytics & Copilot

### `GET /api/v1/analytics/dashboard`
- **Purpose**: Real-time aggregated financial KPIs (Matching rate, DPO, Outstanding payables, Aging cohorts, Cost per invoice).

### `GET /api/v1/analytics/roi-model`
- **Purpose**: Academic cost-benefit and ROI metrics (Baseline vs Automated, Net Savings, Payback months).

### `POST /api/v1/copilot/query`
- **Purpose**: Conversational finance assistant using deterministic read-only database tools.
- **Request**:
```json
{
  "query": "What is our total outstanding payable to Tata Steel and are there any overdue bills?",
  "conversation_id": "conv-1092"
}
```
- **Response `200 OK`**:
```json
{
  "response": "Apex Bharat owes a total outstanding payable of ₹14,25,000 to Tata Steel Products Ltd. across 3 active invoices. Of this, 1 invoice (INV-2026-00388 for ₹3,40,000) is currently 4 days overdue.",
  "supporting_records": ["INV-2026-00388", "INV-2026-00452", "INV-2026-00461"],
  "tools_executed": ["get_vendor_outstanding_payables", "check_overdue_invoices"]
}
```

