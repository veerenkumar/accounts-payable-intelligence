# Multi-Agent Workflow Specification & State Machine
## AP INTELLIGENCE: LangGraph Supervisor-Worker Framework
**Framework**: LangGraph / LangChain Core  
**State Pattern**: Typed State Graph with Deterministic Branching & Human Checkpoints

---

## 1. Graph State Definition (`AgentWorkflowState`)

```python
from typing import TypedDict, List, Dict, Optional, Any
from pydantic import BaseModel, Field

class AgentWorkflowState(TypedDict):
    # Workflow Metadata
    workflow_run_id: str
    document_id: str
    file_path: str
    
    # Extracted Artifacts
    invoice_data: Optional[Dict[str, Any]]
    po_data: Optional[Dict[str, Any]]
    grn_data: Optional[List[Dict[str, Any]]]
    
    # Financial Engine Results
    matching_result: Optional[Dict[str, Any]]
    is_matched: bool
    discrepancies: List[Dict[str, Any]]
    
    # Risk & Anomaly Assessment
    risk_score: int
    risk_category: str
    risk_flags: List[str]
    
    # Exceptions & Remediation
    exception_id: Optional[str]
    remediation_plan: Optional[Dict[str, Any]]
    
    # Human-in-the-Loop & Routing
    assigned_approval_role: Optional[str]
    approval_status: str  # PENDING, APPROVED, REJECTED, HELD
    requires_human_review: bool
    
    # Execution Tracking
    current_agent: str
    execution_history: List[Dict[str, Any]]
    total_tokens_used: int
    error_message: Optional[str]
```

---

## 2. LangGraph State Machine Diagram

```mermaid
stateDiagram-v2
    [*] --> Supervisor
    
    Supervisor --> InvoiceIntelligenceAgent : Route: Document Ingested
    InvoiceIntelligenceAgent --> Supervisor : Extracted Data & Confidence

    Supervisor --> POAnalysisAgent : Verify PO Reference
    POAnalysisAgent --> Supervisor : PO Status & Approved Lines

    Supervisor --> GRNVerificationAgent : Verify Goods Received
    GRNVerificationAgent --> Supervisor : Accepted/Rejected Quantities

    Supervisor --> ThreeWayMatchingAgent : Trigger Deterministic Reconciliation
    ThreeWayMatchingAgent --> Supervisor : Matching Status & Variances

    Supervisor --> FraudRiskAgent : Evaluate Anomaly & Duplicates
    FraudRiskAgent --> Supervisor : Risk Score (0-100) & Flags

    state MatchDecision <<choice>>
    Supervisor --> MatchDecision
    
    MatchDecision --> ExceptionResolutionAgent : If Mismatch OR High Risk
    MatchDecision --> ApprovalManagementAgent : If Matched AND Low Risk

    ExceptionResolutionAgent --> HumanWorkbench : Create Exception Ticket
    ApprovalManagementAgent --> HumanApprovalQueue : Create Tiered Authorization

    HumanWorkbench --> Supervisor : Human Resolves / Overrides
    HumanApprovalQueue --> FinanceAnalyticsAgent : On Approval Action

    FinanceAnalyticsAgent --> [*] : Update KPIs & Finalize Audit
```

---

## 3. Human-in-the-Loop (HITL) Checkpoints

To ensure zero uncontrolled financial liability, the workflow pauses and requires cryptographic / user session authorization at two specific state boundaries:

1. **Checkpoint A: Exception Resolution Hold**
   - **Condition**: Price discrepancy > 2%, Quantity discrepancy > 0%, Missing PO/GRN, Duplicate invoice detected.
   - **Agent Action**: `ExceptionResolutionAgent` classifies discrepancy, suggests resolution (e.g., *Debit note request* or *PO amendment*), and transitions state to `EXCEPTION_HOLD`.
   - **Human Action**: AP Specialist or Manager must explicitly resolve or re-route through the Exception Workbench.
2. **Checkpoint B: Tiered Authorization Gate**
   - **Condition**: Reconciled invoice eligible for payment recording.
   - **Agent Action**: `ApprovalManagementAgent` assigns to required tier based on monetary threshold:
     - $\le ₹1,00,000$: Finance Executive
     - $\le ₹10,00,000$: AP Manager
     - $> ₹10,00,000$: Finance Controller
   - **Human Action**: Authorized user submits `APPROVE`, `REJECT`, or `HOLD` with mandatory decision comments.

---

## 4. Fallback & Deterministic Invariance

If external LLM APIs (Gemini/OpenAI) experience rate limits, latency spikes, or network isolation:
1. **Rule-Based Deterministic Fallback**: The workflow switches transparently to local regex, template matching, and SQL reconciliation routines.
2. **No Data Hallucination**: The LLM is strictly prohibited from altering numeric fields (GST, unit price, quantity) produced by the OCR or database.

