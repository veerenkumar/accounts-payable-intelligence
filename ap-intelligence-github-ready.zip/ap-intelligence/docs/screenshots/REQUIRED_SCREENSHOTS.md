# AP INTELLIGENCE — REQUIRED SCREENSHOTS FOR ACADEMIC SUBMISSION REPORT

This document specifies the comprehensive screenshot inventory required for the MBA academic report, project presentation, and viva voce defense.

---

### Screenshot Inventory Checklist

| # | Screenshot Filename | Application URL / Screen | Key Visual Elements to Capture | Report Chapter Alignment |
|:---:|---|---|---|:---:|
| **01** | `01_executive_dashboard.png` | `http://localhost:3000/` | KPI metric cards (Total Invoices: 32, Active Exceptions: 10, Pending Approvals: 12), STP rate gauge, Aging charts, dark navy theme | Chapter 1 & Chapter 4 |
| **02** | `02_invoice_ledger.png` | `http://localhost:3000/invoices` | Supplier Invoices table, status badges (`EXACT_MATCH`, `MISSING_PO`, `PRICE_MISMATCH`), search bar, `⚠️ OCR Conflict` flag | Chapter 4 |
| **03** | `03_ocr_reconciliation_modal.png` | `http://localhost:3000/invoices` (Review Modal) | Side-by-side reconciliation comparison table for `INV-2026-00452` showing ERP Ledger vs Extracted Document OCR and conflict flags | Chapter 3 & Chapter 4 |
| **04** | `04_document_center.png` | `http://localhost:3000/documents` | Drag-and-drop upload zone, document list, OCR confidence telemetry badges (97.6% - 98.0%) | Chapter 4 |
| **05** | `05_document_ocr_inspection.png` | `http://localhost:3000/documents` (Inspect Modal) | Full OCR extraction preview of `INV_2026_00452_TataSteel.pdf` showing structured key-value fields and raw OCR text stream | Chapter 3 & Chapter 4 |
| **06** | `06_three_way_matching_overview.png` | `http://localhost:3000/matching` | 3-way matching dashboard, tolerance sliders (2% Price, 0% Qty), invoice evaluation list | Chapter 4 |
| **07** | `07_triangulation_detail_exact.png` | `http://localhost:3000/matching` (INV-2026-00451) | Three-column triangulation view for `INV-2026-00451`: Invoice $\leftrightarrow$ PO-2026-00101 $\leftrightarrow$ GRN-2026-00081 with green agreed status | Chapter 4 |
| **08** | `08_triangulation_missing_po.png` | `http://localhost:3000/matching` (INV-2026-00452) | Triangulation screen for `INV-2026-00452` showing `MISSING PO`, `NO GRN FOUND`, and financial impact of ₹2,46,620 | Chapter 4 |
| **09** | `09_exception_workbench.png` | `http://localhost:3000/exceptions` | Exception cards grouped by severity (High/Medium), root cause categories (`MISSING_PO`, `QUANTITY_MISMATCH`), financial exposure total | Chapter 2 & Chapter 4 |
| **10** | `10_approval_center_search.png` | `http://localhost:3000/approvals` | Approval queue filtered by `INV-2026-00452`, displaying `HELD` status, missing PO exception count, and disabled approval button | Chapter 4 & Chapter 5 |
| **11** | `11_delegation_of_authority_matrix.png` | `http://localhost:3000/approvals` | Tiered authorization badges (`FINANCE_EXECUTIVE < ₹1L`, `AP_MANAGER < ₹10L`, `CONTROLLER ≥ ₹10L`), DOA ceiling error modal | Chapter 5 |
| **12** | `12_purchase_orders_registry.png` | `http://localhost:3000/purchase-orders` | PO master list showing `PO-2026-00101` (Tata Steel, Fulfilled) vs `PO-2026-00102` (L&T, Fulfilled) | Chapter 4 |
| **13** | `13_goods_receipt_notes.png` | `http://localhost:3000/grn` | Warehouse delivery receipts, accepted vs rejected counts, challan numbers | Chapter 4 |
| **14** | `14_vendor_management.png` | `http://localhost:3000/vendors` | Vendor directory (`VEND-001` Tata Steel, `VEND-002` L&T), verified GSTINs, state codes, risk indices | Chapter 4 |
| **15** | `15_financial_analytics_roi.png` | `http://localhost:3000/analytics` | 3-Year ROI model, cost-per-invoice reduction curve, labor savings calculations, working capital impact | Chapter 6 |
| **16** | `16_ai_financial_copilot.png` | `http://localhost:3000/copilot` | Natural language query: *"What is our outstanding liability?"* showing database-grounded response and tool telemetry | Chapter 3 & Chapter 4 |
| **17** | `17_audit_trail_log.png` | `http://localhost:3000/audit` | Chronological non-repudiation audit table, actor IDs, actions (`MATCH_EVALUATED_MISSING_PO`, `RECONCILIATION`), JSON diffs | Chapter 5 |
| **18** | `18_agent_control_center.png` | `http://localhost:3000/agent-control` | 8-agent supervisor orchestration diagram, agent health indicators, token telemetry | Chapter 3 |

---

### Recommended Capture Instructions

1. **Resolution**: 1920 $\times$ 1080 (1080p full HD) or 2560 $\times$ 1440 (2K QHD) on a 16:9 display.
2. **Theme**: Standard application dark navy theme (`bg-navy-950`).
3. **Browser Zoom**: Set browser zoom to 100% (default) in Google Chrome or Microsoft Edge.
4. **File Format**: Standard PNG format (`.png`) with crisp text rendering. Store in `docs/screenshots/`.

