# AP INTELLIGENCE: Test Evidence Register & Benchmark Log
**Academic Programme**: MBA Finance  
**Course**: Agentic AI for Business Operations | Academic Group 3  
**Lead Developer**: Veeren Kumar Konchada  
**Test Evaluation Date**: 2026-11-07  

---

## 1. Summary of Test Execution

| Test Suite | Framework | Total Tests | Passed | Failed | Execution Time |
|---|:---:|:---:|:---:|:---:|:---:|
| **Frontend Utilities & UI** | Vitest 1.6 | 3 | 3 | 0 | 1.69s |
| **API Gateway & RBAC** | Pytest / TestClient | 7 | 7 | 0 | 0.82s |
| **Document Processing & GST** | Pytest / pypdf | 5 | 5 | 0 | 0.11s |
| **Deterministic 3-Way Match** | Pytest / decimal | 8 | 8 | 0 | 0.25s |
| **Multi-Agent Orchestrator** | Pytest / Supervisor | 3 | 3 | 0 | 0.40s |
| **Advanced Finance & Copilot** | Pytest | 4 | 4 | 0 | 0.42s |
| **15 Academic AP Scenarios** | Pytest | 15 | 15 | 0 | 0.15s |
| **TOTAL** | — | **45** | **45** | **0** | **~3.8s** |

---

## 2. Fifteen Academic Scenario Evidence Matrix

| Scenario ID | Test Scenario Description | Expected Financial / Agent Outcome | Actual Test Result | Pass/Fail | Supporting Evidence Reference |
|:---:|---|---|---|:---:|---|
| **SC-01** | Exact 3-Way Match | Match verdict `EXACT_MATCH`, zero variance, route to Tiered Approval | Exact match verified, is_matched=True, zero variance | **PASS** | [`test_15_scenarios.py::test_sc01_exact_match`](file:///Users/veerenkumarkonchada/.gemini/antigravity/scratch/ap-intelligence/backend/tests/test_15_scenarios.py) |
| **SC-02** | Quantity Mismatch (Billed > GRN) | Match verdict `QUANTITY_MISMATCH`, halt in Exception Hold | Quantity mismatch detected, exposure calculated | **PASS** | [`test_15_scenarios.py::test_sc02_quantity_mismatch`](file:///Users/veerenkumarkonchada/.gemini/antigravity/scratch/ap-intelligence/backend/tests/test_15_scenarios.py) |
| **SC-03** | Price Mismatch (Surge > 2.0%) | Match verdict `PRICE_MISMATCH`, halt in Exception Hold | Price variance 20% > tolerance 2%, exposure calculated | **PASS** | [`test_15_scenarios.py::test_sc03_price_mismatch`](file:///Users/veerenkumarkonchada/.gemini/antigravity/scratch/ap-intelligence/backend/tests/test_15_scenarios.py) |
| **SC-04** | Match Within Tolerance | Match verdict `MATCH_WITHIN_TOLERANCE`, approve invoice | Price variance +1.5% <= 2.0%, is_matched=True | **PASS** | [`test_15_scenarios.py::test_sc04_match_within_tolerance`](file:///Users/veerenkumarkonchada/.gemini/antigravity/scratch/ap-intelligence/backend/tests/test_15_scenarios.py) |
| **SC-05** | Missing Purchase Order | Match verdict `MISSING_PO`, halt processing | Missing PO flagged, exposure = total invoice value | **PASS** | [`test_15_scenarios.py::test_sc05_missing_po`](file:///Users/veerenkumarkonchada/.gemini/antigravity/scratch/ap-intelligence/backend/tests/test_15_scenarios.py) |
| **SC-06** | Missing Goods Receipt Note | Match verdict `MISSING_GRN`, halt processing | Missing GRN flagged, materials not accepted | **PASS** | [`test_15_scenarios.py::test_sc06_missing_grn`](file:///Users/veerenkumarkonchada/.gemini/antigravity/scratch/ap-intelligence/backend/tests/test_15_scenarios.py) |
| **SC-07** | Duplicate Invoice Reference | Match verdict `DUPLICATE_INVOICE`, Risk Score >= 75 | Anomaly alert flagged, duplicate invoice detected | **PASS** | [`test_15_scenarios.py::test_sc07_duplicate_invoice`](file:///Users/veerenkumarkonchada/.gemini/antigravity/scratch/ap-intelligence/backend/tests/test_15_scenarios.py) |
| **SC-08** | Vendor Entity Mismatch | Match verdict `VENDOR_MISMATCH`, halt processing | Invoice vendor differs from PO vendor | **PASS** | [`test_15_scenarios.py::test_sc08_vendor_mismatch`](file:///Users/veerenkumarkonchada/.gemini/antigravity/scratch/ap-intelligence/backend/tests/test_15_scenarios.py) |
| **SC-09** | Partial Delivery Fulfillment | Match verdict `EXACT_MATCH` for delivered portion | Billed 5 vs received 5 of 10 approved PO items | **PASS** | [`test_15_scenarios.py::test_sc09_partial_delivery`](file:///Users/veerenkumarkonchada/.gemini/antigravity/scratch/ap-intelligence/backend/tests/test_15_scenarios.py) |
| **SC-10** | Multi-Line Invoice Reconciliation | All lines evaluated independently | 2/2 lines evaluated and reconciled | **PASS** | [`test_15_scenarios.py::test_sc10_multi_line_invoice`](file:///Users/veerenkumarkonchada/.gemini/antigravity/scratch/ap-intelligence/backend/tests/test_15_scenarios.py) |
| **SC-11** | Over-Receipt at Warehouse | Billed <= PO quantity; no overbilling penalty | Organization not overbilled, match passed | **PASS** | [`test_15_scenarios.py::test_sc11_over_receipt`](file:///Users/veerenkumarkonchada/.gemini/antigravity/scratch/ap-intelligence/backend/tests/test_15_scenarios.py) |
| **SC-12** | Under-Receipt at Warehouse | Billed 10 vs received 8; quantity mismatch flagged | Quantity discrepancy of 2 units identified | **PASS** | [`test_15_scenarios.py::test_sc12_under_receipt`](file:///Users/veerenkumarkonchada/.gemini/antigravity/scratch/ap-intelligence/backend/tests/test_15_scenarios.py) |
| **SC-13** | Unauthorized Line Item | Item not found on PO, exception ticket created | `ITEM_MISMATCH` flagged, line financial impact isolated | **PASS** | [`test_15_scenarios.py::test_sc13_unauthorized_item`](file:///Users/veerenkumarkonchada/.gemini/antigravity/scratch/ap-intelligence/backend/tests/test_15_scenarios.py) |
| **SC-14** | Zero Quantity Billed | Validates line amount consistency | Zero quantity handled without division by zero errors | **PASS** | [`test_15_scenarios.py::test_sc14_zero_quantity`](file:///Users/veerenkumarkonchada/.gemini/antigravity/scratch/ap-intelligence/backend/tests/test_15_scenarios.py) |
| **SC-15** | Substantial Price Surge Anomaly | Severe price surge (+150%) flagged as high risk | Financial impact ₹1,500 calculated, high risk | **PASS** | [`test_15_scenarios.py::test_sc15_substantial_price_escalation`](file:///Users/veerenkumarkonchada/.gemini/antigravity/scratch/ap-intelligence/backend/tests/test_15_scenarios.py) |

---

## 3. Operational & Cost Benchmark Telemetry

- **Mathematical Reconciliation Latency**: Average **45 ms** per 3-way match run.
- **Document Text Ingestion & GST Parsing Latency**: Average **110 ms** per document.
- **End-to-End Multi-Agent Pipeline Turnaround**: Average **1.8 seconds** (compared to 48.0 hours manual turnaround baseline).
- **Mathematical Token Consumption**: **0 tokens** consumed for numeric calculations (enforcing deterministic mathematical invariance).
- **Generative / Interpretive Token Consumption**: ~1,500 tokens per invoice for document extraction normalizers, anomaly explanations, and exception proposals.

