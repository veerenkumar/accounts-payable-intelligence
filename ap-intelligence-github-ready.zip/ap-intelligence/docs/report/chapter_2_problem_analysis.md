# CHAPTER 2: PROBLEM ANALYSIS AND PROCESS MAPPING (MODULE M1)
## AP INTELLIGENCE: Accounts Payable Transformation
**Academic Module**: M1 | MBA Finance Evaluation

---

### 2.1 As-Is Accounts Payable Process Description
In the baseline corporate environment, the Accounts Payable lifecycle is overwhelmingly manual, paper-dependent, and decentralized across Procurement, Warehousing, and Finance:

```mermaid
flowchart TD
    A["1. Supplier Invoices Received (Mail/PDF)"] --> B["2. Clerical Data Entry into ERP"]
    B --> C["3. Physical Search for Approved PO"]
    C --> D["4. Coordinate with Warehouse for Delivery Challan / GRN"]
    D --> E["5. Manual Line-by-Line 3-Way Match Check"]
    E --> F{"Discrepancy Found?"}
    F -- Yes --> G["6. Email Back-and-Forth with Vendor & Procurement (Hold)"]
    F -- No --> H["7. Physical Approval Voucher Routing"]
    H --> I["8. Periodic Batch Payment Run"]
    G --> I
```

#### Bottlenecks in the As-Is Process:
- **Average Lead Time**: 48.0 to 72.0 hours per invoice.
- **Error Rate**: 12.5% of manual entries contain clerical discrepancies (incorrect HSN code, typographical errors in taxable base, misattributed vendor code).
- **Audit Deficiencies**: Physical paper trails or fragmented email approvals complicate internal audits and statutory GST reconciliation.

---

### 2.2 Root-Cause Analysis (Fishbone Diagram & 5 Whys)

#### 1. Ishikawa (Fishbone) Diagram

```mermaid
graph LR
    subgraph People ["People & Training"]
        P1["Clerical Data Entry Fatigue"]
        P2["Lack of GST Nuance Knowledge"]
    end
    subgraph Process ["Process & Policies"]
        PR1["Manual 3-Way Cross Checking"]
        PR2["Decentralized Approval Follow-ups"]
    end
    subgraph Technology ["Technology & Systems"]
        T1["Legacy ERP Brittle OCR"]
        T2["Siloed Warehouse Receipt Data"]
    end
    subgraph Materials ["Documents & Inputs"]
        M1["Unstructured PDF Layouts"]
        M2["Missing PO References on Bills"]
    end

    People --> Problem["Accounts Payable Processing Bottlenecks & High Cost (₹450/invoice)"]
    Process --> Problem
    Technology --> Problem
    Materials --> Problem
```

#### 2. The 5 Whys Analysis: Why Does Invoice Processing Take 48+ Hours?
1. **Why?** Clerks spend hours manually reconciling invoice line items against purchase orders and warehouse receipts.
2. **Why?** Supplier invoices arrive in inconsistent, unstructured PDF formats with differing line descriptions and tax groupings.
3. **Why?** Existing ERP systems lack intelligent semantic document parsing and cannot resolve minor typographical variances.
4. **Why?** Procurement rules require strict matching, but tolerance checks are applied manually on desktop spreadsheets.
5. **Why?** The organization lacks an agentic orchestration layer capable of combining OCR document intelligence with deterministic mathematical verification.

---

### 2.3 Baseline Operating Metrics

| Metric | Baseline (Manual As-Is) | Target (AP Intelligence) | Percentage Improvement |
|---|:---:|:---:|:---:|
| **Processing Time per Invoice** | 48.0 Hours | 1.8 Hours | **-96.2%** |
| **Cost per Invoice** | ₹450.00 | ₹42.50 | **-90.5%** |
| **Straight-Through Processing (STP)** | 0.0% (Manual entry) | 78.2% | **+78.2% Lift** |
| **Reconciliation Matching Rate** | 68.0% | 85.8% | **+26.1% Lift** |
| **Duplicate Billing Leakage** | 1.5% undetected | 0.0% (100% caught) | **Zero Leakage** |
| **Early Payment Discount Capture** | < 15% captured | > 85% captured | **+466% Lift** |

---

### 2.4 Stakeholder Mapping & Value Matrix

| Stakeholder Group | Operational Pain Point | Value Delivered by AP Intelligence |
|---|---|---|
| **Chief Financial Officer (CFO)** | Inaccurate working capital forecasting, cash leakage, high cost per transaction | Real-time DPO visibility, annual savings of ₹34.5 Lakhs, 342% ROI |
| **Finance Controller** | Fraud risk, audit non-compliance, unauthorized delegation of authority | Immutable audit trails, DPDP Act compliance, automated monetary ceilings |
| **Accounts Payable Manager** | High exception backlogs, endless supplier dispute emails | Exception Workbench with auto-generated root causes and debit note proposals |
| **Procurement & Warehouse** | Constant friction resolving invoice price/quantity discrepancies | Triangulated line-item matching against verified GRN accepted quantities |
| **Key Suppliers / Vendors** | Payment delays, lack of status visibility, disputed deductions | Rapid invoice acknowledgment, timely payment cycles, transparent resolution |

---

### 2.5 Agent Suitability Assessment
Following the prescribed academic agent framework, tasks within Accounts Payable were evaluated to determine whether they warrant autonomous agentic automation:

| Process Component | Deterministic vs Probabilistic | Reasoning Required? | Agent Suitability Verdict |
|---|:---:|:---:|:---:|
| **Document OCR Parsing** | Probabilistic (varying layouts) | Yes (spatial & semantic parsing) | **Agent 1 (Invoice Intelligence)** |
| **PO Master Record Lookup** | Deterministic (exact key query) | Low (data retrieval) | **Agent 2 (PO Analysis)** |
| **GRN Receipt Triangulation** | Deterministic (quantity check) | Low (math validation) | **Agent 3 (GRN Verification)** |
| **3-Way Mathematical Match** | Strictly Deterministic | None (math precision required) | **Agent 4 (Math Invariance Engine)** |
| **Duplicate & Anomaly Detection**| Hybrid (rule + statistical) | Medium (anomaly explanation) | **Agent 5 (Fraud & Risk Agent)** |
| **Discrepancy Remediation** | Probabilistic (contextual) | High (root cause, action drafting) | **Agent 6 (Exception Resolution)** |
| **Monetary Routing** | Deterministic (threshold policy) | Low (policy enforcement) | **Agent 7 (Approval Management)** |
| **Ledger Analytics & Queries** | Hybrid (data + conversational) | High (executive synthesis) | **Agent 8 (Finance Analytics)** |

---

### 2.6 To-Be Accounts Payable Process Overview
The To-Be process replaces manual clerical interventions with an autonomous 8-agent pipeline governed by two strict Human-in-the-Loop checkpoints:

```mermaid
flowchart TD
    Doc["Supplier Ingests PDF/Image"] --> A1["Agent 1: OCR & GST Extraction"]
    A1 --> A2["Agent 2: PO Master Validation"]
    A2 --> A3["Agent 3: Warehouse GRN Verification"]
    A3 --> A4["Agent 4: Deterministic 3-Way Match Engine"]
    A4 --> A5["Agent 5: Duplicate & Anomaly Risk Scoring"]
    A5 --> Gate{"Match Passed & Risk Low?"}
    Gate -- No --> A6["Agent 6: Exception Workbench (Human Checkpoint A)"]
    A6 --> Gate2{"Human Overrides or Issues Debit Note?"}
    Gate2 -- Resolved --> A7["Agent 7: Approval Hierarchy (Human Checkpoint B)"]
    Gate2 -- Rejected --> Terminate["Voucher Cancelled"]
    Gate -- Yes --> A7
    A7 --> A8["Agent 8: Finance Analytics & Immutable Audit Log"]
```

