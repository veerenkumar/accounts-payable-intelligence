# CHAPTER 4: PROTOTYPE IMPLEMENTATION AND WORKFLOW ORCHESTRATION (MODULE M3)
## AP INTELLIGENCE: Full-Stack Implementation
**Academic Module**: M3 | MBA Finance Evaluation

---

### 4.1 Technology Stack Justification
The technology stack for **AP INTELLIGENCE** was chosen to balance modern enterprise web architecture with rigorous financial accuracy:

- **Frontend (Next.js 14, React 18, TypeScript, Tailwind CSS)**:
  - *Justification*: Provides server-side rendering (SSR), type safety, zero client-side calculation errors, and a responsive dark navy enterprise design system.
  - *Visual Consistency*: Clean, data-dense financial tables, metric KPI cards, and status badges styled after corporate treasury consoles.
- **Backend (FastAPI, Python 3.12, Pydantic v2, SQLAlchemy 2.0)**:
  - *Justification*: FastAPI offers asynchronous I/O performance, automatic OpenAPI documentation, and native Pydantic schema validation for strong data typing.
- **Financial Computation Engine (`decimal.Decimal`)**:
  - *Justification*: Eliminates IEEE 754 binary floating-point rounding errors (e.g. `0.1 + 0.2 != 0.3`) in corporate tax and variance calculations.
- **Multi-Agent Orchestrator (LangGraph Core)**:
  - *Justification*: Stateful graph execution with explicit cycle and error controls, preventing runaway API calls and supporting persistent checkpoints.

---

### 4.2 Synthetic Data Architecture
To ensure rigorous evaluation without compromising corporate privacy or violating the DPDP Act (2023), the prototype utilizes a realistic synthetic corporate dataset modeled after **Apex Bharat Manufacturing Pvt. Ltd.** (`GSTIN: 27AABCA9876K1Z5`):
- **15 Master Vendor Profiles**: Realistic Indian corporate entities across industrial categories (e.g., Tata Steel Products Ltd., Schneider Electric India, Bharat Petro Lubricants).
- **30 Purchase Orders & Goods Receipt Notes**: Representing diverse procurement terms (Net 15, Net 30, Net 45).
- **Sample Digital Documents**: Formatted tax invoices generated programmatically in PDF format matching ground-truth ledger data.

---

### 4.3 Implementation Walkthrough

#### 1. Document Ingestion & Statutory GST Parsing
When a supplier invoice is ingested via `POST /api/v1/documents/upload`, `DocumentParser` utilizes `pypdf` to extract raw text blocks. `GSTValidator` executes format validation on the 15-character alphanumeric GSTIN regex:
$$\text{Regex: } \wedge[0-9]\{2\}[A-Z]\{5\}[0-9]\{4\}[A-Z]\{1\}[1-9A-Z]\{1\}Z[0-9A-Z]\{1\}\$$
It dynamically determines tax applicability:
$$\text{Tax Mode} = \begin{cases} \text{Intra-State (CGST + SGST)}, & \text{if } \text{Supplier State Code} = \text{Recipient State Code} \\ \text{Inter-State (IGST)}, & \text{if } \text{Supplier State Code} \neq \text{Recipient State Code} \end{cases}$$

#### 2. Deterministic Three-Way Matching Engine
`DeterministicMatchingEngine` reconciles line-item quantities and rates against master PO commitments and GRN accepted counts:
$$\text{Price Variance \%} = \left(\frac{\text{Invoice Unit Rate} - \text{PO Unit Rate}}{\text{PO Unit Rate}}\right) \times 100$$
$$\text{Quantity Variance \%} = \left(\frac{\text{Invoice Qty} - \text{GRN Accepted Qty}}{\text{GRN Accepted Qty}}\right) \times 100$$

Reconciliation decision logic:
- $\text{Price Variance \%} \le 2.0\%$ and $\text{Qty Variance \%} = 0\% \implies \textbf{MATCH\_WITHIN\_TOLERANCE}$
- $\text{Price Variance \%} > 2.0\% \implies \textbf{PRICE\_MISMATCH}$ (financial exposure isolated)
- $\text{Billed Qty} > \text{GRN Accepted Qty} \implies \textbf{QUANTITY\_MISMATCH}$

---

### 4.4 Human-in-the-Loop (HITL) Checkpoints

```mermaid
stateDiagram-v2
    [*] --> IngestInvoice
    IngestInvoice --> ThreeWayMatch
    
    state CheckpointChoice <<choice>>
    ThreeWayMatch --> CheckpointChoice
    
    CheckpointChoice --> CheckpointA : Discrepancy or Risk Alert
    CheckpointChoice --> CheckpointB : Matched within Policy

    state CheckpointA {
        [*] --> ExceptionHold
        ExceptionHold --> APManagerReview
        APManagerReview --> IssueDebitNote : Variance Deducted
        APManagerReview --> ApproveOverride : Documented Justification
        APManagerReview --> RejectVoucher : Cancel Invoice
    }

    state CheckpointB {
        [*] --> TieredMonetaryGate
        TieredMonetaryGate --> FinanceExecutive : Amount <= 1 Lakh
        TieredMonetaryGate --> APManager : Amount <= 10 Lakhs
        TieredMonetaryGate --> FinanceController : Amount > 10 Lakhs
        FinanceExecutive --> DecisionLogged
        APManager --> DecisionLogged
        FinanceController --> DecisionLogged
    }

    CheckpointA --> CheckpointB : On Resolution
    CheckpointB --> [*] : Ready for Disbursement
```

---

### 4.5 Testing and Evaluation Summary

The prototype was subjected to comprehensive automated test suites:
- **Backend Test Suite (Pytest)**: **42 tests passed in 1.65 seconds** across 15 standard reconciliation scenarios, API endpoints, GST parsing, and multi-agent coordination.
- **Frontend Test Suite (Vitest)**: **3 tests passed in 1.69 seconds** validating financial formatting and UI state logic.
- **Total Test Coverage**: **45 passed, 0 failed**.
- **Full Test Evidence Log**: Documented in [`docs/testing/test_evidence_register.md`](file:///Users/veerenkumarkonchada/.gemini/antigravity/scratch/ap-intelligence/docs/testing/test_evidence_register.md).

