# AP INTELLIGENCE: Academic Viva Voce Preparation Guide
**Programme**: MBA Finance | Course: Agentic AI for Business Operations  
**Student & Lead Developer**: Veeren Kumar Konchada | Academic Group 3  

---

### Core Viva Defense Principles
When defending this project before the faculty panel:
1. **Frame the solution primarily as a BUSINESS & FINANCE AUTOMATION PLATFORM**, not just a technical programming project.
2. Emphasize that **Generative AI does NOT calculate taxes or make payment decisions**; all math is governed by **deterministic Python logic** (`decimal.Decimal`).
3. Point out that **real-world payments are never executed autonomously**; human authorization is mandatory at every state-changing gate.

---

### Key Viva Questions & Recommended Model Answers

#### Q1: "Why use Agentic AI when traditional RPA or OCR scripts already exist?"
> **Model Answer**:  
> Traditional RPA relies on brittle, template-based screen coordinates. If a supplier changes their invoice font, moves the PO reference box, or adjusts column headers, RPA fails completely. Similarly, basic OCR only outputs unorganized character strings.  
> Our Multi-Agent solution employs **Agent 1 (Invoice Intelligence)** to semantically understand unstructured invoice documents, normalize varied formats, and calculate extraction confidence scores. Furthermore, our supervisor-worker architecture orchestrates specialized domain agents—delegating PO verification to Agent 2 and physical goods verification to Agent 3—while preserving deterministic mathematical invariance in Agent 4 for 3-way matching.

#### Q2: "How does your system prevent AI hallucinations in financial amounts and taxes?"
> **Model Answer**:  
> We enforce the **Mathematical Invariance Principle**. Generative AI tokens are strictly prohibited from performing numeric calculations or approving transactions. All unit rates, taxable amounts, statutory GST calculations (CGST/SGST vs IGST), and percentage tolerances are executed using Python's `decimal.Decimal` module, ensuring zero IEEE 754 floating-point drift. The LLM is restricted to qualitative tasks: explaining anomaly reasons, parsing natural language queries in the Finance Copilot, and drafting remediation actions.

#### Q3: "What happens if a supplier bills for goods that were never received?"
> **Model Answer**:  
> This is prevented by our **Three-Way Matching Engine (Agent 4)**. The invoice line items are triangulated not only against the Purchase Order commitment but also against the warehouse **Goods Receipt Note (GRN)** accepted quantity. If a supplier bills for 15 units while the warehouse accepted only 10, the engine automatically flags a `QUANTITY_MISMATCH` with an exact financial exposure calculation. The invoice is immediately halted in `EXCEPTION_HOLD` for human review in the Exception Workbench, preventing unauthorized cash disbursement.

#### Q4: "How does the platform align with Indian statutory requirements like GST and the DPDP Act?"
> **Model Answer**:  
> On the GST front, the platform implements format validation for 15-character alphanumeric GSTINs (Rule 46 of CGST Rules), validates 2-digit state prefixes, and dynamically segregates Intra-State supply (CGST + SGST) from Inter-State supply (IGST).  
> Regarding the Digital Personal Data Protection (DPDP) Act, 2023, the platform enforces data minimization (only extracting necessary transaction fields), masks sensitive bank account numbers and PAN numbers to the last 4 digits in audit logs, and maintains an immutable non-repudiation log (`audit_logs`) of every user and agent interaction.

#### Q5: "Walk me through your ROI and cost-benefit numbers. How did you arrive at 342% ROI?"
> **Model Answer**:  
> Our model is based on an enterprise baseline processing 12,000 invoices annually. Under manual operations, clerical labor, paper filing, and verification bottlenecks cost ₹450 per invoice. With AP INTELLIGENCE achieving a 78.2% straight-through processing rate, the automated cost drops to ₹42.50 per invoice—generating ₹48.90 Lakhs in annual gross savings.  
> Deducting ₹14.40 Lakhs in annual cloud infrastructure and maintenance yields **₹34.50 Lakhs in annual net benefit**. Against an upfront initial development investment of ₹12.00 Lakhs, this produces an **annual ROI of 342.5%** and a **payback period of just 4.2 months**.

