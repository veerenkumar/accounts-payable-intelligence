# AP INTELLIGENCE — ACADEMIC REPORT APPENDICES

> **Course**: Agentic AI for Business Operations | MBA Finance  
> **Student**: Veeren Kumar Konchada  
> **Academic Project Group**: Group 3  

---

## Appendix A: Complete REST API Contract Directory

| Endpoint Route | HTTP Method | Request Payload | Response Schema | Description |
|---|:---:|---|---|---|
| `/api/v1/health` | `GET` | None | `HealthResponse` | System health and database connectivity probe. |
| `/api/v1/analytics/dashboard` | `GET` | None | `KPIDashboardResponse` | Executive KPI metrics (Total Spend, Invoice Count, STP Rate). |
| `/api/v1/vendors` | `GET` | None | `List[VendorResponse]` | Vendor directory with GSTINs, state codes, and risk categories. |
| `/api/v1/purchase-orders` | `GET` | `?vendor_id=` | `List[POResponse]` | Purchase order master registry and line item schedules. |
| `/api/v1/grn` | `GET` | `?po_id=` | `List[GRNResponse]` | Warehouse delivery receipts and accepted vs rejected counts. |
| `/api/v1/invoices` | `GET` | `?status=&match_status=` | `List[InvoiceResponse]` | Invoices ledger enriched with OCR conflict metadata. |
| `/api/v1/invoices/{id}` | `GET` | Path `invoice_id` | `InvoiceResponse` | Single invoice detail with field-by-field OCR discrepancy list. |
| `/api/v1/matching` | `GET` | None | `List[MatchingResponse]` | Ingestion match status and tolerance verdicts. |
| `/api/v1/matching/{id}` | `GET` | Path `invoice_id` | `TriangulationDetailResponse` | Full 3-way triangulation ($Invoice \leftrightarrow PO \leftrightarrow GRN$). |
| `/api/v1/matching/evaluate/{id}` | `POST` | `MatchingEvaluateRequest` | `MatchingResponse` | Re-evaluates 3-way matching engine for an invoice. |
| `/api/v1/exceptions` | `GET` | `?category=&status=` | `List[ExceptionResponse]` | Open exception workbench records and exposure metrics. |
| `/api/v1/approvals` | `GET` | `?search=` | `List[ApprovalResponse]` | Tiered approval queue with blocking exception guards. |
| `/api/v1/approvals/{id}/action` | `POST` | `ApprovalActionRequest` | `ApprovalResponse` | Approves, holds, or rejects an invoice within DOA limit. |
| `/api/v1/invoices/{id}/reconcile-ocr` | `POST` | `InvoiceReconcileOCRRequest` | `InvoiceReconcileOCRResponse` | Authorized human verification to reconcile ledger with OCR artifact. |
| `/api/v1/documents` | `GET` | None | `List[DocumentResponse]` | Stored document artifacts, OCR raw text, and confidence scores. |
| `/api/v1/copilot/query` | `POST` | `CopilotQueryRequest` | `CopilotQueryResponse` | Natural language conversational AP assistant with database tools. |

---

## Appendix B: Database Relational Schema Dictionary

| Table Name | Primary Key | Foreign Keys | Key Columns | Purpose |
|---|---|---|---|---|
| `vendors` | `id` (VARCHAR 32) | None | `name`, `gstin`, `pan`, `state_code`, `risk_category` | Authoritative master directory of approved corporate vendors. |
| `purchase_orders` | `id` (VARCHAR 32) | `vendor_id` | `order_date`, `total_amount_inr`, `status` | Contractual purchase orders issued to suppliers. |
| `po_items` | `id` (VARCHAR 36) | `po_id` | `line_number`, `item_code`, `quantity`, `unit_price_inr` | Itemized line schedules with agreed pricing and specs. |
| `goods_receipt_notes` | `id` (VARCHAR 32) | `po_id`, `vendor_id` | `receipt_date`, `delivery_challan_no`, `status` | Physical warehouse receipt confirmations. |
| `grn_items` | `id` (VARCHAR 36) | `grn_id` | `item_code`, `quantity_received`, `quantity_accepted`, `quantity_rejected` | Physical count verification and transit damage tracking. |
| `invoices` | `id` (VARCHAR 64) | `vendor_id`, `po_reference`, `document_id` | `invoice_date`, `vendor_gstin`, `taxable_value_inr`, `total_amount_inr`, `status`, `match_status` | Authoritative financial ledger row for supplier invoices. |
| `invoice_items` | `id` (VARCHAR 36) | `invoice_id` | `line_number`, `item_code`, `quantity`, `unit_price_inr`, `total_line_amount_inr` | Billed line items from supplier tax invoice. |
| `matching_results` | `id` (VARCHAR 36) | `invoice_id`, `po_id`, `grn_id` | `match_status`, `price_variance_percent`, `quantity_variance_percent`, `is_matched` | Verdict record from deterministic 3-way matching engine. |
| `exceptions` | `id` (VARCHAR 32) | `invoice_id` | `category`, `severity`, `financial_impact_inr`, `status` | Discrepancy lifecycle record in Exception Workbench. |
| `approval_requests` | `id` (VARCHAR 32) | `invoice_id` | `amount_inr`, `required_role`, `status` | Approval queue records gated by Delegation of Authority. |
| `audit_logs` | `id` (VARCHAR 36) | None | `entity_type`, `entity_id`, `action`, `actor_id`, `old_state`, `new_state`, `timestamp` | Tamper-evident, append-only non-repudiation audit trail. |
| `documents` | `id` (VARCHAR 36) | None | `file_name`, `file_path`, `ocr_raw_text`, `ocr_confidence_score` | Binary file artifact metadata and extracted OCR stream. |

---

## Appendix C: Indian GST Statutory Tax Logic & Place of Supply Rules

1. **Intra-State Supply**:
   - Condition: $\text{Vendor State Code} == \text{Place of Supply (POS)}$
   - Tax Application: Equal split between Central Goods & Services Tax (CGST) and State Goods & Services Tax (SGST).
   - $\text{CGST Amount} = \text{Taxable Value} \times 9\%$
   - $\text{SGST Amount} = \text{Taxable Value} \times 9\%$
   - $\text{IGST Amount} = ₹0.00$
2. **Inter-State Supply**:
   - Condition: $\text{Vendor State Code} \neq \text{Place of Supply (POS)}$
   - Tax Application: Integrated Goods & Services Tax (IGST) exclusively.
   - $\text{IGST Amount} = \text{Taxable Value} \times 18\%$
   - $\text{CGST Amount} = ₹0.00, \quad \text{SGST Amount} = ₹0.00$
3. **Mathematical Invariance**:
   $$\text{Total Tax} = \text{CGST} + \text{SGST} + \text{IGST}$$
   $$\text{Grand Total} = \text{Taxable Value} + \text{Total Tax}$$

---

## Appendix D: 15 Core Business Scenarios Test Matrix

| Scenario ID | Test Function | Scenario Description | Input Variances | Expected Engine Verdict | Verified Test Status |
|:---:|---|---|---|:---:|:---:|
| **SC-01** | `test_sc01_exact_match` | Perfect 3-Way Match | Zero price or quantity variance | `EXACT_MATCH` | **PASSED** |
| **SC-02** | `test_sc02_quantity_mismatch` | Billed Quantity > Accepted | Invoiced Qty 50 vs Received Qty 20 | `QUANTITY_MISMATCH` | **PASSED** |
| **SC-03** | `test_sc03_price_mismatch` | Unit Price Escalation | Invoice unit rate exceeds PO rate by 8.9% | `PRICE_MISMATCH` | **PASSED** |
| **SC-04** | `test_sc04_match_within_tolerance`| Price Variance within Tolerance | Rate variance +1.2% (under 2% policy) | `MATCH_WITHIN_TOLERANCE` | **PASSED** |
| **SC-05** | `test_sc05_missing_po` | Missing / Invalid PO Reference | Non-existent PO reference | `MISSING_PO` | **PASSED** |
| **SC-06** | `test_sc06_missing_grn` | Missing Goods Receipt Note | Valid PO exists, but zero warehouse GRN | `MISSING_GRN` | **PASSED** |
| **SC-07** | `test_sc07_duplicate_invoice` | Duplicate Billing Attempt | Same invoice number, supplier, & amount | `DUPLICATE_INVOICE` | **PASSED** |
| **SC-08** | `test_sc08_vendor_mismatch` | Cross-Vendor PO Mismatch | Invoice from Vendor B points to PO of Vendor A | `VENDOR_MISMATCH` | **PASSED** |
| **SC-09** | `test_sc09_partial_delivery` | Multiple Partial Receipts | Delivery split across multiple shipments | `MATCH_WITHIN_TOLERANCE` | **PASSED** |
| **SC-10** | `test_sc10_multi_line_invoice` | Multi-line Split Reconciliations | 5 line items with distinct tax rates | `EXACT_MATCH` | **PASSED** |
| **SC-11** | `test_sc11_over_receipt` | Over-receipt at Warehouse | Warehouse received 25 units for 20-unit PO | `REQUIRES_HUMAN_REVIEW` | **PASSED** |
| **SC-12** | `test_sc12_under_receipt` | Under-receipt (Damage in Transit) | 2 units rejected due to transit damage | `QUANTITY_MISMATCH` | **PASSED** |
| **SC-13** | `test_sc13_unauthorized_item` | Unauthorized Line Item | Invoiced SKU code absent on PO | `ITEM_MISMATCH` | **PASSED** |
| **SC-14** | `test_sc14_zero_quantity` | Zero Invoiced Quantity | Line quantity submitted as 0.00 | `QUANTITY_MISMATCH` | **PASSED** |
| **SC-15** | `test_sc15_substantial_price_escalation`| Catastrophic Price Surge | Invoice unit rate +45% over baseline | `PRICE_MISMATCH` | **PASSED** |

---

## Appendix E: Delegation of Authority (DOA) Matrix

| Approval Tier | Authorized Corporate Role | Maximum Approval Ceiling | Permitted Invoice Types | Required Approvers |
|:---:|---|---|---|:---:|
| **Tier 1** | Finance Executive | $\le ₹1,00,000$ | Clean `EXACT_MATCH` only | 1 |
| **Tier 2** | Accounts Payable Manager | $\le ₹10,00,000$ | `EXACT_MATCH` & `MATCH_WITHIN_TOLERANCE` | 1 |
| **Tier 3** | Finance Controller / CFO | Unlimited ($> ₹10,00,000$) | All matched invoices & Resolved Exceptions | 2 (Dual Sign-off) |
| **Blocking Gate** | Any Role (Including CFO) | **Blocked** | Invoices with `MISSING_PO`, `DUPLICATE_INVOICE`, or open exceptions | **Approval Prohibited** |

