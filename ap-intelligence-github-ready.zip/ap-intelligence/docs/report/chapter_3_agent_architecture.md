# CHAPTER 3: AGENT ARCHITECTURE AND DESIGN (MODULE M2)
## AP INTELLIGENCE: Supervisor-Worker Multi-Agent Architecture
**Academic Module**: M2 | MBA Finance Evaluation

---

### 3.1 Design Approach & Principles
The architecture of **AP INTELLIGENCE** is founded on four foundational software and financial engineering principles:
1. **Mathematical Invariance Principle**: Financial calculations (unit rates, taxable bases, statutory CGST/SGST/IGST, tolerance variances, financial impacts) are never delegated to LLM generative tokens. All mathematical evaluations execute through deterministic Python routines (`decimal.Decimal`).
2. **Supervisor-Worker Pattern**: A central coordinator agent manages workflow state, controls execution flow, handles retries, and enforces loop-prevention thresholds.
3. **Structured Pydantic Interfaces**: Every inter-agent communication boundary is enforced by strictly validated Pydantic schemas, eliminating parsing hallucinations.
4. **Dual Human-in-the-Loop Boundaries**: Sensitive state-changing financial actions (exception overrides and payment authorizations) are gated by cryptographic and session-backed human approvals.

---

### 3.2 System Architecture Diagram

```mermaid
graph TD
    subgraph UI ["Enterprise UI (Next.js 14 / Tailwind / Lucide)"]
        Dashboard["Executive Dashboard"]
        Workbench["Exception Workbench"]
        Approvals["Approval Center"]
        CopilotUI["Finance Copilot"]
    end

    subgraph API ["FastAPI Gateway & Security"]
        Router["REST API Endpoints"]
        RBAC["Role-Based Access Control"]
        AuditService["Audit Logger"]
    end

    subgraph Orchestrator ["LangGraph Multi-Agent Orchestrator"]
        Supervisor["Supervisor Agent"]
        
        A1["Agent 1: Invoice Intelligence"]
        A2["Agent 2: PO Analysis"]
        A3["Agent 3: GRN Verification"]
        A4["Agent 4: 3-Way Matching Engine"]
        A5["Agent 5: Fraud & Risk Detection"]
        A6["Agent 6: Exception Resolution"]
        A7["Agent 7: Approval Management"]
        A8["Agent 8: Finance Analytics"]
    end

    subgraph CoreEngine ["Deterministic Core"]
        CalcEngine["Decimal Math & Reconciliation"]
        GSTEngine["GST Format & State Validator"]
    end

    subgraph Storage ["Persistence Layer"]
        DB[("PostgreSQL 16 + pgvector / SQLite")]
        DocStore["Sample Document Storage"]
    end

    UI --> API
    API --> Orchestrator
    Orchestrator --> CoreEngine
    Orchestrator --> DB
    API --> Storage
```

---

### 3.3 The Eight Specialized AI Agents Specification Table

| # | Agent Name | Domain Purpose | Input Data | Output Artifact | Deterministic Engine Used |
|---|---|---|---|---|---|
| 1 | **Invoice Intelligence Agent** | Document receipt & field extraction | Raw PDF/Image | `InvoiceExtractionResult` | Regex field normalizer & GST regex validator |
| 2 | **PO Analysis Agent** | Purchase commitment authorization | PO reference string | `POAnalysisResult` | SQL PO master ledger lookup |
| 3 | **GRN Verification Agent** | Inward warehouse inspection | PO reference string | `GRNVerificationResult` | Warehouse receipt accepted/rejected ledger |
| 4 | **Three-Way Matching Agent** | Financial reconciliation & variance | Extracted Invoice, PO, GRN | `ThreeWayMatchVerdict` | `DeterministicMatchingEngine` (`decimal.Decimal`) |
| 5 | **Fraud & Risk Agent** | Internal control protection | Invoice header, PO history | `FraudRiskAssessment` | Anomaly heuristic scorer & duplicate checker |
| 6 | **Exception Resolution Agent** | Root-cause classification & remediation | Mismatch discrepancy list | `ExceptionTicket` | ERP tolerance advisor & debit note drafter |
| 7 | **Approval Management Agent** | Enforce delegation-of-authority limits | Reconciled invoice amount | `ApprovalRoutingDecision` | Configurable monetary threshold evaluator |
| 8 | **Finance Analytics Agent** | Working capital & DPO synthesis | Ledger transaction history | `ExecutiveAnalyticsReport` | Financial KPI aggregator & cash flow forecaster |

---

### 3.4 Memory and Knowledge Design
- **Short-Term Workflow State**: Managed through the strongly typed `AgentWorkflowState` dictionary within LangGraph. Contains the complete payload of the current document run, field confidences, discrepancy logs, and token usage metrics.
- **Long-Term Enterprise Memory**: Relational database persistence within normalized PostgreSQL/SQLite tables (`invoices`, `matching_results`, `exceptions`, `approval_history`, `audit_logs`).
- **Semantic Knowledge (pgvector)**: Vector embeddings of corporate procurement policies, master vendor contracts, and supplier payment terms, enabling the Finance Copilot to ground conversational responses in enterprise documentation.

---

### 3.5 Orchestration and Communication Flow

```mermaid
sequenceDiagram
    autonumber
    actor User as AP Specialist
    participant Sup as Supervisor Agent
    participant InvAg as Agent 1: Invoice Intel
    participant MatchAg as Agent 4: 3-Way Match
    participant RiskAg as Agent 5: Fraud Risk
    participant ExAg as Agent 6: Exception
    participant ApprAg as Agent 7: Approval
    participant DB as Relational Database

    User->>Sup: Ingest Supplier Invoice (PDF)
    Sup->>InvAg: Extract Fields & Validate GSTIN
    InvAg-->>Sup: Invoice Data (Confidence: 0.985)
    Sup->>MatchAg: Trigger Deterministic 3-Way Match
    MatchAg-->>Sup: Match Status (Tolerance Passed / Mismatch)
    Sup->>RiskAg: Compute Anomaly & Duplicate Score
    RiskAg-->>Sup: Risk Score (0-100)
    
    alt Discrepancy Found or High Risk
        Sup->>ExAg: Classify Discrepancy & Root Cause
        ExAg-->>Sup: Create Exception Ticket
        Sup->>DB: Save Exception Record & Set Status='EXCEPTION_HOLD'
    else Exact Match or Passed Tolerance
        Sup->>ApprAg: Route to Authorized Approver
        ApprAg-->>Sup: Assigned Tier (Executive/Manager/Controller)
        Sup->>DB: Save Approval Request & Set Status='PENDING_APPROVAL'
    end
    Sup-->>User: Complete Run Notification with Audit Trail
```

---

### 3.6 Design Decisions and Alternatives Considered

1. **Deterministic Code vs. LLM for Three-Way Matching**:
   - *Alternative Considered*: Asking an LLM prompt to compare PO, GRN, and Invoice and decide whether to approve.
   - *Decision Made*: Strictly rejected. LLMs are non-deterministic, prone to calculation hallucinations, and lack legal accountability. All mathematical matching is executed by deterministic Python logic; LLMs are restricted to text parsing and qualitative discrepancy explanation.
2. **Dual Database Architecture (PostgreSQL + SQLite Fallback)**:
   - *Alternative Considered*: Requiring external cloud PostgreSQL (Supabase/RDS) for all environments.
   - *Decision Made*: Implemented dual connection adapters. The production profile runs on PostgreSQL 16 + pgvector via Docker, while local evaluation runs seamlessly on SQLite with zero external dependencies.
3. **No Automatic Real-World Disbursement**:
   - *Alternative Considered*: Integrating live bank payment gateway APIs for automatic transfer on approval.
   - *Decision Made*: Intentionally avoided. For security and internal control integrity, the platform produces approved payment vouchers and audit records, leaving final banking release to authorized treasury systems.

