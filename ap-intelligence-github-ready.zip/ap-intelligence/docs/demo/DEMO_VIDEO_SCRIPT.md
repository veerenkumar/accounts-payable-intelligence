# AP INTELLIGENCE — 4-MINUTE DEMONSTRATION VIDEO SCRIPT

> **Academic Course**: Agentic AI for Business Operations | MBA Finance  
> **Presenter**: Veeren Kumar Konchada  
> **Duration**: Exactly 04:00 Minutes  
> **Application Target**: `http://localhost:3000` (Next.js Frontend) & `http://localhost:8000` (FastAPI Backend)

---

### Segment 1: Introduction & Executive Problem Statement (00:00 – 00:45)

- **On-Screen**:
  - Open browser at `http://localhost:3000/` (Executive Dashboard).
  - Hover over KPI cards: Total Invoices (32), Active Exceptions (10), Pending Approvals (12), Straight-Through Processing (STP) Rate.
- **Voiceover**:
  > *"Hello, my name is Veeren Kumar Konchada, and welcome to AP Intelligence: an enterprise financial automation platform built for modern Accounts Payable operations.*
  > 
  > *In corporate finance, accounts payable teams struggle with high invoice processing costs—averaging over ₹500 per invoice—and severe exposure to duplicate billing, supplier identity mismatches, and delayed 3-way reconciliations. Traditional OCR tools extract text but lack financial common sense, while unconstrained LLMs hallucinate numbers.*
  > 
  > *AP Intelligence solves this through a dual-architecture: pairing an 8-agent LangGraph supervisor network for intelligent document extraction with a strictly deterministic matching engine and human-in-the-loop governance."*

---

### Segment 2: Document Processing & OCR Inspection (00:45 – 01:30)

- **On-Screen**:
  - Navigate to `http://localhost:3000/documents`.
  - Show the Document Center with uploaded invoices.
  - Click **"Inspect OCR"** on `INV_2026_00452_TataSteel.pdf`.
  - Highlight the 98% confidence score, extracted raw OCR text stream, and structured fields (Invoice Number, Supplier Name, GSTIN: `27AAACT2727Q1ZW`, PO: `PO-2026-00101`, Total: `₹2,46,620.00`).
- **Voiceover**:
  > *"Let's explore our Document Center. When a supplier submits an invoice—whether as a digital PDF or a scanned image—Agent 1, our Invoice Intelligence Agent, parses the layout, verifies the Indian GSTIN structure, and extracts line items with an honest confidence score.*
  > 
  > *Here, for invoice INV-2026-00452, our system extracts Tata Steel Products Ltd., PO-2026-00101, and an invoice total of ₹2,46,620. Crucially, the platform isolates this unverified document artifact from the core financial ledger, preventing raw OCR from silently modifying accounting records."*

---

### Segment 3: Deterministic Three-Way Matching & Triangulation (01:30 – 02:30)

- **On-Screen**:
  - Navigate to `http://localhost:3000/matching`.
  - Show the 3-Way Matching dashboard with 2% price and 0% quantity tolerance controls.
  - Click into `INV-2026-00451` to show a clean **EXACT_MATCH** with green checks across Invoice $\leftrightarrow$ PO-2026-00101 $\leftrightarrow$ GRN-2026-00081 (20 units of Heavy Structural Steel Beams).
  - Then, click into `INV-2026-00452` to display **MISSING_PO** and **NO GRN FOUND**.
- **Voiceover**:
  > *"Now let's examine Agent 4, our Deterministic Three-Way Matching Engine. On invoice INV-2026-00451, we see a textbook straight-through match: 20 units of Structural Steel Beams agreed across Tata Steel's invoice, Purchase Order 00101, and Goods Receipt Note 00081.*
  > 
  > *However, observe invoice INV-2026-00452. The ERP ledger records this invoice under supplier Larsen & Toubro referencing PO-2026-00101-AMENDED, a reference that does not exist in our purchase order database. The matching engine strictly evaluates confirmed ledger data—never unapproved OCR suggestions. It flags MISSING PO, finds NO GRN, and routes the invoice to our Exception Workbench with an exposure of ₹2,46,620."*

---

### Segment 4: OCR Reconciliation & Cross-Vendor Collision Safeguards (02:30 – 03:15)

- **On-Screen**:
  - Navigate to `http://localhost:3000/invoices`.
  - Point to the yellow indicator **`⚠️ OCR Conflict`** on the `INV-2026-00452` table row.
  - Click **"Review / Correct"** to open the modal.
  - Showcase the **Document OCR vs Ledger Reconciliation** side-by-side comparison table:
    - Supplier Name: *Larsen & Toubro Heavy Engg* vs *Tata Steel Products Ltd.* (⚠️ Discrepancy)
    - Supplier GSTIN: *27AAACL0140P1ZH* vs *27AAACT2727Q1ZW* (⚠️ Discrepancy)
    - PO Reference: *PO-2026-00101-AMENDED* vs *PO-2026-00101* (⚠️ Discrepancy)
    - Total Amount: *₹2,46,620.00* vs *₹2,46,620.00* (✓ Verified Match)
- **Voiceover**:
  > *"Here is one of our most powerful innovations: Cross-Vendor Collision & OCR Reconciliation.*
  > 
  > *In corporate reality, distinct vendors can independently issue invoices with the same invoice number. In our Review Modal, the system detects that the ledger record belongs to Larsen & Toubro, while the scanned document belongs to Tata Steel.*
  > 
  > *It highlights the supplier and PO conflicts in a clear side-by-side comparison. Crucially, the platform enforces strict Role-Based Access Control: junior clerks cannot override ledger data. Only authorized finance managers can execute reconciliation, and every action writes a tamper-evident before-and-after snapshot to our audit log."*

---

### Segment 5: Approval Center, AI Copilot & Business ROI (03:15 – 04:00)

- **On-Screen**:
  - Navigate to `http://localhost:3000/approvals`.
  - Search for `INV-2026-00452` in the search box.
  - Show the row with status **HELD**, showing **1 Blocking Exception** and a disabled Approve button.
  - Briefly navigate to `http://localhost:3000/copilot` and submit query: *"What is our total outstanding liability?"*.
  - Show grounded response backed by the database.
  - Switch to `http://localhost:3000/analytics` showing the 3-Year ROI model (₹1.8 Cr net savings).
- **Voiceover**:
  > *"In our Approval Center, financial controls are uncompromising. Because INV-2026-00452 has an open MISSING_PO exception, the invoice is locked on EXCEPTION_HOLD. The platform strictly prevents any user—even a CFO—from approving an unverified invoice.*
  > 
  > *Meanwhile, finance teams can interact with our AI Copilot to query payables and vendor scorecards with verifiable database truth, while our Analytics dashboard projects an annual operating savings exceeding 65% with payback in under 7 months.*
  > 
  > *AP Intelligence demonstrates how Agentic AI can revolutionize corporate finance without compromising auditability, compliance, or mathematical precision. Thank you."*

---

### Recording & Production Notes

1. **Audio**: Crisp narration recorded via dedicated USB microphone with minimal background noise.
2. **Resolution**: 1080p Full HD (1920x1080) at 60 FPS.
3. **Cursor Cues**: Enable subtle yellow highlight or smooth cursor motion to guide the viewer's attention.
4. **Dev Servers**: Keep FastAPI (`port 8000`) and Next.js (`port 3000`) running in background.

