#!/bin/bash
set -e

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
echo "=== Initializing AP INTELLIGENCE Environment ==="
echo "Project Root: $ROOT_DIR"

# 1. Setup Node path
if [ -d "$HOME/.nvm/versions/node/v20.20.2/bin" ]; then
  export PATH="$HOME/.nvm/versions/node/v20.20.2/bin:$PATH"
fi
echo "Node version: $(node -v)"
echo "NPM version: $(npm -v)"

# 2. Setup Backend Python Virtualenv
echo "Setting up Backend Virtual Environment..."
cd "$ROOT_DIR/backend"
if [ ! -d "venv" ]; then
  python3 -m venv venv
fi
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt reportlab

# 3. Generate Sample Documents & Seed Database
echo "Generating synthetic invoice documents..."
cd "$ROOT_DIR"
backend/venv/bin/python data/synthetic/generate_sample_documents.py

echo "Initializing SQLite database with seed records..."
cd "$ROOT_DIR/backend"
source venv/bin/activate
python -m app.database.seed

# 4. Setup Frontend Dependencies
echo "Setting up Frontend Next.js Dependencies..."
cd "$ROOT_DIR/frontend"
npm install

echo "=== AP INTELLIGENCE Setup Completed Successfully ==="

